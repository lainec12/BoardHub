import {createCheckersView} from './checkers.js';
import {createLudoView} from './ludo.js';
import {renderUno} from './uno.js';
import {createBattleshipView} from './battleship.js';
import {createChessView} from './chess.js';
const renderChess=createChessView();
const renderBattleship=createBattleshipView();
/* O cliente envia ações e desenha exclusivamente o estado confirmado no servidor. */
const $=id=>document.getElementById(id);
const socket=io();
let state,me,playerId,pending=false,credentials;
const checkersView=createCheckersView($('board'),$('moveHint'),send);
const ludoView=createLudoView($('ludoBoard'),$('ludoPanel'),send);
try {credentials=JSON.parse(sessionStorage.getItem('boardhub-session'));}catch{}
const urlCode=location.pathname.match(/^\/join\/([a-z0-9]{6})$/i)?.[1] || new URLSearchParams(location.search).get('sala');
$('code').value=urlCode || '';
function feedback(text=''){$('feedback').textContent=text;}
function send(event,data={}) {
  return new Promise(resolve=>socket.timeout(5000).emit(event,data,(err,result)=>{
    if(err){feedback('Sem resposta do servidor. Aguarde a conexão.');resolve(null);}
    else{if(!result.ok)feedback(result.error);resolve(result);}
  }));
}
function forget(reason='Você saiu da sala.') {
  credentials=null;state=null;me=null;playerId=null;checkersView.reset();ludoView.reset();
  sessionStorage.removeItem('boardhub-session');$('messages').replaceChildren();
  $('lobby').hidden=false;$('game').hidden=true;history.replaceState(null,'','/');feedback(reason);
}
async function enter(create=false,resume=false){
  if(pending || !socket.connected)return;
  pending=true;feedback();
  const data=resume?{...credentials}:{name:$('name').value,code:$('code').value.trim().toUpperCase(),gameId:$('gameChoice').value,mode:$('ludoMode').value,acquisition:$('powerAcquisition').value};
  const result=await send(create?'room:create':'room:join',data);pending=false;
  if(!result?.ok){if(resume)forget(result?.error || 'Não foi possível restaurar a sala.');return;}
  me=result.mark;playerId=result.playerId;credentials={name:data.name,code:result.code,token:result.token};
  sessionStorage.setItem('boardhub-session',JSON.stringify(credentials));
  history.replaceState(null,'','/join/'+result.code);$('lobby').hidden=true;$('game').hidden=false;render();
}
socket.on('connect',()=>{
  $('connection').textContent='● Conectado';
  if(credentials && (!urlCode || credentials.code===urlCode.toUpperCase()))enter(false,true);
  else render();
});
socket.on('disconnect',()=>{$('connection').textContent='Reconectando…';render();});
socket.on('connect_error',()=>{$('connection').textContent='Servidor indisponível';});
socket.on('game:state',s=>{state=s;render();});
socket.on('room:removed',d=>forget(d.reason));
$('create').onclick=()=>enter(true);$('join').onclick=()=>enter();
function render(){
  if(!state)return;
  const focused=document.activeElement;
  const focusedCell=focused?.dataset?.cell;
  const game=state.game,host=state.host===playerId;
  const isCheckers=state.gameId.startsWith('checkers-');
  const isLudo=state.gameId==='ludo';
  const isUno=state.gameId==='uno';
  const isNaval=state.gameId==='battleship';
  const isChess=state.gameId==='chess';
  $('gameTitle').textContent=state.gameName;
  $('rulesText').textContent=rules[state.gameId];
  $('roomcode').textContent=state.code;
  const marks=isLudo||isUno?['red','green','yellow','blue']:['X','O'];
  $('players').replaceChildren(...marks.map(mark=>{
    const p=state.players.find(p=>p.mark===mark),el=document.createElement('div');el.className='player';
    const title=document.createElement('b');title.textContent=sideName(state,mark)+' · '+(p?.name || 'Aguardando amigo');
    const sub=document.createElement('small');
    sub.textContent=p?(p.online?'Conectado':'Desconectado · retorno em até 60s')+(mark===me?' · Você':'')+(p.id===state.host?' · Anfitrião':''):'Compartilhe o convite';
    el.append(title,sub);return el;
  }));
  const ready=state.players.length>=2 && state.players.every(p=>p.online) && socket.connected;
  const turn=isLudo||isUno?game.players?.[game.turnIndex]?.color:game.turn;
  $('status').textContent=!socket.connected?'Reconectando…':game.winner==='draw'?'Deu empate!':game.winner?`${state.players.find(p=>p.mark===game.winner)?.name || sideName(state,game.winner)} venceu!`:state.status==='waiting'?(ready?'Prontos! O anfitrião pode iniciar.':'Convide pelo menos mais um amigo.'):!ready?'Partida pausada. Aguardando reconexão…':turn===me?'Sua vez de jogar!':`Vez de ${state.players.find(p=>p.mark===turn)?.name}`;
  $('round').textContent='Partida '+game.round+' · Você: '+sideName(state,me)+(game.ply!==undefined?' · lance '+(game.ply+1):'')+(game.reason?' · '+game.reason:'');
  $('flip').hidden=!isCheckers;
  const canPlay=ready && state.status==='playing' && turn===me && !game.winner;
  $('ludoBoard').hidden=!isLudo;$('ludoPanel').hidden=!isLudo;$('board').hidden=isLudo;
  if(isChess){$('undoPath').hidden=true;$('moveHint').textContent=game.check?'Xeque! Proteja seu rei.':'Selecione uma peça e um destino destacado.';renderChess($('board'),state,me,send,canPlay);}
  else if(isNaval){$('undoPath').hidden=true;$('moveHint').textContent='Posicione sua frota em segredo; os tiros começam quando os dois confirmarem.';renderBattleship($('board'),state,me,send,ready&&state.status==='playing');}
  else if(isUno){$('board').className='uno-board';$('undoPath').hidden=true;$('moveHint').textContent='Suas cartas são privadas. Escolha uma carta disponível ou compre.';renderUno($('board'),state,me,send,ready&&state.status==='playing');}
  else if(isLudo){$('moveHint').textContent=game.lastEvent?eventText(game.lastEvent):'Role o dado para começar.';$('undoPath').hidden=true;$('flip').hidden=true;ludoView.render(state,me,canPlay);}
  else if(isCheckers){checkersView.render(state,me,canPlay);}else{
  $('board').className='';$('moveHint').textContent='';$('undoPath').hidden=true;
  $('board').replaceChildren(...game.board.map((mark,i)=>{
    const b=document.createElement('button');b.dataset.cell=String(i);b.className='cell '+(mark==='O'?'o ':'')+(game.line.includes(i)?'win':'');b.textContent=mark || '';
    b.setAttribute('aria-label',`Linha ${Math.floor(i/3)+1}, coluna ${i%3+1}: ${mark || 'vazia'}`);
    b.disabled=!!mark || !!game.winner || !ready || game.turn!==me || state.status!=='playing';
    b.onclick=()=>send('game:action',{type:'move',cell:i,round:game.round});return b;
  }));
  if(focusedCell!==undefined){
    const cells=[...$('board').querySelectorAll('button')];
    const target=!cells[Number(focusedCell)]?.disabled?cells[Number(focusedCell)]:cells.find(b=>!b.disabled);
    if(target)target.focus({preventScroll:true});
  }
  }
  $('start').hidden=!host || state.status!=='waiting';$('start').disabled=!ready;
  $('restart').hidden=!host || state.status==='waiting';$('restart').disabled=!ready;
  $('resign').disabled=state.status!=='playing' || !socket.connected;
  $('kick').hidden=!host || state.players.length<2;
  $('scores').textContent='Placar da sala · '+state.scores.map(p=>`${p.name}: ${p.wins}`).join(' | ');
  $('offerDraw').hidden=isLudo||isUno||isNaval;$('offerDraw').disabled=!ready || state.status!=='playing' || !!state.drawOffer;
  $('acceptDraw').hidden=$('rejectDraw').hidden=!state.drawOffer || state.drawOffer===playerId || state.status!=='playing';
  $('drawStatus').textContent=state.drawOffer?(state.drawOffer===playerId?'Aguardando resposta ao empate.':'Seu adversário propôs empate.'):'';
  if(isLudo&&game.winner&&game.ranking?.length){$('ranking').replaceChildren(...game.ranking.map(item=>{const p=document.createElement('p');p.textContent=`${item.position}º · ${sideName(state,item.color)} · ${item.home} peças na chegada`;return p;}));$('rematchModal').hidden=!host;if(!$('endModal').open)$('endModal').showModal();}
  // Mensagens entram como texto, nunca como HTML executável.
  const log=$('messages'),bottom=log.scrollHeight-log.scrollTop-log.clientHeight<40;
  const ids=new Set(state.chat.map(m=>m.id));
  for(const el of [...log.children])if(!ids.has(el.dataset.message))el.remove();
  const existing=new Set([...log.children].map(el=>el.dataset.message));
  log.append(...state.chat.filter(m=>!existing.has(m.id)).map(m=>{
    const el=document.createElement('div');el.dataset.message=m.id;el.className='message'+(m.system?' system':'');
    const n=document.createElement('strong');n.textContent=m.name+(m.mark?' · '+m.mark:'');
    const t=document.createElement('time');t.textContent=new Date(m.time).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
    const p=document.createElement('p');p.textContent=m.text;el.append(n,t,p);return el;
  }));if(bottom)log.scrollTop=log.scrollHeight;
}
$('start').onclick=()=>send('room:start');
$('restart').onclick=()=>{if(confirm('Reiniciar a partida? O tabuleiro atual será limpo.'))send('room:restart');};
$('resign').onclick=()=>{if(confirm('Desistir concede a vitória ao adversário. Confirmar?'))send('game:resign');};
$('leave').onclick=()=>{if(state.status!=='playing' || confirm('Sair agora conta como desistência. Confirmar?'))send('room:leave');};
$('kick').onclick=()=>{const others=state.players.filter(p=>p.id!==playerId),name=others.length===1?others[0].name:prompt('Digite exatamente o nome de quem deseja expulsar:'),p=others.find(p=>p.name===name);if(p && confirm('Expulsar '+p.name+' da sala?'))send('room:kick',{playerId:p.id});};
$('chatForm').onsubmit=async e=>{e.preventDefault();const text=$('message').value;if(!text.trim())return;const r=await send('chat:message',{text});if(r?.ok && $('message').value===text)$('message').value='';};
$('invite').onclick=async()=>{const link=location.origin+'/join/'+state.code;try{await navigator.clipboard.writeText(link);feedback('Convite copiado! Envie para seu amigo.');}catch{feedback('Copie este convite: '+link);}};

$('undoPath').onclick=()=>checkersView.undo();
$('flip').onclick=()=>checkersView.flip();
$('offerDraw').onclick=()=>send('game:draw-offer');
$('acceptDraw').onclick=()=>send('game:draw-answer',{accept:true});
$('rejectDraw').onclick=()=>send('game:draw-answer',{accept:false});
$('closeEnd').onclick=()=>$('endModal').close();
$('rematchModal').onclick=()=>{if($('endModal').open)$('endModal').close();send('room:restart');};

const rules={
 'chess':'Brancas (X) começam. Selecione uma peça e um destino legal. Roque, en passant e promoção estão disponíveis conforme a posição. Não é permitido deixar o próprio rei em xeque. Xeque-mate vence; afogamento, material insuficiente, repetição tripla ou 50 lances sem progresso encerram como empate. Também é possível propor empate ou desistir. Sem relógio nesta versão.',
 'battleship':'Dois jogadores, oceano 10×10 e cinco navios com 5, 4, 3, 3 e 2 casas. Posicione na horizontal ou vertical sem sobreposição. Navios podem se tocar. Confirme a frota; depois os tiros alternam mesmo após acerto. Afunde os cinco navios para vencer. O adversário não recebe sua frota secreta.',
 'uno':'De 2 a 4 jogadores. Combine cor ou símbolo; coringas escolhem a cor. +2 compra duas e pula; +4 pode ser desafiado; inverter muda o sentido e pular passa a vez. Não há empilhamento. Marque UNO ao jogar a penúltima carta ou diga antes de ser denunciado. Vence quem esvazia a mão.',
 'tic-tac-toe':'X começa. Alterne jogadas em casas vazias. Três símbolos em linha, coluna ou diagonal vencem; tabuleiro cheio sem vencedor empata.',
 'checkers-brazilian':'12 peças por lado. Brancas (X) começam. Pedras andam uma casa para frente e capturam para os dois lados. Damas deslizam na diagonal. Captura é obrigatória pela sequência que toma mais peças. Clique na origem e em cada pouso destacado; envie a sequência completa. Peças capturadas bloqueiam o caminho até o fim. Pedra só promove se terminar na última fileira. Empates automáticos por repetição e limites de finais; consulte docs/DAMAS.md.',
 'checkers-english':'12 peças por lado. Vermelhas (X) começam. Pedras andam e capturam somente para frente. Damas andam uma casa e capturam para os dois lados. Toda captura é obrigatória; você escolhe a sequência e deve terminá-la. Ao chegar à última fileira, a pedra vira dama e encerra o turno. Repetição tripla ou 40 lances por jogador sem captura nem movimento de pedra empatam.',
 'ludo':'De 2 a 4 jogadores, quatro peças cada. Tire 6 para sair da base; o 6 dá outra jogada e três 6 seguidos encerram o turno. Capturas devolvem a peça à base, casas seguras protegem e a chegada exige número exato. No Power Mode, poderes ficam bloqueados nos dois primeiros turnos.'
};
function sideName(s,side){if(s.gameId==='ludo'||s.gameId==='uno')return ({red:'Vermelho',green:'Verde',yellow:'Amarelo',blue:'Azul'})[side]||'…';return s.gameId==='tic-tac-toe'?side || '…':s.gameId==='checkers-english'?(side==='X'?'Vermelhas':'Brancas'):(side==='X'?'Brancas':'Pretas');}
function eventText(e){return ({roll:`Dado: ${e.value}.`,move:`Peça ${e.token+1} movida${e.captured?.length?' e capturou '+e.captured.length:''}.`,power:`Poder ${e.power} ativado.`,pass:'Sem movimento válido.','frozen-skip':'Jogador congelado perdeu a vez.','triple-six':'Três números 6: turno perdido.'})[e.type]||'Turno atualizado.';}
function variantHint(){$('variantHint').textContent=rules[$('gameChoice').value];$('ludoOptions').hidden=$('gameChoice').value!=='ludo';}
$('gameChoice').onchange=variantHint;variantHint();
