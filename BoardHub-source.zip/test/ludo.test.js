import test from 'node:test';
import assert from 'node:assert/strict';
import {createState,startGame,applyAction,legalActions,START} from '../server/src/games/ludo/index.js';
const action=(s,color,data,rng=()=>0)=>applyAction(s,color,{round:s.round,revision:s.revision,...data},rng);
const ready=(mode='power',acquisition='fixed',colors=['red','green'])=>startGame(createState(1,{mode,acquisition}),colors);
const unlock=s=>{for(const p of s.players)p.turnsTaken=2;return s;};

test('inicia Ludo para 2, 3 e 4 jogadores com quatro peças',()=>{
 for(const n of [2,3,4]){const s=ready('classic','fixed',['red','green','yellow','blue'].slice(0,n));assert.equal(s.players.length,n);assert.ok(s.players.every(p=>p.tokens.join(',')==='-1,-1,-1,-1'));}
 assert.throws(()=>startGame(createState(),['red']));assert.throws(()=>startGame(createState(),['red','red']));
});
test('dado é produzido no servidor e seis libera peça',()=>{
 let s=ready('classic');s=action(s,'red',{type:'roll'},()=>5);assert.equal(s.die,6);
 assert.deepEqual(legalActions(s,'red').filter(a=>a.type==='move'),[{type:'move',token:0,to:0},{type:'move',token:1,to:0},{type:'move',token:2,to:0},{type:'move',token:3,to:0}]);
 s=action(s,'red',{type:'move',token:0,to:0});assert.equal(s.players[0].tokens[0],0);assert.equal(s.phase,'postMove');
 s=action(s,'red',{type:'end-turn'});assert.equal(s.players[s.turnIndex].color,'red');
});
test('três seis consecutivos perdem o turno',()=>{
 let s=ready('classic');s.players[0].tokens[0]=0;
 for(let i=0;i<2;i++){s=action(s,'red',{type:'roll'},()=>5);s=action(s,'red',{type:'move',token:0,to:s.players[0].tokens[0]+6});s=action(s,'red',{type:'end-turn'});}
 s=action(s,'red',{type:'roll'},()=>5);assert.equal(s.lastEvent.type,'triple-six');assert.equal(s.players[s.turnIndex].color,'green');
});
test('chegada exige número exato e quatro peças na chegada vencem',()=>{
 let s=ready('classic');s.players[0].tokens=[56,57,57,57];s=action(s,'red',{type:'roll'},()=>1);
 assert.equal(legalActions(s,'red').some(a=>a.type==='move'),false);s=action(s,'red',{type:'pass'});assert.equal(s.winner,null);
 s.turnIndex=0;s.phase='roll';s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:57});assert.equal(s.winner,'red');
});
test('captura devolve à base e escudo bloqueia captura',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=4;s.players[1].tokens[0]=(5-START.green+52)%52;
 s=action(s,'red',{type:'power',power:'shield',token:0});assert.equal(s.players[0].inventory.shield,1);
 // Avança até o verde e mantém o escudo da peça vermelha para testar imunidade no mesmo ciclo.
 s.turnIndex=1;s.phase='roll';s.die=null;s.effectiveDie=null;s.players[1].tokens[0]=(4-START.green+52)%52;s.players[0].tokens[0]=5;
 s=action(s,'green',{type:'roll'},()=>0);s=action(s,'green',{type:'move',token:0,to:s.players[1].tokens[0]+1});assert.equal(s.players[0].tokens[0],5);
 // Sem escudo, captura ocorre.
 s.players[0].shield=null;s.turnIndex=1;s.phase='roll';s.players[1].tokens[0]=(4-START.green+52)%52;
 s=action(s,'green',{type:'roll'},()=>0);s=action(s,'green',{type:'move',token:0,to:s.players[1].tokens[0]+1});assert.equal(s.players[0].tokens[0],-1);
});
test('Double Distance com 6 é rejeitado sem consumo',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=0;s=action(s,'red',{type:'roll'},()=>5);const before=s.players[0].inventory.double;
 assert.throws(()=>action(s,'red',{type:'power',power:'double'}),/dado 6/);assert.equal(s.players[0].inventory.double,before);
});
test('Dice Control aceita 1–5 e rejeita 6',()=>{
 let s=unlock(ready());s=action(s,'red',{type:'power',power:'control',value:4});assert.equal(s.die,4);assert.equal(s.players[0].inventory.control,0);
 let t=unlock(ready());assert.throws(()=>action(t,'red',{type:'power',power:'control',value:6}));
});
test('Freeze rejeita alvo congelado e faz perder próximo turno',()=>{
 let s=unlock(ready());s=action(s,'red',{type:'power',power:'freeze',target:'green'});assert.equal(s.players[1].frozen,1);
 assert.throws(()=>action({...s,phase:'roll'},'red',{type:'power',power:'freeze',target:'green'}),/já está congelado/);
 s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'pass'});assert.equal(s.players[s.turnIndex].color,'red');assert.equal(s.players[1].frozen,0);
});
test('Teleport rejeita chegada e casas ocupadas; não captura',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=0;s.players[1].tokens[0]=0;s=action(s,'red',{type:'roll'},()=>0);
 assert.throws(()=>action(s,'red',{type:'power',power:'teleport',token:0,cell:52}),/chegada/);
 assert.throws(()=>action(s,'red',{type:'power',power:'teleport',token:0,cell:START.green}));
 s=action(s,'red',{type:'power',power:'teleport',token:0,cell:12});assert.equal(s.players[0].tokens[0],12);assert.equal(s.phase,'postMove');
});
test('poder fora do turno, sem inventário e nos dois primeiros turnos é rejeitado',()=>{
 let s=ready();assert.throws(()=>action(s,'red',{type:'power',power:'control',value:3}),/dois primeiros/);
 assert.throws(()=>action(s,'green',{type:'roll'}),/Aguarde/);
 s=unlock(s);s.players[0].inventory.control=0;assert.throws(()=>action(s,'red',{type:'power',power:'control',value:3}),/indisponível/);
});
test('Bonus Roll concede uma rolagem e não encadeia',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=0;s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:1});
 s=action(s,'red',{type:'power',power:'bonus'});assert.equal(s.phase,'roll');assert.equal(s.players[s.turnIndex].color,'red');
 s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:2});assert.equal(legalActions(s,'red').some(a=>a.power==='bonus'),false);
});
test('aquisição por casa especial respeita limite três e captura remove poder',()=>{
 let s=unlock(ready('power','cells'));s.players[0].tokens[0]=4;s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:5},()=>0);
 assert.equal(s.players[0].inventory.double,1);
 s.players[0].inventory={double:1,control:1,shield:1};s.phase='roll';s.turnIndex=0;s.players[0].tokens[0]=4;s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:5},()=>1);assert.equal(Object.values(s.players[0].inventory).reduce((a,b)=>a+b,0),3);
});
test('estado e inventário do cliente não podem ser adulterados',()=>{
 const s=unlock(ready()),before=structuredClone(s);
 assert.throws(()=>applyAction(s,'red',{type:'roll',round:1,revision:999,die:6}));assert.deepEqual(s,before);
});
