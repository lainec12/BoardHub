/**
 * Ludo autoritativo para 2–4 jogadores.
 * O cliente nunca informa dado, captura, prêmio aleatório ou inventário.
 */
export const COLORS=['red','green','yellow','blue'];
export const START={red:0,green:13,yellow:26,blue:39};
export const SAFE=new Set([0,8,13,21,26,34,39,47]);
export const POWER_CELLS=new Set([5,18,31,44]);
export const POWERS=['double','control','shield','bonus','freeze','teleport'];
const FIXED={double:2,control:1,shield:2,bonus:2,freeze:1,teleport:1};

const clone=value=>structuredClone(value);
const randomIndex=(length,rng)=>Math.max(0,Math.min(length-1,Number(rng(length))||0));
const globalCell=(color,progress)=>progress>=0&&progress<52?(START[color]+progress)%52:null;
const totalInventory=inv=>POWERS.reduce((sum,p)=>sum+(inv[p]||0),0);
const playerOf=(state,color)=>state.players.find(p=>p.color===color);
const current=state=>state.players[state.turnIndex];
const assertVersion=(s,a)=>{if(a.round!==s.round||a.revision!==s.revision)throw Error('Ação desatualizada.');};

export function createState(round=1,options={}) {
  const mode=options.mode==='power'?'power':'classic';
  const acquisition=options.acquisition==='cells'?'cells':'fixed';
  return {variant:'ludo',mode,acquisition,round,revision:0,players:[],turnIndex:0,
    phase:'waiting',die:null,effectiveDie:null,sixes:0,powerUsed:false,bonusChainBlocked:false,
    winner:null,reason:null,lastEvent:null,ranking:[]};
}

export function startGame(state,colors) {
  if(!Array.isArray(colors)||colors.length<2||colors.length>4||new Set(colors).size!==colors.length||colors.some(c=>!COLORS.includes(c)))throw Error('O Ludo exige de 2 a 4 cores diferentes.');
  const next=clone(state);
  next.players=colors.map(color=>({color,tokens:[-1,-1,-1,-1],inventory:next.mode==='power'&&next.acquisition==='fixed'?clone(FIXED):{},turnsTaken:0,frozen:0,shield:null}));
  next.phase='roll';next.turnIndex=0;next.revision++;return next;
}

function tokenMoves(state,player,value) {
  if(!Number.isInteger(value)||value<1)return [];
  const moves=[];
  player.tokens.forEach((progress,token)=>{
    if(progress===57)return;
    if(progress===-1){if(value===6)moves.push({token,to:0});return;}
    const to=progress+value;if(to<=57)moves.push({token,to});
  });
  return moves;
}

export function legalActions(state,color) {
  if(state.winner||state.phase==='waiting'||current(state)?.color!==color)return [];
  const p=current(state),base=[];
  if(state.phase==='roll')base.push({type:'roll'});
  if(state.phase==='move')base.push(...tokenMoves(state,p,state.effectiveDie).map(m=>({type:'move',...m})));
  if(state.phase==='move'&&!tokenMoves(state,p,state.effectiveDie).length)base.push({type:'pass'});
  if(state.phase==='postMove')base.push({type:'end-turn'});
  if(state.mode==='power'&&p.turnsTaken>=2){
    if(state.phase==='roll'&&!state.powerUsed&&(p.inventory.control||0)>0)for(let value=1;value<=5;value++)base.push({type:'power',power:'control',value});
    if(state.phase==='roll'&&!state.powerUsed&&(p.inventory.freeze||0)>0)for(const q of state.players)if(q.color!==color&&!q.frozen)base.push({type:'power',power:'freeze',target:q.color});
    if(['roll','move'].includes(state.phase)&&!state.powerUsed&&(p.inventory.shield||0)>0)p.tokens.forEach((v,token)=>{if(v!==57&&p.shield?.token!==token)base.push({type:'power',power:'shield',token});});
    if(state.phase==='move'&&!state.powerUsed&&(p.inventory.double||0)>0&&state.die!==6)base.push({type:'power',power:'double'});
    if(state.phase==='move'&&!state.powerUsed&&(p.inventory.teleport||0)>0){
      const occupied=new Set(state.players.flatMap(q=>q.tokens.map(v=>globalCell(q.color,v)).filter(v=>v!==null)));
      p.tokens.forEach((v,token)=>{if(v>=0&&v<52)for(let cell=0;cell<52;cell++)if(!occupied.has(cell))base.push({type:'power',power:'teleport',token,cell});});
    }
    if(state.phase==='postMove'&&!state.bonusChainBlocked&&(p.inventory.bonus||0)>0)base.push({type:'power',power:'bonus'});
  }
  return base;
}

function matches(candidate,action){return Object.entries(candidate).every(([k,v])=>action[k]===v);}
function consume(player,power){if((player.inventory[power]||0)<1)throw Error('Poder indisponível no inventário.');player.inventory[power]--;}
function randomPower(player,rng){
  if(totalInventory(player.inventory)>=3)return null;
  const power=POWERS[randomIndex(POWERS.length,rng)];player.inventory[power]=(player.inventory[power]||0)+1;return power;
}
function loseRandomPower(player,rng){
  const bag=POWERS.filter(p=>(player.inventory[p]||0)>0);if(!bag.length)return null;
  const power=bag[randomIndex(bag.length,rng)];player.inventory[power]--;return power;
}
function rank(state){return [...state.players].sort((a,b)=>b.tokens.filter(v=>v===57).length-a.tokens.filter(v=>v===57).length).map((p,i)=>({position:i+1,color:p.color,home:p.tokens.filter(v=>v===57).length}));}
function beginTurn(state,index){
  state.turnIndex=index%state.players.length;const p=current(state);
  if(p.shield)p.shield=null;
  if(p.frozen>0){p.frozen--;p.turnsTaken++;state.lastEvent={type:'frozen-skip',color:p.color};return beginTurn(state,(state.turnIndex+1)%state.players.length);}
  state.phase='roll';state.die=null;state.effectiveDie=null;state.sixes=0;state.powerUsed=false;state.bonusChainBlocked=false;
}
function finishTurn(state,extra=false){
  const p=current(state);p.turnsTaken++;
  if(extra){state.phase='roll';state.die=null;state.effectiveDie=null;state.powerUsed=false;return;}
  beginTurn(state,state.turnIndex+1);
}
function afterMove(state,rolledSix){
  state.phase='postMove';
  if(rolledSix){state.lastEvent={...state.lastEvent,extraRoll:true};}
}

export function applyAction(state,color,action,rng=n=>Math.floor(Math.random()*n)) {
  if(state.winner)throw Error('A partida terminou.');assertVersion(state,action);
  const p=current(state);if(!p||p.color!==color)throw Error('Aguarde sua vez.');
  const allowed=legalActions(state,color);if(!allowed.some(a=>matches(a,action))) {
    if(action.type==='power'&&state.mode!=='power')throw Error('Poderes não existem no modo clássico.');
    if(action.type==='power'&&p.turnsTaken<2)throw Error('Poderes bloqueados nos dois primeiros turnos.');
    if(action.type==='power'&&action.power==='freeze'&&playerOf(state,action.target)?.frozen)throw Error('O jogador já está congelado.');
    if(action.type==='power'&&action.power==='teleport'&&action.cell>=52)throw Error('Teleporte não entra na chegada.');
    if(action.type==='power'&&!(p.inventory[action.power]||0))throw Error('Poder indisponível no inventário.');
    if(action.type==='power'&&action.power==='double'&&state.die===6)throw Error('Double Distance não pode ser usado com dado 6.');
    throw Error('Ação ilegal nesta fase.');
  }
  const next=clone(state),me=current(next);next.revision++;
  if(action.type==='roll'){
    const value=randomIndex(6,rng)+1;next.die=value;next.effectiveDie=value;
    if(value===6&&++next.sixes===3){next.lastEvent={type:'triple-six',color};finishTurn(next);return next;}
    next.phase='move';next.lastEvent={type:'roll',color,value};return next;
  }
  if(action.type==='power'){
    consume(me,action.power);
    if(action.power==='control'){next.die=action.value;next.effectiveDie=action.value;next.phase='move';next.powerUsed=true;next.lastEvent={type:'power',power:'control',color,value:action.value};}
    if(action.power==='double'){next.effectiveDie=next.die*2;next.powerUsed=true;next.lastEvent={type:'power',power:'double',color,value:next.effectiveDie};}
    if(action.power==='shield'){me.shield={token:action.token};next.powerUsed=true;next.lastEvent={type:'power',power:'shield',color,token:action.token};}
    if(action.power==='freeze'){playerOf(next,action.target).frozen=1;next.powerUsed=true;next.lastEvent={type:'power',power:'freeze',color,target:action.target};}
    if(action.power==='teleport'){
      const relative=(action.cell-START[color]+52)%52;me.tokens[action.token]=relative;next.powerUsed=true;next.lastEvent={type:'power',power:'teleport',color,token:action.token,cell:action.cell};afterMove(next,false);
    }
    if(action.power==='bonus'){next.bonusChainBlocked=true;next.phase='roll';next.die=null;next.effectiveDie=null;next.powerUsed=false;next.lastEvent={type:'power',power:'bonus',color};}
    return next;
  }
  if(action.type==='pass'){next.lastEvent={type:'pass',color};finishTurn(next,next.die===6);return next;}
  if(action.type==='end-turn'){finishTurn(next,!!next.lastEvent?.extraRoll);return next;}
  if(action.type==='move'){
    const from=me.tokens[action.token];me.tokens[action.token]=action.to;
    const cell=globalCell(color,action.to),captured=[];
    if(cell!==null&&!SAFE.has(cell))for(const q of next.players)if(q.color!==color)q.tokens.forEach((progress,token)=>{
      if(globalCell(q.color,progress)===cell&&q.shield?.token!==token){q.tokens[token]=-1;captured.push({color:q.color,token,lostPower:next.mode==='power'?loseRandomPower(q,rng):null});}
    });
    let gained=null;if(next.mode==='power'&&next.acquisition==='cells'&&POWER_CELLS.has(cell))gained=randomPower(me,rng);
    next.lastEvent={type:'move',color,token:action.token,from,to:action.to,cell,captured,gained};
    if(me.tokens.every(v=>v===57)){next.winner=color;next.reason='quatro peças chegaram';next.ranking=rank(next);return next;}
    afterMove(next,next.die===6);return next;
  }
  throw Error('Ação desconhecida.');
}
