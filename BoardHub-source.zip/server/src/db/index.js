// SQLite nativo do Node 24: placar e histórico sobrevivem ao reinício do processo.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
export function openDatabase(path) {
  if(path!==':memory:') mkdirSync(dirname(path),{recursive:true});
  const db=new DatabaseSync(path);
  db.exec(`PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS results (
      room TEXT NOT NULL, round INTEGER NOT NULL, winner TEXT NOT NULL,
      reason TEXT NOT NULL, finished_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(room,round));
    CREATE TABLE IF NOT EXISTS scores (
      room TEXT NOT NULL, player TEXT NOT NULL, name TEXT NOT NULL,
      wins INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(room,player));`);
  return {
    authInit(){db.exec('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL); CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, value TEXT NOT NULL, expires INTEGER NOT NULL)');},
    upsertUser(id,name){db.prepare('INSERT INTO users(id,name) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').run(id,name);return {id,name};},
    getUser(id){return db.prepare('SELECT id,name FROM users WHERE id=?').get(id);},
    getSession(id){const row=db.prepare('SELECT value FROM sessions WHERE id=? AND expires>?').get(id,Date.now());return row?JSON.parse(row.value):null;},
    setSession(id,value){db.prepare('DELETE FROM sessions WHERE expires<=?').run(Date.now());db.prepare('INSERT OR REPLACE INTO sessions(id,value,expires) VALUES(?,?,?)').run(id,JSON.stringify(value),new Date(value.cookie.expires||Date.now()+86400000).getTime());},
    deleteSession(id){db.prepare('DELETE FROM sessions WHERE id=?').run(id);},
    roomExists(room) {return !!db.prepare('SELECT 1 FROM scores WHERE room=? LIMIT 1').get(room);},
    register(room,p) {db.prepare('INSERT OR IGNORE INTO scores(room,player,name) VALUES(?,?,?)').run(room,p.id,p.name);},
    finish(room,game,players) {
      db.exec('BEGIN');
      try {
        const saved=db.prepare('INSERT OR IGNORE INTO results(room,round,winner,reason) VALUES(?,?,?,?)').run(room,game.round,game.winner,game.reason);
        const winner=players.find(p=>p.mark===game.winner);
        if(saved.changes && winner) db.prepare('UPDATE scores SET wins=wins+1 WHERE room=? AND player=?').run(room,winner.id);
        db.exec('COMMIT');
      } catch(e) {db.exec('ROLLBACK');throw e;}
    },
    score(room) {return db.prepare('SELECT player,name,wins FROM scores WHERE room=? ORDER BY wins DESC').all(room);},
    history(room) {return db.prepare('SELECT round,winner,reason,finished_at FROM results WHERE room=? ORDER BY round DESC LIMIT 20').all(room);},
    close() {db.close();}
  };
}
