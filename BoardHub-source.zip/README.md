# BoardHub 💜

Coleção web multiplayer com seis jogos, lobby roxo/lilás, convites, chat, reconexão e perfil Google único. Projeto independente dos demais repositórios da conta.

| Jogo | Jogadores | Recursos |
| --- | --- | --- |
| Jogo da Velha | 2 | Vitória, empate e revanche |
| Damas | 2 | Variantes Brasileira e Inglesa |
| Ludo | 2–4 | Clássico e Power Mode com seis poderes |
| UNO | 2–4 | Mãos privadas, cartas especiais e desafio +4 |
| Batalha Naval | 2 | Posicionamento secreto e tiros alternados |
| Xadrez | 2 | Xeque/mate, roque, en passant e promoção |

## Rodar

Instale Node.js 24+, abra o terminal nesta pasta e execute:

```bash
npm ci
npm test
npm start
```

Abra http://localhost:3000. Para desenvolvimento, `npm run dev`. Dois navegadores ou janelas anônimas permitem testar a sala localmente. Convites em localhost não são acessíveis de outros computadores. Acesso entre cidades exige servidor hospedado.

## Perfil Google e configuração

Quando configurado, o Google é obrigatório para acessar os jogos. O perfil fica salvo no SQLite e a sessão dura até 30 dias no navegador. Limpar cookies, sair ou mudar de aparelho exige novo login com o mesmo perfil. Sem credenciais, funciona em modo de desenvolvimento por apelido.

| Variável | Finalidade |
| --- | --- |
| PORT | Porta do servidor; padrão 3000 |
| DB_PATH | SQLite; padrão ./data/boardhub.sqlite |
| PUBLIC_URL | Origem pública HTTPS; local http://localhost:3000 |
| GOOGLE_CLIENT_ID | Cliente OAuth Google |
| GOOGLE_CLIENT_SECRET | Segredo OAuth, apenas no servidor |
| SESSION_SECRET | Segredo aleatório de pelo menos 32 caracteres |
| TRUST_PROXY | 1 somente atrás de um proxy confiável |
| CLIENT_ORIGIN | Origens adicionais permitidas, separadas por vírgula |

Copie .env.example para .env e use `node --env-file=.env server.js`, ou configure as variáveis no painel da hospedagem. Não envie .env ao GitHub.

## Arquitetura e código

JavaScript modular sem build no cliente; Node/Express/Socket.io no servidor. Motores em `server/src/games`, interface em `client/public`, SQLite em `server/src/db`, autenticação em `server/src/auth.js` e testes em `test`. Todas as jogadas são validadas no servidor. Mãos e frotas são filtradas por socket. Rate limit: dez eventos por segundo por conexão.

Salas de seis caracteres, convite `/join/CODIGO`, anfitrião com início/reinício/expulsão e chat exclusivo. Desconexão pausa a partida por até 60 segundos. Saída em partidas com mais de dois participantes encerra como empate. Placar é por sala/identidade de partida; perfil único não equivale a ranking global.

SQLite preserva perfis, sessões e resultados. Salas/partidas ativas e chat ficam em memória e se encerram ao reiniciar o servidor. Use uma instância e disco persistente. Dependências externas npm: Express, Socket.io, Passport, estratégia Google, express-session, chess.js; socket.io-client para testes. Sem CDN obrigatória.

## Documentação e validação

- [Damas](docs/DAMAS.md)
- [Ludo](docs/LUDO.md)
- [UNO](docs/UNO.md)
- [Batalha Naval](docs/BATALHA-NAVAL.md)
- [Xadrez](docs/XADREZ.md)
- [Login Google](docs/LOGIN-GOOGLE.md)
- [Hospedagem e domínio](docs/DEPLOY.md)

69 testes automatizados aprovados localmente, incluindo clientes Socket.io reais. GitHub Actions executa a suíte a cada push/PR. O login real Google precisa de credenciais e callback. Conferência visual em navegador e auditoria formal de acessibilidade permanecem pendentes; não há certificação WCAG. A coleção usa adaptações casuais documentadas, sem relógios de torneio.

Próximas evoluções: ranking global, torneios, bots, replay, PostgreSQL e recuperação de salas após reinício.
