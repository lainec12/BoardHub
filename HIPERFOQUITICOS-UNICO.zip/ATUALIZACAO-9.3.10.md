# 9.3.10 — nitidez Retina e enquadramento das mesas

- Detecção de aparelho com poucos núcleos reduz animações, sem forçar o tabuleiro Retina a 1x. Qualidade automática inicia até 2x; alta nitidez explícita até 3x.
- Redução adaptativa limitada a 1,5x em Retina durante movimento; ao ficar parado recupera a resolução original. Alta nitidez explícita mantém resolução.
- Corpo, cabeça e anel de cada peão reunidos em uma geometria reutilizável, preservando dimensões e posições: 16 chamadas para os peões completos, antes 48.
- Câmera e enquadramento do Ludo preservados.
- Demais mesas passam a usar a largura disponível, retirando a coluna vazia reservada ao antigo chat.
- Avatares ficam ancorados à arena, com margens próprias acima e abaixo da área jogável.
- Velha sem altura mínima artificial; Damas e Xadrez com quadrados flexíveis, sem mínimo de 352px que cortava telas estreitas.
- Naval com dois oceanos lado a lado no computador e empilhados em telas menores, grids completos sem deslocamento horizontal.
- UNO preserva rolagem apenas na mão de cartas e mantém monte/descarte centrados.

Build e testes automatizados verificam integridade e regras; desempenho em aparelho físico precisa de confirmação em uso real.

- Conferência visual de notebook: redução das margens e reserva vertical de 440px para HUD e controles nas mesas quadradas.
