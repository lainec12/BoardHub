# Atualização 9.2.6

- Marcas permanentes das bases agora são círculos simples e suaves, sem anel ou desenho interno, com 18% de opacidade.
- Todas as oito estrelas seguras são sombras planas suaves, sem dourado, relevo ou brilho.
- Posições, simetria, permanência das marcas e regras de proteção preservadas nas interfaces 3D e alternativa.
