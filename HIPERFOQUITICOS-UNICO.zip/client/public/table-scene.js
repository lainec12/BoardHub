export function createTableScene(){return {update(){},dispose(){}};}
