import * as T from './vendor/three.module.js';
// Adapter visual. Cliques acionam os controles existentes; nenhuma regra é decidida aqui.
export function createTableScene(root){
 const host=document.createElement('div');host.className='table-3d';root.before(host);let current,renderer,scene,camera,frame,resize,targets=[],scheduled=false,disposed=false;
 const ray=new T.Raycaster(),pointer=new T.Vector2();
 const mat=(color)=>new T.MeshStandardMaterial({color,roughness:.33,metalness:.13});
 function mesh(geometry,color,x,y,z,parent=scene){const m=new T.Mesh(geometry,mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
 const box=(w,h,d,color,x,y,z)=>mesh(new T.BoxGeometry(w,h,d),color,x,y,z);
 function label(text,bg='#fff6df',fg='#30233c'){
  const c=document.createElement('canvas');c.width=256;c.height=384;const x=c.getContext('2d');x.fillStyle=bg;x.fillRect(0,0,256,384);x.strokeStyle='#fff';x.lineWidth=16;x.strokeRect(8,8,240,368);x.save();x.translate(128,192);x.rotate(-.24);x.fillStyle='#ffffffcc';x.beginPath();x.ellipse(0,0,85,130,0,0,Math.PI*2);x.fill();x.restore();x.fillStyle=fg;x.font='bold 75px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText(text,128,192,225);const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;return texture;
 }
 function clear(){if(!scene)return;scene.traverse(o=>{o.geometry?.dispose();const materials=Array.isArray(o.material)?o.material:[o.material];for(const m of materials){m?.map?.dispose();m?.dispose();}});scene.clear();targets=[];}
 function bind(m,button){m.userData.button=button;targets.push(m);}
 function piece(type,color,x,z){const group=new T.Group();scene.add(group);group.position.set(x,.2,z);const ivory=color==='white';const paint=ivory?0xfff1d2:0x25202a;const cylinder=(a,b,h,y)=>mesh(new T.CylinderGeometry(a,b,h,32),paint,0,y,0,group);
  cylinder(.32,.38,.13,.08);cylinder(.23,.31,.12,.2);cylinder(.12,.24,.48,.48);
  if(type==='p')mesh(new T.SphereGeometry(.21,24,16),paint,0,.83,0,group);
  if(type==='r'){cylinder(.29,.19,.22,.82);for(let i=0;i<4;i++){const a=i*Math.PI/2;mesh(new T.BoxGeometry(.13,.18,.13),paint,Math.cos(a)*.2,1.01,Math.sin(a)*.2,group);}}
  if(type==='b'){const head=mesh(new T.SphereGeometry(.22,24,16),paint,0,.87,0,group);head.scale.y=1.45;mesh(new T.SphereGeometry(.07,16,12),paint,0,1.19,0,group);}
  if(type==='q'||type==='k'){cylinder(.23,.16,.2,.85);if(type==='q'){for(let i=0;i<6;i++){const a=i*Math.PI/3;mesh(new T.SphereGeometry(.06,12,10),paint,Math.cos(a)*.19,1.08,Math.sin(a)*.19,group);}}else{mesh(new T.BoxGeometry(.09,.38,.09),paint,0,1.15,0,group);mesh(new T.BoxGeometry(.29,.09,.09),paint,0,1.2,0,group);}}
  if(type==='n'){const neck=mesh(new T.BoxGeometry(.24,.48,.28),paint,0,.84,0,group);neck.rotation.z=-.25;mesh(new T.BoxGeometry(.29,.22,.43),paint,.05,1.1,.1,group);for(const x of [-.09,.09])mesh(new T.ConeGeometry(.06,.2,8),paint,x,1.29,0,group);}
  return group;
 }
 function rebuild(){scheduled=false;if(disposed||!current||current.gameId==='ludo'){host.hidden=true;root.classList.remove('has-3d');return;}
  const id=current.gameId;host.hidden=false;
  try{if(!renderer){renderer=new T.WebGLRenderer({antialias:true,alpha:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;host.append(renderer.domElement);const controls=document.createElement('button');controls.className='secondary scene-access';controls.textContent='Abrir controles e tabuleiro acessível';controls.onclick=()=>{const open=root.classList.toggle('show-controls');controls.textContent=open?'Recolher controles acessíveis':'Abrir controles e tabuleiro acessível';};host.append(controls);renderer.domElement.setAttribute('aria-label','Mesa 3D. Controles acessíveis disponíveis abaixo.');scene=new T.Scene();camera=new T.PerspectiveCamera(38,1,.1,100);resize=new ResizeObserver(size);resize.observe(host);renderer.domElement.addEventListener('pointerup',pick);loop();}}catch(e){host.hidden=true;return;}
  if(!root.classList.contains('has-3d'))root.classList.add('has-3d');clear();scene.add(new T.HemisphereLight(0xf0deff,0x253651,2.5));const light=new T.DirectionalLight(0xffe4bd,4);light.position.set(-5,13,6);light.castShadow=true;light.shadow.mapSize.set(1024,1024);light.shadow.camera.left=-12;light.shadow.camera.right=12;light.shadow.camera.top=12;light.shadow.camera.bottom=-12;scene.add(light);
  let extent=10;
  if(id==='uno'){
   extent=14;box(14,.4,10,0x493027,0,-.5,0);box(13.7,.1,9.7,0x176443,0,-.24,0);
   for(let i=0;i<5;i++)box(1.35,.035,2,0x222233,-1.3,i*.04,0);
   const top=current.game.top;if(top){const colors={red:'#c72d3e',green:'#25844b',blue:'#2d63b1',yellow:'#e9c43c'};const card=new T.Mesh(new T.BoxGeometry(1.35,.07,2),[mat(0xfffaf1),mat(0xfffaf1),new T.MeshStandardMaterial({map:label(String(top.value),colors[top.color]||'#29263a')}),mat(0xfffaf1),mat(0xfffaf1),mat(0xfffaf1)]);card.position.set(1,.02,0);scene.add(card);}
   const buttons=[...root.querySelectorAll('.uno-card')],colors={red:'#c72d3e',green:'#25844b',blue:'#2d63b1',yellow:'#e9c43c',wild:'#29263a'};
   // Cartes limitées à une page visuelle; la main complète reste dans les contrôles HTML.
   buttons.slice(0,14).forEach((b,i)=>{const color=Object.keys(colors).find(c=>b.classList.contains(c))||'wild';const card=new T.Mesh(new T.BoxGeometry(1.1,.07,1.7),[mat(0xffffff),mat(0xffffff),new T.MeshStandardMaterial({map:label(b.textContent,colors[color])}),mat(0xffffff),mat(0xffffff),mat(0xffffff)]);card.position.set((i-(Math.min(14,buttons.length)-1)/2)*.72,.1,3.2);card.rotation.y=(i-(buttons.length-1)/2)*.018;card.castShadow=true;scene.add(card);bind(card,b);});
  }else if(id==='battleship'){
   extent=14;[...root.querySelectorAll('.naval-grid')].forEach((grid,g)=>{const ox=g?3.4:-3.4;box(6.3,.3,6.3,0x2a5074,ox,-.25,0);[...grid.children].forEach((b,i)=>{const x=ox+(i%10-4.5)*.59,z=(Math.floor(i/10)-4.5)*.59;const tile=box(.56,.07,.56,0x237baf,x,-.04,z);bind(tile,b);if(b.classList.contains('ship')){box(.43,.16,.5,0x758393,x,.08,z);box(.2,.15,.25,0xaab3bf,x,.23,z);}if(b.classList.contains('hit')||b.classList.contains('sunk')||b.classList.contains('water')){mesh(new T.SphereGeometry(.13,16,12),b.classList.contains('water')?0xf0f5ff:0xef4c4d,x,.22,z);}});});
  }else{
   const isTic=id==='tic-tac-toe',n=isTic?3:8,buttons=[...root.querySelectorAll(isTic?'.cell':id==='chess'?'.chess-square':'.square')];extent=isTic?6:10;box(n+.6,.4,n+.6,0x704725,0,-.35,0);box(n+.35,.08,n+.35,0xc99d59,0,-.1,0);
   buttons.forEach((b,i)=>{const x=i%n-(n-1)/2,z=Math.floor(i/n)-(n-1)/2;const color=b.classList.contains('selected')?0xc6ae66:b.classList.contains('target')||b.classList.contains('destination')?0x9dab78:(Math.floor(i/n)+i%n)%2?0x966c47:0xf2dcba;const tile=box(.96,.12,.96,color,x,0,z);bind(tile,b);
    if(isTic){const value=b.textContent.trim();if(value==='O'){const ring=mesh(new T.TorusGeometry(.28,.095,16,32),0xd73d50,x,.24,z);ring.rotation.x=-Math.PI/2;bind(ring,b);}if(value==='X')for(const angle of [-Math.PI/4,Math.PI/4]){const bar=box(.15,.16,.73,0x2c77c6,x,.22,z);bar.rotation.y=angle;bind(bar,b);}}
    else if(id==='chess'){const glyph=b.firstChild?.textContent?.trim();const symbols='♔♕♖♗♘♙♚♛♜♝♞♟';const k=symbols.indexOf(glyph);if(k>=0){const group=piece(['k','q','r','b','n','p'][k%6],k<6?'white':'black',x,z);group.traverse(o=>{if(o.isMesh)bind(o,b);});}}
    else{const token=b.querySelector('.checker');if(token){const white=token.classList.contains('side-X'),color=white?0xf5e8cd:0x28212a;const disk=mesh(new T.CylinderGeometry(.34,.36,.17,32),color,x,.18,z);bind(disk,b);if(token.textContent.includes('♛'))bind(mesh(new T.CylinderGeometry(.29,.31,.15,32),color,x,.34,z),b);}}
   });
  }
  camera.position.set(0,extent*1.35,extent*.95);camera.lookAt(0,0,0);size();
 }
 function size(){if(!renderer)return;const w=host.clientWidth;if(!w)return;const h=Math.round(w*.82);renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
 function pick(e){if(!renderer)return;const rect=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(targets,false)[0];const b=hit?.object.userData.button;if(b&&!b.disabled&&b.isConnected)b.click();}
 function loop(){frame=requestAnimationFrame(loop);if(renderer&&!host.hidden&&scene&&camera)renderer.render(scene,camera);}
 const queue=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(rebuild);}};const observer=new MutationObserver(queue);observer.observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['class','disabled']});
 return {update(state){current=state;queue();},dispose(){disposed=true;observer.disconnect();resize?.disconnect();cancelAnimationFrame(frame);clear();renderer?.dispose();host.remove();}};
}
