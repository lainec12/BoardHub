import {TRACK,STAR_ZONES,START_ZONES} from './ludo-map.js';
// x é coluna, y é linha. Tipos: 0 branca, 1 vermelha, 2 verde, 3 azul, 4 amarela, 5 estrela.
export const CELL_TYPES={white:0,red:1,green:2,blue:3,yellow:4,star:5};
export const LUDO_GRID=Array.from({length:15},()=>Array(15).fill(0));
for(const [color,x0,y0] of [['red',0,0],['green',9,0],['blue',0,9],['yellow',9,9]])for(let y=y0;y<y0+6;y++)for(let x=x0;x<x0+6;x++)LUDO_GRID[y][x]=CELL_TYPES[color];
for(const [row,col] of TRACK)LUDO_GRID[row][col]=0;
for(let n=1;n<=6;n++){LUDO_GRID[7][n]=1;LUDO_GRID[n][7]=2;LUDO_GRID[14-n][7]=3;LUDO_GRID[7][14-n]=4;}
for(const {x,y,color} of START_ZONES)LUDO_GRID[y][x]=CELL_TYPES[color];
for(const {x,y} of STAR_ZONES)LUDO_GRID[y][x]=5;
export const CELL_COLORS={0:'#ffffff',1:'#e44755',2:'#27a764',3:'#3185dc',4:'#edc13c',5:'#ffffff'};
for(const row of LUDO_GRID)Object.freeze(row);Object.freeze(LUDO_GRID);
