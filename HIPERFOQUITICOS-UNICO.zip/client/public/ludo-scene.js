export function createLudoScene(){return {update(){},dispose(){}};}
