// Coordenadas públicas (x=coluna, y=linha). Mesma fonte para renderização e servidor.
export const TRACK=[[6,1],[6,2],[6,3],[6,4],[6,5],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[9,8],[10,8],[11,8],[12,8],[13,8],[14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0],[7,0],[6,0]];
export const START={red:0,green:13,yellow:26,blue:39};
export const STAR_ZONES=[{color:'green',x:8,y:2},{color:'blue',x:6,y:12},{color:'red',x:2,y:6},{color:'yellow',x:12,y:8}];
export const START_ZONES=[{color:'blue',x:6,y:13},{color:'yellow',x:13,y:8},{color:'green',x:8,y:1},{color:'red',x:1,y:6}];
export const SAFE_ZONES=[...STAR_ZONES,...START_ZONES];
export const SAFE=new Set(SAFE_ZONES.map(({x,y})=>{const index=TRACK.findIndex(([row,col])=>row===y&&col===x);if(index<0)throw Error('Zona segura fora do caminho');return index;}));
