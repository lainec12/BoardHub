/** Renderizador de damas: usa somente caminhos legais calculados pelo servidor. */
export function createCheckersView(board,hint,send,controls={}) {
  let path=[],version=null,flipped=false,flight=false;
  let snapshot=null;
  const coord=i=>String.fromCharCode(97+i%8)+(8-Math.floor(i/8));
  const hasPrefix=(move,prefix)=>prefix.every((i,k)=>move.path[k]===i);
  function clear(){path=[];}
  function render(state,me,canPlay,options={}) {
    snapshot={state,me,canPlay};
    const game=state.game,key=state.code+':'+game.round+':'+game.ply;
    if(version!==key){version=key;path=[];flight=false;}
    board.className='checkers-board '+(game.variant==='english'?'english':'brazilian');
    board.setAttribute('aria-label',state.gameName+' · casas em coordenadas');
    const available=canPlay&&!flight?state.legalMoves:[];
    const matching=available.filter(m=>hasPrefix(m,path));
    const destinations=new Set(path.length?matching.map(m=>m.path[path.length]):[]);
    const sources=new Set(available.map(m=>m.path[0]));
    const focused=options.focus ?? document.activeElement?.dataset?.cell;
    // Prévia da sequência: não altera o estado canônico; o servidor só recebe a sequência completa.
    const preview=game.board.slice();
    if(path.length>1){const piece=preview[path[0]];preview[path[0]]=null;preview[path.at(-1)]=piece;}
    const ids=Array.from({length:64},(_,i)=>flipped?63-i:i);
    board.replaceChildren(...ids.map(i=>{
      const dark=(Math.floor(i/8)+i%8)%2===1,piece=preview[i];
      const el=document.createElement('button');el.type='button';el.dataset.cell=String(i);
      el.className='square '+(dark?'dark':'light')+(path.includes(i)?' selected':'')+(destinations.has(i)?' destination':'')+(game.lastMove?.path.includes(i)?' last-move':'');
      const pieceName=piece?(piece.side===me?'sua ':'adversária ')+(piece.king?'dama':'pedra'):'vazia';
      el.setAttribute('aria-label',`${coord(i)}: ${pieceName}${destinations.has(i)?', destino válido':''}${sources.has(i)?', pode jogar':''}`);
      el.setAttribute('aria-pressed',String(path.at(-1)===i));
      // Casas jogáveis seguem focáveis mesmo fora da vez, para leitura do tabuleiro.
      el.disabled=!dark;
      if(piece){const token=document.createElement('span');token.className='checker side-'+piece.side+(piece.king?' king35':'');token.textContent=piece.king?'♛':piece.side==='X'?'●':'○';token.setAttribute('aria-hidden','true');el.append(token);}
      const label=document.createElement('span');label.className='coordinate';label.textContent=coord(i);el.append(label);
      el.onclick=async()=>{
        if(!canPlay || flight)return;
        if(path.length && destinations.has(i)) {
          path.push(i);
          const candidates=available.filter(m=>hasPrefix(m,path));
          const complete=candidates.find(m=>m.path.length===path.length);
          if(complete){
            flight=true;render(state,me,canPlay,{focus:i});
            const sentVersion=version;
            const result=await send('game:action',{type:'move',path:[...path],round:game.round,ply:game.ply});
            if(!result?.ok && version===sentVersion){flight=false;clear();render(state,me,canPlay,{focus:i});}
          }else render(state,me,canPlay,{focus:i});
        }else if(sources.has(i)){path=[i];render(state,me,canPlay,{focus:i});}
      };
      // Setas: navigation spatiale, Tab reste disponible pour tous les contrôles.
      el.onkeydown=e=>{
        const delta={ArrowUp:-8,ArrowDown:8,ArrowLeft:-1,ArrowRight:1}[e.key];
        if(!delta)return;e.preventDefault();
        let pos=ids.indexOf(i),target=pos+delta;
        if(target<0 || target>=64 || ((e.key==='ArrowLeft'||e.key==='ArrowRight')&&Math.floor(pos/8)!==Math.floor(target/8)))return;
        if((Math.floor(ids[target]/8)+ids[target]%8)%2!==1)target+=delta;
        if(target>=0&&target<64)board.querySelector(`[data-cell="${ids[target]}"]`)?.focus();
      };
      return el;
    }));
    const mandatory=available[0]?.captures.length;
    hint.textContent=flight?'Validando a jogada…':!canPlay?'Selecione as casas para consultar o tabuleiro.':path.length>1?`Continue a captura: ${path.map(coord).join(' → ')}. Clique no próximo destino.`:path.length?'Escolha um destino destacado.':mandatory?`Captura obrigatória${game.variant==='brazilian'?' · maior sequência: '+mandatory+' peça(s)':''}. Selecione uma peça destacada.`:'Selecione uma peça sua e depois o destino.';
    // Origem identificada além da cor, com borda pontilhada.
    for(const i of sources)board.querySelector(`[data-cell="${i}"]`)?.classList.add('source');
    const undo=controls.undoButton||document.getElementById('undoPath');if(undo)undo.hidden=!canPlay || !path.length || flight;
    if(focused!==undefined)board.querySelector(`[data-cell="${focused}"]`)?.focus({preventScroll:true});
  }
  return {render,reset(){clear();version=null;},undo(){clear();if(snapshot)render(snapshot.state,snapshot.me,snapshot.canPlay);},flip(){flipped=!flipped;if(snapshot)render(snapshot.state,snapshot.me,snapshot.canPlay);}};
}
