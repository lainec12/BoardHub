# Atualização 9.3.1

Resumo compacto ao terminar as partidas nas seis salas: resultado e ranking da sala por vitórias, com empates de posição tratados igualmente. No Ludo, cada jogador vê quantos peões derrubou e quantas vezes seus peões foram derrubados; Damas e Xadrez mostram capturas e perdas, Naval mostra navios afundados/perdidos, Velha e UNO mostram jogadas. Contagens vêm apenas de ações aceitas pelo servidor, incluindo bots. Sem histórico de dados ou poderes usados. Na revanche as estatísticas da nova partida zeram, enquanto o placar de vitórias da sala permanece.
