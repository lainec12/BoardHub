import test from 'node:test';
import assert from 'node:assert/strict';
import {pawnStep,motionDuration} from '../shared/ludo-motion.js';
test('captura só regressa após o pouso e visita cada casa até a base',()=>{
 const event={startedAt:1,type:'move',color:'red',token:0,from:2,to:5,captured:[{color:'green',token:2,from:41}]};
 const cells=[],back=[];
 for(let t=0;t<=motionDuration(event);t+=5){
   const attacker=pawnStep(event,'red',0,t),victim=pawnStep(event,'green',2,t);
   if(attacker&&!cells.includes(attacker.from))cells.push(attacker.from);
   if(attacker)assert.equal(victim.t,0);
   if(victim&&!back.includes(victim.to))back.push(victim.to);
 }
 assert.deepEqual(cells,[2,3,4]);
 assert.deepEqual(back,Array.from({length:42},(_,i)=>40-i));
 assert.equal(pawnStep(event,'green',2,motionDuration(event)),null);
});
