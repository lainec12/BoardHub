import test from 'node:test';
import assert from 'node:assert/strict';
import {pawnStep,motionDuration,landingTime} from '../shared/ludo-motion.js';
test('captura só regressa após o pouso e visita cada casa até a base',()=>{
 const event={startedAt:1,type:'move',color:'red',token:0,from:2,to:5,captured:[{color:'green',token:2,from:41}]};
 const landing=landingTime(event);
 assert.equal(pawnStep(event,'green',2,landing-1).tilt,0);
 const falling=pawnStep(event,'green',2,landing+175);
 assert.equal(falling.from,falling.to);
 assert.ok(falling.tilt>1);
 const cells=[],back=[];
 for(let t=0;t<=motionDuration(event);t+=5){
   const attacker=pawnStep(event,'red',0,t),victim=pawnStep(event,'green',2,t);
   if(attacker&&!cells.includes(attacker.from))cells.push(attacker.from);
   if(attacker)assert.equal(victim.t,0);
   if(victim&&victim.from!==victim.to&&!back.includes(victim.to))back.push(victim.to);
 }
 assert.deepEqual(cells,[2,3,4]);
 assert.deepEqual(back,Array.from({length:42},(_,i)=>40-i));
 assert.equal(pawnStep(event,'green',2,motionDuration(event)),null);
});
