import test from 'node:test';
import assert from 'node:assert/strict';
import {io} from 'socket.io-client';
import {createBoardHub} from '../server/src/app.js';
const event=(s,name,predicate=()=>true)=>new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>{s.off(name,handler);reject(Error('Timeout '+name));},2000);
 function handler(value){if(predicate(value)){clearTimeout(timer);s.off(name,handler);resolve(value);}}
 s.on(name,handler);
});
const emit=(s,name,payload={})=>new Promise((resolve,reject)=>s.timeout(2000).emit(name,payload,(e,r)=>e?reject(e):resolve(r)));
for(const variant of ['brazilian','english'])test('rede '+variant+': variante, sequência, vitória, placar, reinício e empate por acordo',async()=>{
 const hub=createBoardHub({dbPath:':memory:'});await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+hub.http.address().port,a=io(url),b=io(url);
 try {
 await Promise.all([event(a,'connect'),event(b,'connect')]);
 const room=await emit(a,'room:create',{name:'A',gameId:'checkers-'+variant});
 const joined=event(b,'game:state');await emit(b,'room:join',{name:'B',code:room.code,gameId:'tic-tac-toe'});
 const initial=await joined;assert.equal(initial.gameId,'checkers-'+variant);assert.equal(initial.game.variant,variant);assert.equal(initial.game.board.length,64);
 // Posição controlada no servidor para exercitar captura múltipla pela rede.
 const canonical=hub.rooms.get(room.code).game;canonical.board=Array(64).fill(null);
 canonical.board[49]={side:'X',king:false};canonical.board[42]={side:'O',king:false};canonical.board[28]={side:'O',king:false};
 const started=event(b,'game:state',s=>s.status==='playing');await emit(a,'room:start');const view=await started;
 assert.deepEqual(view.legalMoves.map(m=>m.path),[[49,35,21]]);
 assert.equal((await emit(a,'game:action',{type:'move',path:[49,35],round:1,ply:0})).ok,false);
 const victory=event(b,'game:state',s=>s.game.winner==='X');
 assert.equal((await emit(a,'game:action',{type:'move',path:[49,35,21],round:1,ply:0})).ok,true);
 const final=await victory;assert.equal(final.scores.find(p=>p.player===room.playerId).wins,1);assert.deepEqual(final.game.lastMove.captures,[42,28]);
 const reset=event(b,'game:state',s=>s.game.round===2);await emit(a,'room:restart');assert.equal((await reset).game.variant,variant);
 assert.equal((await emit(a,'game:action',{type:'move',path:[40,33],round:1,ply:0})).ok,false);
 const offered=event(b,'game:state',s=>!!s.drawOffer);await emit(a,'game:draw-offer');await offered;
 assert.equal((await emit(a,'game:draw-answer',{accept:true})).ok,false);
 const draw=event(a,'game:state',s=>s.game.winner==='draw');assert.equal((await emit(b,'game:draw-answer',{accept:true})).ok,true);
 assert.equal((await draw).game.reason,'acordo entre jogadores');
 }finally{a.disconnect();b.disconnect();await hub.close();}
});
