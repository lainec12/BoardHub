import test from 'node:test';
import assert from 'node:assert/strict';
import {botReaction} from '../server/src/reactions.js';
test('a conversa envolve somente os participantes da jogada',()=>{
 const make=()=>({gameId:'ludo',game:{},players:['red','green','blue'].map(mark=>({mark,name:mark,bot:true})),chat:[]});
 const react=(r,event)=>botReaction(r,event,()=>0);
 const r=make();react(r,{color:'red',type:'move'});assert.equal(r.chat.length,0);
 react(r,{greeting:true});assert.equal(r.chat.length,1);
 for(const human of [true,false]){
   const room=make();room.players[1].bot=!human;
   react(room,{color:'red',captured:[{color:'green'}]});
   assert.deepEqual(room.chat.map(m=>[m.mark,m.target]),human?[['red','green'],['red','green']]:[['red','green'],['red','green'],['green','red']]);
   assert.equal(room.chat[1].kind,'avatar-effect');
   if(!human)assert.ok(room.chat[2].displayAt>room.chat[0].displayAt+room.chat[0].displayFor);
 }
 const lost=make();react(lost,{color:'blue',type:'triple-six'});assert.deepEqual(lost.chat.map(m=>m.mark),['blue']);
});
