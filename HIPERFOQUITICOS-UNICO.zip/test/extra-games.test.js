import test from 'node:test';
import assert from 'node:assert/strict';
import * as memory from '../server/src/games/memory/index.js';
import * as hangman from '../server/src/games/hangman/index.js';
import {chooseBotAction} from '../server/src/bots.js';
for(const [id,engine] of [['memory',memory],['hangman',hangman]])test(id+' bots finish with private state and legal turns',()=>{
 let s=engine.startGame(engine.createState(1,{memorySize:50,hangmanCategory:'Palavras raras'}),['X','O'],n=>Math.floor(Math.random()*n));
 const view=engine.publicState(s,'X');
 if(id==='memory'){assert.equal(view.cards.length,50);assert.ok(view.cards.every(c=>c===null));assert.equal(view.seen,undefined);}
 else{assert.equal(view.word,undefined);assert.ok(view.pattern.includes('_'));}
 for(let i=0;i<1000&&!s.winner;i++){
  const mark=s.players[s.turnIndex].color;
  const a=chooseBotAction(engine,s,mark,n=>Math.floor(Math.random()*n));
  assert.ok(a);s=engine.applyAction(s,mark,a);
 }
 assert.ok(s.winner);
});
