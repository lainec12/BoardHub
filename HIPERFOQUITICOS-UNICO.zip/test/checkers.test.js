import test from 'node:test';
import assert from 'node:assert/strict';
import {createState,legalMoves,applyAction,positionKey} from '../server/src/games/checkers/index.js';
const at=s=>(8-Number(s[1]))*8+s.charCodeAt(0)-97;
function fixture(variant,entries,turn='X') {
 const s=createState(1,variant);s.board=Array(64).fill(null);s.turn=turn;
 for(const [square,side,king=false] of entries)s.board[at(square)]={side,king};
 s.repetitions={[positionKey(s)]:1};return s;
}
const move=(s,path,side=s.turn)=>applyAction(s,side,{type:'move',path:path.map(at),round:s.round,ply:s.ply});
const paths=s=>legalMoves(s).map(m=>m.path.map(i=>String.fromCharCode(97+i%8)+(8-Math.floor(i/8))).join('-'));

for(const variant of ['brazilian','english']) {
 test(variant+': disposição inicial, imutabilidade, ação e versão validadas',()=>{
  const s=createState(1,variant),before=JSON.stringify(s);
  assert.equal(s.board.filter(p=>p?.side==='X').length,12);assert.equal(s.board.filter(p=>p?.side==='O').length,12);
  assert.equal(legalMoves(s).length,7);const next=move(s,['a3','b4']);assert.equal(next.turn,'O');assert.equal(next.ply,1);assert.equal(JSON.stringify(s),before);
  assert.throws(()=>move(s,['a3','b4'],'O'));assert.throws(()=>move(s,['a3','c5']));
  assert.throws(()=>applyAction(s,'X',{type:'move',path:[40,33],round:1,ply:2}));
  assert.throws(()=>applyAction(s,'X',{type:'move',path:'a3b4',round:1,ply:0}));
 });
 test(variant+': captura obrigatória e sequência completa',()=>{
  const s=fixture(variant,[['b2','X'],['c3','O'],['e5','O'],['h8','O']]);
  assert.throws(()=>move(s,['b2','a3']));assert.throws(()=>move(s,['b2','d4']));
  const next=move(s,['b2','d4','f6']);assert.equal(next.board[at('c3')],null);assert.equal(next.board[at('e5')],null);assert.equal(next.board[at('f6')].side,'X');assert.equal(next.turn,'O');
 });
 test(variant+': vitória por captura da última peça',()=>{
  const s=fixture(variant,[['b2','X'],['c3','O']]),next=move(s,['b2','d4']);assert.equal(next.winner,'X');assert.equal(next.reason,'adversário sem jogadas');
  assert.throws(()=>move(next,['d4','e5']));
 });
 test(variant+': vitória por bloqueio',()=>{
  const s=fixture(variant,[['b4','X'],['a1','O']]);assert.equal(move(s,['b4','a5']).winner,'X');
 });
 test(variant+': promoção ao terminar na fileira final',()=>{
  const s=fixture(variant,[['b6','X'],['a1','O']]);
  const a=move(s,['b6','a7']);assert.equal(a.board[at('a7')].king,false);
  const s2=fixture(variant,[['a7','X'],['a1','O']]);assert.equal(move(s2,['a7','b8']).board[at('b8')].king,true);
 });
 test(variant+': repetição tripla encerra o jogo',()=>{
  let s=fixture(variant,[['a1','X',true],['h6','O',true]]);
  for(let cycle=0;cycle<2;cycle++)for(const path of [['a1','b2'],['h6','g5'],['b2','a1'],['g5','h6']])s=move(s,path);
  assert.equal(s.winner,'draw');assert.equal(s.reason,'repetição tripla');
 });
}

test('brasileira captura para trás; inglesa rejeita captura de pedra para trás',()=>{
 const entries=[['c3','X'],['d2','O'],['h8','O']];
 assert.ok(paths(fixture('brazilian',entries)).includes('c3-e1'));
 assert.ok(!paths(fixture('english',entries)).includes('c3-e1'));
 assert.throws(()=>move(fixture('english',entries),['c3','e1']));
});
test('lei da maioria só na brasileira; inglesa admite sequência menor',()=>{
 const entries=[['b2','X'],['f2','X'],['c3','O'],['e5','O'],['g3','O']];
 const br=fixture('brazilian',entries),en=fixture('english',entries);
 assert.deepEqual(paths(br),['b2-d4-f6']);assert.throws(()=>move(br,['f2','h4']));assert.ok(paths(en).includes('f2-h4'));assert.ok(paths(en).includes('b2-d4-f6'));
});
test('dama voadora brasileira; inglesa anda uma casa',()=>{
 const entries=[['b2','X',true],['h8','O']];
 assert.ok(paths(fixture('brazilian',entries)).includes('b2-f6'));
 assert.ok(!paths(fixture('english',entries)).includes('b2-f6'));
});
test('dama brasileira captura à distância e escolhe pouso legal',()=>{
 const s=fixture('brazilian',[['b2','X',true],['d4','O']]);
 assert.deepEqual(paths(s).sort(),['b2-e5','b2-f6','b2-g7','b2-h8']);
});
test('capturadas bloqueiam retorno da dama brasileira até o fim',()=>{
 const s=fixture('brazilian',[['d4','X',true],['c3','O'],['f6','O']]);
 assert.ok(legalMoves(s).every(m=>m.captures.length===1));
 assert.throws(()=>move(s,['d4','b2','g7']));
});
test('pedra brasileira passa pela promoção e segue como pedra; inglesa para',()=>{
 const entries=[['b6','X'],['c7','O'],['e7','O'],['h2','O']];
 const br=fixture('brazilian',entries),en=fixture('english',entries);
 assert.deepEqual(paths(br),['b6-d8-f6']);assert.throws(()=>move(br,['b6','d8']));
 assert.equal(move(br,['b6','d8','f6']).board[at('f6')].king,false);
 assert.deepEqual(paths(en),['b6-d8']);assert.equal(move(en,['b6','d8']).board[at('d8')].king,true);
});
test('dama e pedra têm mesmo peso na lei da maioria',()=>{
 const entries=[['b2','X'],['f2','X'],['c3','O',true],['g3','O']];
 assert.equal(legalMoves(fixture('brazilian',entries)).length,2);
});
test('contadores de empate e reinicialização após movimento de pedra',()=>{
 let br=fixture('brazilian',[['a1','X',true],['h6','O',true]]);br.quietPlies=29;
 assert.equal(move(br,['a1','b2']).winner,'draw');
 let en=fixture('english',[['a1','X',true],['h6','O',true]]);en.quietPlies=79;
 assert.equal(move(en,['a1','b2']).winner,'draw');
 en=fixture('english',[['a3','X'],['h6','O',true]]);en.quietPlies=79;assert.equal(move(en,['a3','b4']).quietPlies,0);
});
test('final reduzido brasileiro encerra após contador regulamentar',()=>{
 const s=fixture('brazilian',[['a1','X',true],['h6','O',true]]);s.endgame={key:'small-0',plies:9};
 assert.equal(move(s,['a1','b2']).reason,'limite de final reduzido');
});
test('caminhos excessivos, peças adversárias e troca de variante não burlam validação',()=>{
 const s=createState(1,'english');assert.throws(()=>applyAction(s,'X',{type:'move',path:Array(14).fill(40),round:1,ply:0}));
 assert.throws(()=>move(s,['b6','a5']));assert.throws(()=>createState(1,'unknown'));
 const copy=structuredClone(s);const m=legalMoves(s)[0];applyAction(s,'X',{type:'move',path:m.path,round:1,ply:0,variant:'brazilian',winner:'X'});assert.deepEqual(s,copy);
});

test('partidas completas geradas: peças não aumentam, estado serializa e turnos alternam',()=>{
 let seed=937;const random=n=>{seed=(seed*1664525+1013904223)>>>0;return seed%n;};
 for(const variant of ['brazilian','english'])for(let match=0;match<4;match++){
  let s=createState(1,variant),total=24;
  for(let ply=0;ply<400 && !s.winner;ply++){
   const options=legalMoves(s);assert.ok(options.length>0);
   const selected=options[random(options.length)],side=s.turn;
   const next=applyAction(s,side,{type:'move',path:selected.path,round:s.round,ply:s.ply});
   assert.equal(next.board.filter(Boolean).length,total-selected.captures.length);
   assert.notEqual(next.turn,side);assert.deepEqual(JSON.parse(JSON.stringify(next)),next);
   total=next.board.filter(Boolean).length;s=next;
  }
  assert.ok(s.winner,'partida deve terminar sem loop ilimitado');
 }
});
