import test from 'node:test';import assert from 'node:assert/strict';import {io} from 'socket.io-client';import {createBoardHub} from '../server/src/app.js';
const emit=(s,e,d={})=>new Promise((resolve,reject)=>s.timeout(2000).emit(e,d,(error,result)=>error?reject(error):resolve(result)));
test('revanche exige confirmação dos humanos e preserva sala, jogadores e configurações',async()=>{const h=createBoardHub({dbPath:':memory:'}),sockets=[];await new Promise(r=>h.http.listen(0,'127.0.0.1',r));try{for(let i=0;i<2;i++){const s=io('http://127.0.0.1:'+h.http.address().port,{forceNew:true});sockets.push(s);await new Promise(r=>s.once('connect',r));}const [a,b]=sockets,c=await emit(a,'room:create',{gameId:'tic-tac-toe',name:'A',difficulty:'hard'});await emit(b,'room:join',{code:c.code,name:'B'});await emit(a,'room:start');await emit(a,'game:resign');const room=h.rooms.get(c.code),ids=room.players.map(p=>p.id);assert.ok(room.matchSummary);assert.equal(room.matchSummary.rows.length,2);assert.equal((await emit(b,'room:rematch')).ok,true);assert.equal(room.status,'finished');assert.equal((await emit(a,'room:rematch')).ok,true);assert.equal(room.status,'playing');assert.equal(room.code,c.code);assert.equal(room.game.round,2);assert.deepEqual(room.players.map(p=>p.id),ids);assert.equal(room.options.difficulty,'hard');assert.deepEqual(room.rematchVotes,[]);assert.equal(room.matchSummary,null);}finally{sockets.forEach(s=>s.disconnect());await h.close();}});
test('o vencedor do Ludo abre a revanche mesmo sem ser o anfitrião',async()=>{
 const hub=createBoardHub({dbPath:':memory:',ludoRandom:()=>0}),clients=[];
 await new Promise(resolve=>hub.http.listen(0,'127.0.0.1',resolve));
 try{
  for(const name of ['Ana','Bia']){
   const socket=io('http://127.0.0.1:'+hub.http.address().port,{forceNew:true});
   clients.push(socket);await new Promise(resolve=>socket.once('connect',resolve));
  }
  const [host,guest]=clients;
  const {code}=await emit(host,'room:create',{gameId:'ludo',capacity:2,name:'Ana'});
  await emit(guest,'room:join',{code,name:'Bia'});await emit(host,'room:start');
  await emit(host,'game:resign');const room=hub.rooms.get(code),winner=room.game.winner;
  assert.equal(winner,room.players[1].mark);
  await emit(guest,'room:rematch');await emit(host,'room:rematch');
  assert.equal(room.game.round,2);assert.equal(room.game.players[room.game.turnIndex].color,winner);
 }finally{clients.forEach(s=>s.disconnect());await hub.close();}
});
for(const gameId of ['tic-tac-toe','checkers-brazilian','checkers-english','chess','battleship','domino','uno']){
 test('vencedor visitante inicia revanche em '+gameId,async()=>{
  const hub=createBoardHub({dbPath:':memory:'}),clients=[];
  await new Promise(resolve=>hub.http.listen(0,'127.0.0.1',resolve));
  try{
   for(let i=0;i<2;i++){
    const socket=io('http://127.0.0.1:'+hub.http.address().port,{forceNew:true});
    clients.push(socket);await new Promise(resolve=>socket.once('connect',resolve));
   }
   const [host,guest]=clients;
   const {code}=await emit(host,'room:create',{gameId,capacity:2,name:'Ana'});
   const joined=await emit(guest,'room:join',{code,name:'Bia'});
   await emit(host,'room:start');await emit(host,'game:resign');
   await emit(guest,'room:rematch');await emit(host,'room:rematch');
   const room=hub.rooms.get(code),game=room.game;
   assert.equal(game.round,2);
   const winner=room.players.find(p=>p.id===joined.playerId);
   assert.equal(game.turn??game.players[game.turnIndex].color,winner.mark);
   if(gameId==='domino')assert.ok(game.players[game.turnIndex].hand.some(t=>t.id===game.openingTile));
  }finally{clients.forEach(s=>s.disconnect());await hub.close();}
 });
}
