import {test} from 'node:test';import assert from 'node:assert/strict';import {io} from 'socket.io-client';import {createBoardHub} from '../server/src/app.js';
for(const mode of ['together','versus'])test('duplas em cantos opostos: '+mode,async()=>{
 const hub=createBoardHub({dbPath:':memory:'});await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+hub.http.address().port;
 const clients=[];const connect=async()=>{const s=io(url,{forceNew:true});clients.push(s);await new Promise(r=>s.on('connect',r));return s;};const emit=(s,e,d={})=>new Promise(r=>s.emit(e,d,r));
 try{const a=await connect(),b=await connect();let latest;a.on('game:state',s=>latest=s);
 const room=await emit(a,'room:create',{name:'Amigo A',gameId:'ludo'});assert.ok(room.ok);assert.ok((await emit(b,'room:join',{name:'Amigo B',code:room.code})).ok);assert.ok((await emit(a,'room:fill-bots')).ok);
 const started=new Promise(r=>a.on('game:state',s=>{if(s.status==='playing')r(s);}));assert.ok((await emit(a,'room:start',{teams:mode})).ok);const s=await started;
 assert.deepEqual(s.game.teams,[['red','yellow'],['green','blue']]);assert.equal(s.players[0].name,'Amigo A');assert.equal(s.players[mode==='together'?2:1].name,'Amigo B');assert.deepEqual(s.game.players.map(p=>p.color),['red','green','yellow','blue']);
 }finally{clients.forEach(s=>s.disconnect());await new Promise(r=>hub.io.close(r))}
});
