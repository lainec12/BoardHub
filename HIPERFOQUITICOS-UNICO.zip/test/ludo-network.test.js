import test from 'node:test';
import assert from 'node:assert/strict';
import {io} from 'socket.io-client';
import {createBoardHub} from '../server/src/app.js';
const wait=(s,name,p=()=>true)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('timeout '+name)),2500);s.on(name,function h(v){if(p(v)){clearTimeout(timer);s.off(name,h);resolve(v);}});});
const emit=(s,name,data={})=>new Promise((resolve,reject)=>s.timeout(2000).emit(name,data,(e,r)=>e?reject(e):resolve(r)));
test('Ludo Power conecta quatro jogadores, servidor rola dado e reconecta',async()=>{
 const hub=createBoardHub({dbPath:':memory:',graceMs:500}),clients=[];await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+hub.http.address().port,connect=async()=>{const s=io(url,{forceNew:true});clients.push(s);await wait(s,'connect');return s;};
 try{const [a,b,c,d,e]=await Promise.all([connect(),connect(),connect(),connect(),connect()]);const room=await emit(a,'room:create',{name:'A',gameId:'ludo',mode:'power',acquisition:'fixed'});for(const [socket,name] of [[b,'B'],[c,'C'],[d,'D']])assert.equal((await emit(socket,'room:join',{name,code:room.code})).ok,true);assert.equal((await emit(e,'room:join',{name:'E',code:room.code})).ok,false);const started=wait(d,'game:state',s=>s.status==='playing');await emit(a,'room:start');const state=await started;assert.deepEqual(state.game.players.map(p=>p.color),['red','green','yellow','blue']);assert.equal((await emit(b,'game:action',{type:'roll',round:1,revision:state.game.revision,die:6})).ok,false);const rolled=wait(b,'game:state',s=>s.game.die!==null);await emit(a,'game:action',{type:'roll',round:1,revision:state.game.revision,die:6});const after=await rolled;assert.ok(after.game.die>=1&&after.game.die<=6);a.disconnect();const re=await connect();assert.equal((await emit(re,'room:join',{name:'A',code:room.code,token:room.token})).mark,'red');}
 finally{clients.forEach(s=>s.disconnect());await hub.close();}
});
test('Ludo inicia com dois e conserva casas especiais na revanche',async()=>{
 const hub=createBoardHub({dbPath:':memory:'});await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+hub.http.address().port,a=io(url),b=io(url);
 try{await Promise.all([wait(a,'connect'),wait(b,'connect')]);const room=await emit(a,'room:create',{name:'A',gameId:'ludo',mode:'power',acquisition:'cells'});await emit(b,'room:join',{name:'B',code:room.code});await emit(a,'room:start');const restarted=wait(b,'game:state',s=>s.game.round===2);await emit(a,'room:restart');const s=await restarted;assert.equal(s.game.acquisition,'cells');assert.equal(s.game.players.length,2);assert.ok(s.game.players.every(p=>Object.keys(p.inventory).length===0));}
 finally{a.disconnect();b.disconnect();await hub.close();}
});
