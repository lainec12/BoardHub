import test from 'node:test';
import assert from 'node:assert/strict';
import {createState,startGame,applyAction,legalActions,START} from '../server/src/games/ludo/index.js';
const action=(s,color,data,rng=()=>0)=>applyAction(s,color,{round:s.round,revision:s.revision,...data},rng);
// Fixtures de poderes representam itens já coletados, não inventário inicial.
const ready=(mode='power',acquisition='fixed',colors=['red','green'])=>{const s=startGame(createState(1,{mode,acquisition}),colors);s.bonusCells=[];if(mode!=='classic'&&acquisition==='fixed')for(const p of s.players)p.inventory={double:2,control:1,shield:2,bonus:2};return s;};
const unlock=s=>{for(const p of s.players)p.turnsTaken=2;return s;};

test('inicia Ludo para 2, 3 e 4 jogadores com quatro peças',()=>{
 for(const n of [2,3,4]){const s=ready('classic','fixed',['red','green','yellow','blue'].slice(0,n));assert.equal(s.players.length,n);assert.ok(s.players.every(p=>p.tokens.join(',')==='-1,-1,-1,-1'));}
 assert.throws(()=>startGame(createState(),['red']));assert.throws(()=>startGame(createState(),['red','red']));
});
test('dado é produzido no servidor e seis libera peça',()=>{
 let s=ready('classic');s=action(s,'red',{type:'roll'},()=>5);assert.equal(s.die,6);
 assert.deepEqual(legalActions(s,'red').filter(a=>a.type==='move'),[{type:'move',token:0,to:0},{type:'move',token:1,to:0},{type:'move',token:2,to:0},{type:'move',token:3,to:0}]);
 s=action(s,'red',{type:'move',token:0,to:0});assert.equal(s.players[0].tokens[0],0);assert.equal(s.phase,'postMove');
 s=action(s,'red',{type:'end-turn'});assert.equal(s.players[s.turnIndex].color,'red');
});
test('três seis consecutivos perdem o turno',()=>{
 let s=ready('classic');s.players[0].tokens[0]=0;
 for(let i=0;i<2;i++){s=action(s,'red',{type:'roll'},()=>5);s=action(s,'red',{type:'move',token:0,to:s.players[0].tokens[0]+6});s=action(s,'red',{type:'end-turn'});}
 s=action(s,'red',{type:'roll'},()=>5);assert.equal(s.lastEvent.type,'triple-six');assert.equal(s.players[s.turnIndex].color,'green');
});
test('chegada exige número exato e quatro peças na chegada vencem',()=>{
 let s=ready('classic');s.players[0].tokens=[56,57,57,57];s=action(s,'red',{type:'roll'},()=>1);
 assert.equal(legalActions(s,'red').some(a=>a.type==='move'),false);s=action(s,'red',{type:'pass'});assert.equal(s.winner,null);
 s.turnIndex=0;s.phase='roll';s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:57});assert.equal(s.winner,'red');
});
test('captura devolve à base e escudo bloqueia captura',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=4;s.players[1].tokens[0]=(5-START.green+52)%52;
 s=action(s,'red',{type:'power',power:'shield',token:0});assert.equal(s.players[0].inventory.shield,1);
 // Avança até o verde e mantém o escudo da peça vermelha para testar imunidade no mesmo ciclo.
 s.turnIndex=1;s.phase='roll';s.die=null;s.effectiveDie=null;s.players[1].tokens[0]=(4-START.green+52)%52;s.players[0].tokens[0]=5;
 s=action(s,'green',{type:'roll'},()=>0);s=action(s,'green',{type:'move',token:0,to:s.players[1].tokens[0]+1});assert.equal(s.players[0].tokens[0],5);
 // Sem escudo, captura ocorre.
 s.players[0].shield=null;s.players[0].shields=[];s.turnIndex=1;s.phase='roll';s.players[1].tokens[0]=(4-START.green+52)%52;
 s=action(s,'green',{type:'roll'},()=>0);s=action(s,'green',{type:'move',token:0,to:s.players[1].tokens[0]+1});assert.equal(s.players[0].tokens[0],-1);
});
test('Double Distance com 6 é rejeitado sem consumo',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=0;s=action(s,'red',{type:'roll'},()=>5);const before=s.players[0].inventory.double;
 assert.throws(()=>action(s,'red',{type:'power',power:'double'}),/dado 6/);assert.equal(s.players[0].inventory.double,before);
});
test('Controle aceita seis nos dois modos e aquisição; poderes removidos são rejeitados',()=>{
 for(const mode of ['power','extra'])for(const acquisition of ['fixed','cells']){
 let s=unlock(ready(mode,acquisition));s.players[0].inventory.control=1;
 s=action(s,'red',{type:'power',power:'control',value:6});assert.equal(s.die,6);
 for(const power of ['freeze','teleport'])assert.throws(()=>action(unlock(ready(mode,acquisition)),'red',{type:'power',power,target:'green',token:0,cell:12}));
 }
});
test('todos os modos iniciam sem poderes, inclusive opções antigas',()=>{for(const mode of ['classic','power','extra'])for(const acquisition of ['fixed','cells']){const s=startGame(createState(1,{mode,acquisition}),['red','green']);assert.ok(s.players.every(p=>Object.keys(p.inventory).length===0));}});
test('poderes disponíveis desde o início, mas nunca fora do turno ou sem inventário',()=>{
 let s=ready();assert.equal(action(s,'red',{type:'power',power:'control',value:3}).die,3);
 assert.throws(()=>action(s,'green',{type:'roll'}),/Aguarde/);
 s=unlock(s);s.players[0].inventory.control=0;assert.throws(()=>action(s,'red',{type:'power',power:'control',value:3}),/indisponível/);
});
test('Bonus Roll concede uma rolagem e não encadeia',()=>{
 let s=unlock(ready());s.players[0].tokens[0]=0;s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:1});
 s=action(s,'red',{type:'power',power:'bonus'});assert.equal(s.phase,'roll');assert.equal(s.players[s.turnIndex].color,'red');
 s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:2});assert.equal(legalActions(s,'red').some(a=>a.power==='bonus'),false);
});
test('coleta sem limite repõe três poderes fora de casas seguras e ocupadas',()=>{
 let s=ready('power','cells');s.powerDrops=[{id:100,cell:5,power:'double'},{id:101,cell:6,power:'shield'},{id:102,cell:7,power:'bonus'}];s.dropSequence=103;s.players[0].inventory.double=25;s.players[0].tokens[0]=4;s=action(s,'red',{type:'roll'},()=>0);s=action(s,'red',{type:'move',token:0,to:5},()=>0);assert.equal(s.players[0].inventory.double,26);assert.equal(s.powerDrops.length,6);assert.ok(!s.powerDrops.some(d=>d.cell===5));
});
test('vários poderes no mesmo turno: escolher dado, duplo e escudo',()=>{let s=ready();s.players[0].tokens[0]=0;s=action(s,'red',{type:'power',power:'control',value:3});s=action(s,'red',{type:'power',power:'double'});s=action(s,'red',{type:'power',power:'shield',token:0});assert.equal(s.effectiveDie,6);assert.ok(s.players[0].shields.includes(0));assert.equal(s.players[0].inventory.double,1);});
test('estado e inventário do cliente não podem ser adulterados',()=>{
 const s=unlock(ready()),before=structuredClone(s);
 assert.throws(()=>applyAction(s,'red',{type:'roll',round:1,revision:999,die:6}));assert.deepEqual(s,before);
});
