import test from 'node:test';
import assert from 'node:assert/strict';
import {io} from 'socket.io-client';
import {createBoardHub} from '../server/src/app.js';
import {openDatabase} from '../server/src/db/index.js';
import {createState,applyAction} from '../server/src/games/tic-tac-toe/index.js';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const waitFor=(s,event,predicate=()=>true)=>new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>{s.off(event,handler);reject(Error('Timeout '+event));},2500);
 function handler(value){if(predicate(value)){clearTimeout(timer);s.off(event,handler);resolve(value);}}
 s.on(event,handler);
});
const emit=(s,event,data={})=>new Promise((resolve,reject)=>s.timeout(2000).emit(event,data,(e,r)=>e?reject(e):resolve(r)));

test('motor rejeita turno, casa ocupada, índice e versão; detecta vitória e empate',()=>{
 let s=createState();assert.throws(()=>applyAction(s,'O',{type:'move',cell:0,round:1}));
 assert.throws(()=>applyAction(s,'X',{type:'move',cell:9,round:1}));
 assert.throws(()=>applyAction(s,'X',{type:'move',cell:0,round:0}));
 s=applyAction(s,'X',{type:'move',cell:0,round:1});assert.throws(()=>applyAction(s,'O',{type:'move',cell:0,round:1}));
 for(const [mark,cell] of [['O',3],['X',1],['O',4],['X',2]])s=applyAction(s,mark,{type:'move',cell,round:1});
 assert.equal(s.winner,'X');assert.deepEqual(s.line,[0,1,2]);
 assert.throws(()=>applyAction(s,'O',{type:'move',cell:8,round:1}));
 s=createState();[0,1,2,4,3,5,7,6,8].forEach((cell,i)=>s=applyAction(s,i%2?'O':'X',{type:'move',cell,round:1}));assert.equal(s.winner,'draw');
});

test('multiplayer real: salas, host, chat isolado, XSS, vitória, reconexão e limite',async()=>{
 const hub=createBoardHub({dbPath:':memory:',graceMs:1500});await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+hub.http.address().port,clients=[];
 const connect=async()=>{const s=io(url,{forceNew:true});clients.push(s);await waitFor(s,'connect');return s;};
 try {
 const a=await connect(),b=await connect(),c=await connect();
 const first=await emit(a,'room:create',{name:'Laine'});assert.match(first.code,/^[A-Z2-9]{6}$/);
 assert.equal((await emit(b,'room:join',{code:first.code,name:'Amiga'})).ok,true);
 assert.equal((await emit(c,'room:join',{code:first.code,name:'Terceiro'})).ok,false);
 const other=await emit(c,'room:create',{name:'Outra sala'});
 assert.equal((await emit(b,'room:start')).ok,false);
 assert.equal((await emit(a,'room:start')).ok,true);
 let receivedOther=false;c.on('game:state',s=>{if(s.code!==other.code)receivedOther=true;});
 const chat=waitFor(b,'game:state',s=>s.chat.some(m=>m.text==='Oi em tempo real!'));
 await emit(a,'chat:message',{text:'Oi em tempo real!'});await chat;assert.equal(receivedOther,false);
 assert.equal((await emit(b,'game:action',{type:'move',cell:0,round:1})).ok,false);
 const win=waitFor(b,'game:state',s=>s.game.winner==='X');
 for(const [s,cell] of [[a,0],[b,3],[a,1],[b,4],[a,2]])assert.equal((await emit(s,'game:action',{type:'move',cell,round:1})).ok,true);
 const result=await win;assert.equal(result.scores.find(p=>p.player===first.playerId).wins,1);
 const gone=waitFor(b,'player:disconnect');a.disconnect();await gone;
 const d=await connect();const resumed=await emit(d,'room:join',{code:first.code,name:'Laine',token:first.token});assert.equal(resumed.mark,'X');assert.equal(resumed.playerId,first.playerId);
 const restarted=waitFor(b,'game:state',s=>s.game.round===2);assert.equal((await emit(d,'room:restart')).ok,true);await restarted;
 const resign=waitFor(b,'game:state',s=>s.game.reason==='desistência');await emit(d,'game:resign');assert.equal((await resign).game.winner,'O');
 const escaped=waitFor(b,'game:state',s=>s.chat.some(m=>m.text==='img src=x onerror=alert(1)'));
 assert.equal((await emit(b,'chat:message',{text:'<img src=x onerror=alert(1)>'})).ok,true);await escaped;
 assert.equal((await emit(d,'chat:message',{text:'x'.repeat(401)})).ok,false);
 const spam=await Promise.all(Array.from({length:12},()=>emit(c,'chat:message',{text:'oi'})));assert.ok(spam.some(r=>r.error?.includes('10 ações')));
 for(const path of ['/','/join/'+first.code,'/style.css','/app.js','/health'])assert.equal((await fetch(url+path)).status,200);
 } finally {clients.forEach(s=>s.disconnect());await hub.close();}
});

test('prazo de reconexão: adversário vence por abandono',async()=>{
 const hub=createBoardHub({dbPath:':memory:',graceMs:80});await new Promise(r=>hub.http.listen(0,'127.0.0.1',r));
 const url='http://127.0.0.1:'+hub.http.address().port,a=io(url),b=io(url);
 try {await Promise.all([waitFor(a,'connect'),waitFor(b,'connect')]);
 const room=await emit(a,'room:create',{name:'A'});await emit(b,'room:join',{code:room.code,name:'B'});await emit(a,'room:start');
 const abandoned=waitFor(b,'game:state',s=>s.game.reason==='tempo de reconexão esgotado');a.disconnect();assert.equal((await abandoned).game.winner,'O');
 } finally {a.disconnect();b.disconnect();await hub.close();}
});

test('SQLite mantém placar e histórico ao reabrir o arquivo, sem duplicar vitória',()=>{
 const dir=mkdtempSync(join(tmpdir(),'boardhub-')),file=join(dir,'score.sqlite');
 try {let db=openDatabase(file);const p={id:'p1',name:'Laine',mark:'X'};db.register('ABC123',p);
 const game={round:1,winner:'X',reason:'line'};db.finish('ABC123',game,[p]);db.finish('ABC123',game,[p]);db.close();
 db=openDatabase(file);assert.equal(db.score('ABC123')[0].wins,1);assert.equal(db.history('ABC123').length,1);db.close();
 } finally {rmSync(dir,{recursive:true,force:true});}
});
