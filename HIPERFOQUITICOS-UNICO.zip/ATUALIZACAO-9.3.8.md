# 9.3.8 — desempenho no celular e computador

Mantém câmera relativa, enquadramento, tamanhos, peões e regras existentes.

- Tabuleiro estático isolado das atualizações da sala; perfis dos peões e triângulos centrais reutilizados.
- 21 pintas do dado desenhadas em uma chamada instanciada, com as mesmas faces e posições.
- Resolução inicial nítida e ajuste conservador sob carga (piso 1x); pausas entre ações não contam como travadas.
- Cena 3D, animações CSS e atualização visual do relógio pausam em segundo plano; conexão e prazos do servidor continuam ativos.
- Rolagem deixa de pedir quadros quando o dado assenta, mesmo se houver atraso da rede.
- Modo leve também interrompe animação CSS dos poderes; música e efeitos mantêm controles separados.

Validação: testes de orçamento de quadros, qualidade, regras/fluxo do Ludo, bots e montagem das seis mesas; build de produção.
O ganho de FPS em cada aparelho depende de validação em uso real; não há medição de FPS do celular da usuária.

- Resolução adaptativa preservada também quando chegam novas atualizações da sala.
- Relógio visual nunca retrocede antes do instante de recebimento do estado.
