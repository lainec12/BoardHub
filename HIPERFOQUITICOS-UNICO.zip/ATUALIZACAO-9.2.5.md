# Atualização 9.2.5

Setas de saída substituídas por estrelas planas escuras e translúcidas, como sombras nas casas de partida. Estrelas douradas das demais zonas seguras, regras e coordenadas preservadas. Aplicado ao 3D e à interface alternativa.
