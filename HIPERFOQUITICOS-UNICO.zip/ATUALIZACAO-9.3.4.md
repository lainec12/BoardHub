# Atualização 9.3.4

Mais 16 reações animadas, totalizando 32: 16 zoadas e 16 fofas. Novas opções: palhaço, martelo de borracha, balde gelado, meia fedida, peixada, papel enrolado, língua, confete, cachorrinho, coelho, sol, cupcake, cerejas, balão, laço e carta. Preços de cinco a vinte Foticas visíveis antes do envio; só o remetente paga. Bots podem escolher todas as novas reações. Frases continuam com sete segundos de exibição. Demais regras e recursos preservados.
