# Hiperfoquíticos 9.3.0

## Social e revanche
- Amigos por ID da conta: pedido, aceite/recusa, remoção, indicador online e convites diretos para salas com vaga. Convites expiram em dois minutos; só o destinatário pode aceitar.
- Conta Google salva amizades no PostgreSQL e recebe convites entre aparelhos; convidados continuam com convite por código.
- Revanche mantém sala, jogadores, equipes, modo, aposta e dificuldade. Todos os humanos confirmam; bots confirmam automaticamente. Partidas apostadas mostram a nova entrada antes da confirmação.

## Reações e brincadeiras em todos os seis jogos
- 16 efeitos temporários: 8 zoados e 8 fofos. Clique na foto do adversário para abrir o catálogo, conferir preço e enviar.
- Zoados: bigode, ovo, tomate, torta, chinelo, banana, patinho e óculos.
- Fofos: coração, flor, ursinho, beijo, estrelas, borboletas, arco-íris e gatinho.
- O símbolo animado sai do remetente e voa até o avatar escolhido; o efeito aparece na foto por alguns segundos e desaparece. Não modifica a imagem salva nem as regras da partida.
- Cada envio custa de 5 a 15 Foticas, com preço visível antes do clique. Só o remetente paga. A carteira é validada no servidor, com proteção contra débito duplicado e reembolso se o efeito não puder ser enviado.
- Bots usam frases e efeitos autonomamente e podem responder a uma brincadeira. Ações de bots não descontam Foticas de pessoas.
- 100 frases dos bots: 50 de deboche (incluindo “hello”) e 50 de raiva teatral, incluindo as frases pedidas pela usuária.
- Intervalo entre reações de uma pessoa: quatro segundos; bots respeitam pelo menos oito segundos entre suas reações.
- Não há chave para silenciar reações, conforme solicitado. Música e efeitos sonoros continuam com controles independentes.

## Cosméticos, missões e acabamento
- Loja e inventário ganham seis estilos permanentes de balão: clássico, neon, dourado, nuvem, quadrinhos e rosa.
- Novas missões diárias: vencer uma partida (+20 Foticas) e capturar três peças em partidas apostadas (+25). As duas se juntam ao baú diário e à missão de três partidas. O servidor verifica o progresso e impede resgate repetido.
- Indicador da última jogada e destaque da peça recém-movida no Ludo.
- Modo leve automático com opção manual; reduz detalhes decorativos em aparelhos com menos recursos.
- Temas de acabamento dourado suave, prata lunar e violeta, sem mudar regras ou posições. Preferências ficam salvas no navegador.

## Banco e publicação
A migração aditiva `202611170004_social` cria amizades, convites e a coluna do balão equipado. `npm start` aplica as migrações automaticamente quando DATABASE_URL está configurada, como já ocorre no projeto. Não há nova credencial a configurar.

A compilação e testes locais cobrem regras, permissões, débito/reembolso, revanche e montagem das seis mesas. Não há PostgreSQL ou credenciais Google de produção neste ambiente para testar a migração e o fluxo da conta ao vivo. O pacote não publica automaticamente no Render.
