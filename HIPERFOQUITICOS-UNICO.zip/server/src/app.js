import {DEFAULT_GOOGLE_CLIENT_ID} from '../../shared/oauth-config.js';
import jwt from 'jsonwebtoken';
import {createAccountApp} from '../../account/api.js';
import {createLudoFlow} from './ludo-flow.js';
import {chooseBotAction} from './bots.js';
import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { randomBytes, randomInt } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db/index.js';
import { games } from './games/index.js';
import {configureAuth} from './auth.js';

export function createBoardHub({dbPath=process.env.DB_PATH || './data/boardhub.sqlite',graceMs=60000,ludoTimings={},ludoRandom=n=>randomInt(n)}={}) {
  const app=express(), http=createServer(app), rooms=new Map();
  const db=openDatabase(dbPath);
  const allowed=process.env.CLIENT_ORIGIN?.split(',').map(s=>s.trim());
  const io=new Server(http,{maxHttpBufferSize:8192,cors:allowed?{origin:allowed}:undefined,
    allowRequest:(req,callback)=>callback(null,!req.headers.origin || (allowed?allowed.includes(req.headers.origin):req.headers.origin===`https://${req.headers.host}` || req.headers.origin===`http://${req.headers.host}`))});
  app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');if(req.path.startsWith('/3d')||['/','/lobby','/profile','/shop'].includes(req.path)||req.path.startsWith('/room/')||req.path.startsWith('/game/')){res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' https://accounts.google.com; style-src 'self' 'unsafe-inline' https://accounts.google.com https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; frame-src https://accounts.google.com; connect-src 'self' https://accounts.google.com; img-src 'self' data: https:; base-uri 'none'; frame-ancestors 'none'");return next();}res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data: https://*.googleusercontent.com; script-src 'self'; style-src 'self'; connect-src 'self' ws: wss:; base-uri 'none'; frame-ancestors 'none'");next();});
  app.get('/health',(_,res)=>res.json({ok:true}));
  configureAuth(app,io,db);
  app.get('/api/public-config',(_,res)=>{const value=process.env.GOOGLE_CLIENT_ID||DEFAULT_GOOGLE_CLIENT_ID;res.set('Cache-Control','no-store');res.json({googleClientId:/^[a-zA-Z0-9._-]+\.apps\.googleusercontent\.com$/.test(value.trim())?value.trim():'',accountsEnabled:!!(process.env.DATABASE_URL&&process.env.JWT_SECRET)});});
  const accountApp=process.env.DATABASE_URL&&process.env.JWT_SECRET?createAccountApp():null;
  if(accountApp)app.use(accountApp);
  else app.use(['/api/auth/google','/api/profile','/api/games','/api/shop','/api/inventory','/api/recover','/api/dice'],(_,res)=>res.status(503).json({error:'Conta global ainda não configurada. Use o modo convidado.'}));
  // app.js está em server/src: dois níveis chegam à raiz do projeto.
  const assets=fileURLToPath(new URL('../../client/public/',import.meta.url));
  app.get(['/','/lobby','/profile','/shop','/room/:gameId','/game/:gameId'],(_,res)=>{res.set('Cache-Control','no-store');res.sendFile(assets+'3d/index.html');});
  app.get('/legacy',(_,res)=>res.sendFile(assets+'index.html'));
  app.use(express.static(assets));
  app.get('/join/:code',(_,res)=>res.sendFile(assets+'index.html'));
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const code=()=>Array.from({length:6},()=>alphabet[randomInt(alphabet.length)]).join('');
  const clean=(v,max)=>{
    if(typeof v!=='string') throw Error('Texto inválido.');
    const s=v.replace(/[\u0000-\u001f\u007f<>]/g,'').trim();
    if(!s || s.length>max) throw Error(`Use de 1 a ${max} caracteres.`);return s;
  };
  function system(r,text) {r.chat.push({id:randomBytes(8).toString('hex'),name:'BoardHub',text,time:Date.now(),system:true});r.chat=r.chat.slice(-100);}
  let accountJobTask=null;
  function flushAccountJobs(){if(!accountApp)return Promise.resolve();if(accountJobTask)return accountJobTask;
    accountJobTask=(async()=>{for(const job of db.accountJobs()){try{await accountApp.locals[job.type](job.record);db.completeAccountJob(job.id);}catch(e){console.error('Sincronização de conta será repetida',e.code||e.message);break;}}})().finally(()=>{accountJobTask=null;});return accountJobTask;
  }
  function queueAccountJob(type,record){db.enqueueAccountJob(type,record);flushAccountJobs();}
  const accountJobInterval=accountApp?setInterval(()=>{flushAccountJobs().then(()=>accountApp.locals.recoverHeld([...rooms.values()].filter(r=>r.status==='playing'||r.starting).map(r=>r.escrowId).filter(Boolean))).catch(e=>console.error('Recuperação de potes será repetida',e.code||e.message));},5000):null;accountJobInterval?.unref?.();
  async function reserveStake(r,round){if(!r.options.stake)return;
    if(!accountApp||r.players.some(p=>!p.bot&&!p.accountId?.startsWith('platform:')))throw Error('Apostas exigem conta Google.');if(r.players.some(p=>p.bot)&&(!r.solo||r.players.filter(p=>!p.bot).length!==1))throw Error('Aposta com bots exige sala solo.');
    const id='stake:'+r.instance+':'+round;const escrow=await accountApp.locals.reserveWager({id,gameId:r.gameId,stake:r.options.stake,players:r.players.map(p=>({id:p.bot?'bot:'+p.id:p.accountId.slice(9),mark:p.mark,bot:!!p.bot}))});r.escrowId=id;r.pot=escrow.pot;
  }
  function captures(r,color,next){if(!r.escrowId||!accountApp)return;const p=r.players.find(p=>p.mark===color);if(!p?.accountId?.startsWith('platform:'))return;
    const count=r.gameId==='ludo'?next.lastEvent?.captured?.length||0:r.gameId.startsWith('checkers')?next.lastMove?.captures?.length||0:r.gameId==='chess'?(next.lastChessMove?.san?.includes('x')?1:0):r.gameId==='battleship'&&next.lastEvent?.result==='sunk'?1:0;
    if(count)queueAccountJob('recordCapture',{id:'capture:'+r.instance+':'+next.round+':'+(next.revision??next.ply),matchId:r.escrowId,userId:p.accountId.slice(9),count});
  }
  function applyTimed(r,color,action){
    if(action.type==='bot')action=chooseBotAction(games.ludo,{...r.game,botDifficulty:r.options.difficulty},color,n=>randomInt(n));
    if(!action)return;
    const next=games.ludo.applyAction(r.game,color,action,ludoRandom);captures(r,color,next);r.game=next;
    if(action.type==='power'&&accountApp){const player=r.players.find(p=>p.mark===color);if(player?.accountId?.startsWith('platform:'))queueAccountJob('recordPowerUse',{id:'power:'+r.instance+':'+next.round+':'+next.revision,userId:player.accountId.slice(9)});}
    next.bonusQueued=!!r.bonusQueued;
    const now=Date.now();
    if(action.type==='roll'||action.power==='control'){
      r.diceAnimation={id:randomBytes(8).toString('hex'),color,value:next.lastEvent?.type==='triple-six'?6:next.die,startsAt:now,endsAt:now+(ludoTimings.roll??1800)};
      r.ludoLockedUntil=r.diceAnimation.endsAt;
    }else if(action.type==='move')r.ludoLockedUntil=now+(ludoTimings.move??1300);
    else r.ludoLockedUntil=0;
    if(next.winner)finish(r,next.winner,next.reason);
  }
  const syncLudo=createLudoFlow({engine:games.ludo,apply:applyTimed,publish:r=>publish(r),timings:ludoTimings});
  function publish(r) {
    syncLudo(r);
    if(r.gameId!=='ludo' && r.players.some(p=>p.bot) && r.status==='playing' && !r.botTimer && !r.game.winner && r.players.some(p=>!p.bot&&p.socket)){
      r.botTimer=setTimeout(()=>{
        r.botTimer=null;if(r.status!=='playing'||r.game.winner)return;
        const engine=games[r.gameId];
        for(const bot of r.players.filter(p=>p.bot)){
          const action=chooseBotAction(engine,{...r.game,botDifficulty:r.options.difficulty},bot.mark,n=>randomInt(n));
          if(!action)continue;
          try{r.game=engine.applyAction(r.game,bot.mark,action,n=>randomInt(n));
          if(r.game.winner)finish(r,r.game.winner,r.game.reason);publish(r);}catch(e){console.error('Bot action failed',r.gameId,e.message);}
          return;
        }
      },650);r.botTimer.unref?.();
    }
    const engine=games[r.gameId];
    if(engine.publicState){for(const p of r.players)if(p.socket)io.to(p.socket).emit('game:state',{serverNow:Date.now(),stake:r.options.stake||0,pot:r.pot||0,solo:r.solo,code:r.code,gameId:r.gameId,gameName:engine.name,legalMoves:engine.legalActions(r.game,p.mark),host:r.host,status:r.status,drawOffer:null,game:engine.publicState(r.game,p.mark),chat:r.chat,scores:db.score(r.code),history:db.history(r.code),players:r.players.map(q=>({id:q.id,name:q.name,mark:q.mark,picture:q.picture||null,avatar:q.avatar,frame:q.frame,dice:q.dice,online:!!q.socket,deadline:q.deadline||null}))});return;}
    const actions=engine.legalActions?.(r.game,r.game.players?.[r.game.turnIndex]?.color) || engine.legalMoves?.(r.game) || [];
    io.to(r.code).emit('game:state',{serverNow:Date.now(),stake:r.options.stake||0,pot:r.pot||0,solo:r.solo,code:r.code,gameId:r.gameId,gameName:engine.name,legalMoves:actions,drawOffer:r.drawOffer || null,host:r.host,status:r.status,
      game:{...r.game,...(r.gameId==='ludo'?{diceAnimation:r.diceAnimation||null}:{})},chat:r.chat,scores:db.score(r.code),history:db.history(r.code),
      players:r.players.map(p=>({id:p.id,name:p.name,mark:p.mark,picture:p.picture||null,avatar:p.avatar,frame:p.frame,dice:p.dice,online:!!p.socket,deadline:p.deadline || null}))});
  }
  function finish(r,winner,reason) {
    if(r.status!=='playing') return;
    r.game={...r.game,winner,reason};if(r.gameId==='ludo'){for(const player of r.game.players){player.inventory={};player.shields=[];player.shield=null;}r.game.powerDrops=[];r.bonusQueued=false;}db.finish(r.code,r.game,r.players);r.status='finished';r.drawOffer=null;
    if(accountApp&&r.escrowId){const winners=r.players.filter(p=>r.game.winningTeam?r.game.winningTeam.includes(p.mark):p.mark===winner).map(p=>p.bot?'bot:'+p.id:p.accountId.slice(9));queueAccountJob('settleWager',{id:r.escrowId,draw:winner==='draw',winners,teams:r.game.teams?.map(t=>r.players.filter(p=>t.includes(p.mark)).map(p=>p.bot?'bot:'+p.id:p.accountId.slice(9)))});}
    if(accountApp){for(const p of r.players.filter(p=>p.accountId?.startsWith('platform:'))){
      const userId=p.accountId.slice(9),outcome=winner==='draw'?'draw':(r.game.winningTeam?r.game.winningTeam.includes(p.mark):winner===p.mark)?'victory':'defeat';
      const record={userId,matchId:'room:'+r.instance+':'+r.game.round+':'+userId,gameName:games[r.gameId].name,escrowId:r.escrowId||null,outcome,difficulty:r.options.difficulty||'medium',opponent:r.players.filter(q=>q!==p).map(q=>q.name).join(', ').slice(0,160)};
      queueAccountJob('recordRoomResult',record);
    }}
    system(r,winner==='draw'?'A partida empatou.':`${r.players.find(p=>p.mark===winner)?.name} venceu (${reason}).`);
  }
  function detach(r,p,reason) {
    clearTimeout(p.timer);
    if(r.gameId==='ludo'){const participant=r.game.players.find(q=>q.color===p.mark);if(participant){participant.inventory={};participant.shields=[];participant.shield=null;}}
    if(r.status==='playing') {
      const remaining=r.players.filter(q=>q!==p);
      const winner=remaining.length===1?remaining[0].mark:'draw';
      if(r.options.stake&&remaining.length>1){const losingTeam=r.game.teams?.find(t=>t.includes(p.mark));const winners=remaining.filter(q=>!losingTeam?.includes(q.mark));r.game.winningTeam=winners.map(q=>q.mark);finish(r,winners[0]?.mark||'draw',reason);}else finish(r,winner,reason);
    }
    r.players=r.players.filter(q=>q!==p);
    const old=io.sockets.sockets.get(p.socket);
    if(old) {old.leave(r.code);old.data.room=null;old.emit('room:removed',{reason});}
    if(r.host===p.id) r.host=r.players[0]?.id || null;
    system(r,`${p.name} saiu: ${reason}.`);
    r.touched=Date.now();publish(r);
  }
  io.use(async(socket,next)=>{try{const token=socket.handshake.auth?.token;if(token){if(!accountApp)throw Error('Conta global não configurada');socket.data.platformUser=await accountApp.locals.socketProfile(token);}next();}catch{next(Error('Entre novamente no painel 3D.'));}});
  io.on('connection',socket=>{
    let count=0, windowStart=Date.now(),lastChat=0;
    const current=()=>{
      const r=rooms.get(socket.data.room), p=r?.players.find(p=>p.socket===socket.id);
      if(!r || !p) throw Error('Entre em uma sala primeiro.');
      if(p.accountId?.startsWith('platform:')){try{const token=jwt.verify(socket.handshake.auth.token,process.env.JWT_SECRET,{algorithms:['HS256'],issuer:'boardhub-3d',audience:'boardhub-player'});if('platform:'+token.sub!==p.accountId)throw Error();}catch{throw Error('Entre novamente no painel 3D.');}}
      else if(p.accountId&&db.getSession(socket.request.sessionID)?.passport?.user!==p.accountId)throw Error('Sessão encerrada. Entre novamente com Google.');
      r.touched=Date.now();return {r,p};
    };
    const hostOnly=(r,p)=>{if(r.host!==p.id) throw Error('Apenas o anfitrião pode fazer isso.');};
    const playersReady=r=>{const game=games[r.gameId];if(r.players.length<game.minPlayers || r.players.some(p=>!p.socket)) throw Error(`Aguarde pelo menos ${game.minPlayers} jogadores conectados.`);};
    // Teto de dez eventos/segundo por conexão (inclui chat e ações inválidas).
    const on=(event,fn)=>socket.on(event,async(data,ack)=>{
      try {
        if(Date.now()-windowStart>=1000){count=0;windowStart=Date.now();}
        if(++count>10) throw Error('Limite de 10 ações por segundo.');
        if(!data || typeof data!=='object' || Array.isArray(data)) throw Error('Payload inválido.');
        if(rooms.get(socket.data.room)?.starting)throw Error('A partida está sendo iniciada. Aguarde.');const result=await fn(data);if(typeof ack==='function') ack({ok:true,...result});
      } catch(e) {if(typeof ack==='function') ack({ok:false,error:e.message});}
    });
    function enter(data,create) {
      if(socket.data.room) throw Error('Saia da sala atual primeiro.');
      const googleEnabled=!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET);
      const accountId=googleEnabled?db.getSession(socket.request.sessionID)?.passport?.user:null;
      const account=socket.data.platformUser||(googleEnabled&&accountId?db.getUser(accountId):null);

      const name=clean(account?account.name.slice(0,24):data.name,24);
      let r;
      if(create) {
        if(rooms.size>=1000) throw Error('Servidor cheio.');
        const gameId=data.gameId || 'tic-tac-toe';
        if(!Object.hasOwn(games,gameId))throw Error('Jogo inválido.');
        let id;do{id=code();}while(rooms.has(id) || db.roomExists(id));
        const stake=Number(data.stake||0);if(!Number.isSafeInteger(stake)||stake<0||stake>1000)throw Error('Aposta inválida');if(stake&&!account?.id.startsWith('platform:'))throw Error('Entre com Google para apostar Foticas');
        const options={stake,difficulty:['easy','medium','hard'].includes(data.difficulty)?data.difficulty:'medium',...(gameId==='ludo'?{mode:data.mode,acquisition:data.acquisition}:{})};
        r={instance:randomBytes(12).toString('hex'),solo:data.solo===true,code:id,gameId,options,players:[],host:null,game:games[gameId].createState(1,options),status:'waiting',chat:[],touched:Date.now()};rooms.set(id,r);
      } else {r=rooms.get(String(data.code).toUpperCase());if(!r) throw Error('Sala não encontrada ou expirada.');}
      if(r.options.stake>0&&!account?.id.startsWith('platform:'))throw Error('Entre na conta para participar de uma aposta.');
      let p=account?r.players.find(p=>p.accountId===account.id):(typeof data.token==='string'?r.players.find(p=>p.token===data.token):null);
      if(r.solo && !p && r.players.length)throw Error('Sala exclusiva contra o computador. Crie uma sala com amigos para convidar.');
      if(!account&&p?.accountId)throw Error('Entre na conta original para retomar esta sala.');
      if(p?.socket) throw Error('Este jogador já está conectado.');
      const reconnect=!!p;
      if(!p) {
        if(r.players.length>=games[r.gameId].maxPlayers) throw Error('Sala cheia.');
        if(r.status==='playing') throw Error('A partida já começou.');
        const mark=games[r.gameId].playerMarks.find(value=>!r.players.some(p=>p.mark===value));
        p={id:randomBytes(12).toString('hex'),accountId:account?.id||null,picture:account?.picture||null,avatar:account?.avatar||null,frame:account?.frame||'none',dice:account?.dice||'classic',name,mark,token:randomBytes(24).toString('hex')};
        db.register(r.code,p);r.players.push(p);if(!r.host) r.host=p.id;
      }
      clearTimeout(p.timer);p.deadline=null;p.socket=socket.id;
      socket.data.room=r.code;socket.join(r.code);r.touched=Date.now();
      system(r,`${p.name} ${reconnect?'voltou à':'entrou na'} sala.`);
      if(reconnect) io.to(r.code).emit('player:reconnect',{playerId:p.id});
      publish(r);return {code:r.code,token:p.token,playerId:p.id,mark:p.mark};
    }
    on('room:create',d=>enter(d,true));on('room:join',d=>enter(d,false));
    on('room:leave',()=>{const {r,p}=current();detach(r,p,'desistência');});
    on('room:kick',d=>{
      const {r,p}=current();hostOnly(r,p);
      if(r.options.stake&&r.status==='playing')throw Error('Não é permitido expulsar em partida apostada.');
      const target=r.players.find(q=>q.id===d.playerId && q!==p);
      if(!target) throw Error('Jogador inválido.');detach(r,target,'expulsão pelo anfitrião');
    });
    on('matchmaking:join',async d=>{
      const profile=accountApp&&socket.handshake.auth?.token?await accountApp.locals.socketProfile(socket.handshake.auth.token):null;socket.data.platformUser=profile;if(!profile)throw Error('Entre na conta para buscar partidas por ranking.');
      const stake=Number(d.stake||10),gameId=d.gameId;if(!games[gameId])throw Error('Jogo inválido');
      const rating=profile.ratings?.find(r=>r.gameId===gameId)?.elo||1000;
      const target=[...rooms.values()].find(r=>r.status==='waiting'&&!r.starting&&r.gameId===gameId&&!r.solo&&r.options.stake===stake&&r.players.length<games[gameId].maxPlayers&&Math.abs((r.matchRating||1000)-rating)<=200);
      const result=target?enter({code:target.code,name:profile.name},false):enter({...d,stake,name:profile.name},true);const room=rooms.get(result.code);room.matchRating??=rating;return result;
    });
    on('room:fill-bots',()=>{
      const {r,p}=current();hostOnly(r,p);
      if(r.status!=='waiting')throw Error('Complete a sala antes de iniciar.');if(r.options.stake&&!r.solo)throw Error('Bots com aposta exigem sala solo.');
      const profiles=[['Luna','🌙'],['Orion','🦊'],['Nina','🐼'],['Atlas','🦉']];
      for(const mark of games[r.gameId].playerMarks){if(r.players.some(q=>q.mark===mark))continue;
        const [name,avatar]=profiles[randomInt(profiles.length)];
        const bot={id:randomBytes(12).toString('hex'),name:avatar+' '+name+' · Bot '+(r.players.length+1),mark,bot:true,socket:'bot'};
        r.players.push(bot);db.register(r.code,bot);
      }
      publish(r);
    });
    on('room:start',async d=>{
      const {r,p}=current();hostOnly(r,p);r.starting=true;try{
      if(r.solo && r.players.length===1){for(const mark of games[r.gameId].playerMarks.slice(1)){
        const bot={id:randomBytes(12).toString('hex'),name:'Computador '+mark,mark,bot:true,socket:'bot'};r.players.push(bot);db.register(r.code,bot);
      }}
      playersReady(r);
      if(r.status!=='waiting') throw Error('Use reiniciar para uma nova partida.');
      if(r.gameId==='ludo' && [true,'together','versus'].includes(d.teams)){
        const humans=r.players.filter(p=>!p.bot),bots=r.players.filter(p=>p.bot);
        if(r.players.length!==4)throw Error('Duplas exigem quatro jogadores.');
        if(humans.length===4)r.players=d.teams==='versus'?humans:[humans[0],humans[2],humans[1],humans[3]];
        else{if(humans.length!==2||bots.length!==2)throw Error('Use quatro humanos ou dois humanos e dois bots.');r.players=d.teams==='versus'?[humans[0],humans[1],bots[0],bots[1]]:[humans[0],bots[0],humans[1],bots[1]];}
        r.players.forEach((player,index)=>{player.mark=games.ludo.playerMarks[index];});
        r.options.teams=[['red','yellow'],['green','blue']];r.game.teams=r.options.teams;
      }
      await reserveStake(r,r.game.round);
      if(games[r.gameId].startGame)r.game=games[r.gameId].startGame(r.game,r.players.map(p=>p.mark));
      r.status='playing';system(r,games[r.gameId].name+': partida iniciada.');publish(r);
      }finally{r.starting=false;}
    });
    on('room:restart',async()=>{
      const {r,p}=current();hostOnly(r,p);playersReady(r);r.starting=true;try{
      if(r.options.stake&&r.status==='playing')throw Error('Termine a partida apostada antes da revanche.');
      await reserveStake(r,r.game.round+1);
      // Reinício no meio da partida fica no histórico como partida anulada.
      if(r.status==='playing') system(r,'O anfitrião reiniciou a partida em andamento (sem pontuação).');
      clearTimeout(r.ludoTimer);r.ludoTimerKey=null;r.ludoLockedUntil=0;r.diceAnimation=null;r.bonusQueued=false;
      r.game=games[r.gameId].createState(r.game.round+1,r.options);
      if(games[r.gameId].startGame)r.game=games[r.gameId].startGame(r.game,r.players.map(p=>p.mark));
      r.drawOffer=null;r.status='playing';system(r,'Nova partida iniciada.');publish(r);
      }finally{r.starting=false;}
    });
    on('ludo:bonus-queue',()=>{
      const {r,p}=current();if(r.gameId!=='ludo'||r.status!=='playing'||r.game.phase!=='move'||r.game.flow?.state==='PROCESSANDO')throw Error('Aguarde a escolha de peça.');
      const me=r.game.players[r.game.turnIndex];if(me.color!==p.mark||!me.inventory.bonus||r.game.bonusChainBlocked)throw Error('Rolagem bônus indisponível.');
      r.bonusQueued=!r.bonusQueued;r.game.bonusQueued=r.bonusQueued;publish(r);
    });
    on('game:action',action=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing') throw Error('A partida não está em andamento.');
      if(r.gameId==='ludo'){
        if(action.type==='pass'||action.type==='end-turn')throw Error('O turno é processado automaticamente.');
        if(r.game.flow?.state==='PROCESSANDO')throw Error('Aguarde a animação.');
        applyTimed(r,p.mark,action);publish(r);return;
      }
      const next=games[r.gameId].applyAction(r.game,p.mark,action,n=>randomInt(n));
      r.drawOffer=null;
      // finish centraliza o registro único da vitória/empate no banco.
      captures(r,p.mark,next);r.game=next;
      if(next.lastMove){const m=next.lastMove;system(r,`${p.name} moveu ${m.path.map(i=>String.fromCharCode(97+i%8)+(8-Math.floor(i/8))).join(' → ')}${m.captures.length?' · capturas: '+m.captures.length:''}${m.promoted?' · virou dama':''}.`);}
      if(next.lastEvent&&r.gameId==='ludo')system(r,`${p.name}: ${JSON.stringify(next.lastEvent)}.`);
      if(next.winner) finish(r,next.winner,next.reason);
      publish(r);
    });
    on('game:draw-offer',()=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing')throw Error('Não há partida em andamento.');
      if(r.drawOffer)throw Error('Já existe uma proposta pendente.');
      r.drawOffer=p.id;system(r,`${p.name} propôs empate.`);publish(r);
    });
    on('game:draw-answer',d=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing' || !r.drawOffer || r.drawOffer===p.id || typeof d.accept!=='boolean')throw Error('Proposta inválida.');
      if(d.accept)finish(r,'draw','acordo entre jogadores');
      else system(r,`${p.name} recusou o empate.`);
      r.drawOffer=null;publish(r);
    });
    on('game:resign',()=>{
      const {r,p}=current();if(r.status!=='playing') throw Error('Não há partida em andamento.');
      const others=r.players.filter(q=>q!==p);finish(r,others.length===1?others[0].mark:'draw','desistência');publish(r);
    });
    on('chat:message',d=>{
      const {r,p}=current();const text=clean(d.text,400);
      if(Date.now()-lastChat<700) throw Error('Espere um instante entre mensagens.');lastChat=Date.now();
      r.chat.push({id:randomBytes(8).toString('hex'),name:p.name,text,time:Date.now(),mark:p.mark});r.chat=r.chat.slice(-100);publish(r);
    });
    socket.on('disconnect',()=>{
      const r=rooms.get(socket.data.room),p=r?.players.find(p=>p.socket===socket.id);if(!p)return;
      p.socket=null;p.deadline=Date.now()+graceMs;system(r,`${p.name} desconectou. A partida está pausada por até 60 segundos.`);
      io.to(r.code).emit('player:disconnect',{playerId:p.id,deadline:p.deadline});
      p.timer=setTimeout(()=>{if(!p.socket) detach(r,p,'tempo de reconexão esgotado');},graceMs);p.timer.unref();publish(r);
    });
  });
  const cleanup=setInterval(()=>{for(const [id,r] of rooms) if(!r.players.length && Date.now()-r.touched>1800000) rooms.delete(id);},60000);cleanup.unref();
  return {http,io,rooms,async close(){clearInterval(cleanup);clearInterval(accountJobInterval);for(const r of rooms.values()){clearTimeout(r.ludoTimer);clearTimeout(r.botTimer);for(const p of r.players)clearTimeout(p.timer);}await new Promise(resolve=>io.close(resolve));if(accountJobTask)await accountJobTask;await accountApp?.locals.close?.();db.close();}};
}
