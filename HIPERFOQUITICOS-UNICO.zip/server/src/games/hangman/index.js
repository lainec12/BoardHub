import {randomInt} from 'node:crypto';
export const WORDS={
'Cinema':['Interestelar','A Origem','O Labirinto do Fauno','Um Sonho de Liberdade','A Sociedade dos Poetas Mortos','O Grande Hotel Budapeste','O Silêncio dos Inocentes','O Poderoso Chefão'],
'Animes e séries':['Death Note','Fullmetal Alchemist','Supernatural','Dark','Stranger Things','Daemons of the Shadow Realm','Neon Genesis Evangelion'],
'Animais':['Capivara','Axolote','Ornitorrinco','Pangolim','Equidna','Celacanto','Quokka'],
'Comidas':['Brigadeiro','Pão de queijo','Bacalhau','Ratatouille','Pavlova','Boeuf Bourguignon'],
'Futebol':['Santos','Vila Nova','Impedimento','Libertadores','Maracanã','Contra ataque'],
'Mitologia':['Medusa','Perséfone','Quimera','Hecatônquiros','Ouroboros','Nêmesis'],
'Ciência':['Fotossíntese','Mitocôndria','Desoxirribonucleico','Espectrofotometria','Eletromagnetismo'],
'Palavras raras':['Idiossincrasia','Hermenêutica','Epistemologia','Circunlóquio','Inconstitucionalidade','Pusilanimidade','Prolegômenos','Anticonstitucionalissimamente'],
'Geografia':['Tocantins','Cazaquistão','Liechtenstein','Antananarivo','Ouagadougou','Tegucigalpa'],
'Contabilidade':['Patrimônio','Amortização','Exigibilidade','Imunidade tributária','Equivalência patrimonial'],
'Adivinhas':['Espelho','Sombra','Eco','Relógio','Horizonte','Silêncio'],
'Música':['Samba','Luan Santana','Bossa Nova','Rapsódia Boêmia','Sinfonia'],
};
const norm=s=>s.normalize('NFD').replace(/\p{Diacritic}/gu,'').toUpperCase();
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
export function createState(round=1,options={}){return {variant:'hangman',round,revision:0,category:typeof options.hangmanCategory==='string'&&Object.hasOwn(WORDS,options.hangmanCategory)?options.hangmanCategory:'Surpresa',difficulty:['easy','medium','hard','expert'].includes(options.hangmanDifficulty)?options.hangmanDifficulty:'expert',players:[],turnIndex:0,word:'',guessed:[],winner:null};}
export function startGame(s,marks,rng=randomInt){const n=structuredClone(s);n.players=marks.map(color=>({color,score:0,errors:0}));const keys=Object.keys(WORDS);n.category=Object.hasOwn(WORDS,n.category)?n.category:keys[rng(keys.length)];const list=WORDS[n.category].slice().sort((a,b)=>a.length-b.length);const range=n.difficulty==='easy'?list.slice(0,Math.ceil(list.length/2)):n.difficulty==='expert'?list.slice(Math.floor(list.length*0.65)):n.difficulty==='hard'?list.slice(Math.floor(list.length/2)):list.slice(0,Math.ceil(list.length*0.75)); n.word=range[rng(range.length)];return n;}
export function legalActions(s,mark){return s.winner||s.players[s.turnIndex]?.color!==mark?[]:[...alphabet].filter(letter=>!s.guessed.includes(letter)).map(letter=>({type:'guess',letter}));}
export function applyAction(s,mark,a){if(a.round!==s.round||a.revision!==s.revision||!legalActions(s,mark).some(x=>x.type===a.type&&x.letter===a.letter))throw Error('Letra inválida.');const n=structuredClone(s),p=n.players[n.turnIndex],word=norm(n.word);n.revision++;n.guessed.push(a.letter);const hits=[...word].filter(c=>c===a.letter).length;p.score+=hits;if(!hits)p.errors++;if([...word].every(c=>!alphabet.includes(c)||n.guessed.includes(c))||n.players.every(q=>q.errors>=6)){const max=Math.max(...n.players.map(q=>q.score));const wins=n.players.filter(q=>q.score===max);n.winner=wins.length===1?wins[0].color:'draw';n.reason='Palavra: '+n.word;}else{do{n.turnIndex=(n.turnIndex+1)%n.players.length;}while(n.players[n.turnIndex].errors>=6);}return n;}
export function publicState(s){const {word,...rest}=s;return {...rest,pattern:[...word].map(c=>s.winner||!alphabet.includes(norm(c))||s.guessed.includes(norm(c))?c:'_').join('')};}
export function botAction(s,actions,rng){const order='AEOSRINMDUTCLPVGHBQFJXZKWY';return actions.slice().sort((a,b)=>order.indexOf(a.letter)-order.indexOf(b.letter))[0];}
