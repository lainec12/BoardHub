// Registro de jogos: salas compartilham infraestrutura, cada motor guarda suas regras.
import * as ticTacToe from './tic-tac-toe/index.js';
import * as checkers from './checkers/index.js';
import * as ludo from './ludo/index.js';
import * as uno from './uno/index.js';
import * as battleship from './battleship/index.js';
import * as domino from './domino/index.js';
import * as chess from './chess/index.js';
export const games={
  'tic-tac-toe':{name:'Jogo da Velha',minPlayers:2,maxPlayers:2,playerMarks:['X','O'],...ticTacToe},
  'checkers-brazilian':{name:'Damas Brasileiras',minPlayers:2,maxPlayers:2,playerMarks:['X','O'],...checkers,createState:round=>checkers.createState(round,'brazilian')},
  'checkers-english':{name:'Damas Inglesas',minPlayers:2,maxPlayers:2,playerMarks:['X','O'],...checkers,createState:round=>checkers.createState(round,'english')},
  'ludo':{name:'Ludo',minPlayers:2,maxPlayers:4,playerMarks:ludo.COLORS,...ludo},
  'uno':{name:'UNO',minPlayers:2,maxPlayers:4,playerMarks:uno.COLORS,...uno},
  'battleship':{name:'Batalha Naval',minPlayers:2,maxPlayers:2,playerMarks:['X','O'],...battleship},
  'domino':{name:'Dominó',minPlayers:2,maxPlayers:4,playerMarks:domino.COLORS,...domino},
  'chess':{name:'Xadrez',minPlayers:2,maxPlayers:2,playerMarks:['X','O'],...chess}
};
