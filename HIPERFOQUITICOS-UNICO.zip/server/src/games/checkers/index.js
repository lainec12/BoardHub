/**
 * Damas 8×8: brasileiras e inglesas. Motor puro, sem DOM nem rede.
 * Referências e condições de empate: docs/DAMAS.md.
 * X sobe no tabuleiro e inicia (brancas no BR, vermelhas na inglesa).
 * Cada ação contém o caminho COMPLETO, inclusive pousos intermediários.
 */
const directions=[[-1,-1],[-1,1],[1,-1],[1,1]];
const row=i=>Math.floor(i/8), col=i=>i%8;
const inside=(r,c)=>r>=0 && r<8 && c>=0 && c<8;
const crown=(side,i)=>row(i)===(side==='X'?0:7);
const opponent=side=>side==='X'?'O':'X';
export const positionKey=s=>s.turn+':'+s.board.map(p=>p?(p.side+(p.king?'K':'M')):'.').join('');

export function createState(round=1,variant='brazilian') {
  if(!['brazilian','english'].includes(variant))throw Error('Variante de damas inválida.');
  const board=Array.from({length:64},(_,i)=>(row(i)+col(i))%2===1 && (row(i)<3 || row(i)>4)?{side:row(i)<3?'O':'X',king:false}:null);
  const state={board,variant,round,turn:'X',winner:null,reason:null,line:[],ply:0,
    lastMove:null,quietPlies:0,stablePlies:0,endgame:{key:null,plies:0},repetitions:{}};
  state.repetitions[positionKey(state)]=1;return state;
}

function captureSteps(board,from,piece,variant,captured) {
  const steps=[];
  for(const [dr,dc] of directions) {
    if(!piece.king && variant==='english' && dr!==(piece.side==='X'?-1:1))continue;
    let r=row(from)+dr,c=col(from)+dc;
    if(piece.king && variant==='brazilian') {
      // Procura a primeira peça da diagonal; vítimas já saltadas continuam bloqueando.
      while(inside(r,c) && !board[r*8+c]){r+=dr;c+=dc;}
      if(!inside(r,c))continue;
      const victim=r*8+c;
      if(board[victim].side===piece.side || captured.includes(victim))continue;
      r+=dr;c+=dc;
      while(inside(r,c) && !board[r*8+c]){steps.push({to:r*8+c,victim});r+=dr;c+=dc;}
    } else {
      if(!inside(r,c))continue;
      const victim=r*8+c;
      if(!board[victim] || board[victim].side===piece.side || captured.includes(victim))continue;
      r+=dr;c+=dc;
      if(inside(r,c) && !board[r*8+c])steps.push({to:r*8+c,victim});
    }
  }
  return steps;
}

function capturePaths(board,from,piece,variant,path=[from],captured=[]) {
  // Na inglesa, alcançar a última fileira durante captura encerra a sequência.
  const steps=variant==='english' && !piece.king && captured.length && crown(piece.side,from)?[]:captureSteps(board,from,piece,variant,captured);
  if(!steps.length)return captured.length?[{path,captures:captured}]:[];
  return steps.flatMap(({to,victim})=>{
    const next=board.slice();next[from]=null;next[to]=piece;
    if(variant==='english')next[victim]=null;
    // Na brasileira uma pedra não vira dama no meio da sequência.
    return capturePaths(next,to,piece,variant,[...path,to],[...captured,victim]);
  });
}

export function legalMoves(state) {
  if(state.winner)return [];
  const captures=[],quiet=[];
  state.board.forEach((piece,from)=>{
    if(!piece || piece.side!==state.turn)return;
    captures.push(...capturePaths(state.board,from,piece,state.variant));
    for(const [dr,dc] of directions) {
      if(!piece.king && dr!==(piece.side==='X'?-1:1))continue;
      let r=row(from)+dr,c=col(from)+dc;
      while(inside(r,c) && !state.board[r*8+c]) {
        quiet.push({path:[from,r*8+c],captures:[]});
        if(!piece.king || state.variant==='english')break;
        r+=dr;c+=dc;
      }
    }
  });
  if(!captures.length)return quiet;
  if(state.variant==='english')return captures;
  // Lei da maioria: conta peças; dama não tem prioridade sobre pedra.
  const maximum=Math.max(...captures.map(m=>m.captures.length));
  return captures.filter(m=>m.captures.length===maximum);
}

export function validateAction(state,side,action) {
  if(state.winner)throw Error('Esta partida já terminou.');
  if(action.type!=='move')throw Error('Ação desconhecida.');
  if(action.round!==state.round || action.ply!==state.ply)throw Error('Jogada desatualizada.');
  if(side!==state.turn)throw Error('Aguarde sua vez.');
  if(!Array.isArray(action.path) || action.path.length<2 || action.path.length>13 || action.path.some(i=>!Number.isInteger(i)||i<0||i>63))throw Error('Caminho inválido.');
  const selected=legalMoves(state).find(m=>m.path.length===action.path.length && m.path.every((v,i)=>v===action.path[i]));
  if(!selected)throw Error('Jogada ilegal. Respeite a captura obrigatória e complete a sequência destacada.');
  return selected;
}

// Redução de material e contadores regulamentares da referência FMJD 64.
function endingLimit(state) {
  const sides=['X','O'].map(side=>state.board.map((p,i)=>p?.side===side?{...p,i}:null).filter(Boolean));
  for(let i=0;i<2;i++) {
    const lone=sides[i],other=sides[1-i];
    if(lone.length!==1 || !lone[0].king)continue;
    const longDiagonal=row(lone[0].i)+col(lone[0].i)===7;
    if(other.length<=2 && other.some(p=>p.king))return {key:`small-${i}`,limit:10};
    if(other.length===3 && other.some(p=>p.king) && longDiagonal)return {key:`long-${i}`,limit:10};
    if(other.length>=3 && other.every(p=>p.king))return {key:`three-${i}`,limit:30};
  }
  return null;
}

export function applyAction(state,side,action) {
  const move=validateAction(state,side,action),next=structuredClone(state);
  const from=move.path[0],to=move.path.at(-1),piece=next.board[from];
  const wasKing=piece.king;next.board[from]=null;
  for(const i of move.captures)next.board[i]=null;
  const promoted=!piece.king && crown(side,to);
  next.board[to]={...piece,king:piece.king || promoted};
  next.lastMove={side,path:move.path,captures:move.captures,promoted};next.ply++;
  next.turn=opponent(side);
  next.quietPlies=wasKing && !move.captures.length?state.quietPlies+1:0;
  next.stablePlies=move.captures.length || promoted?0:state.stablePlies+1;
  if(!legalMoves(next).length) {next.winner=side;next.reason='adversário sem jogadas';return next;}
  // Posições de antes de capturas/movimentos de pedra não podem ser repetidas.
  if(move.captures.length || !wasKing)next.repetitions={};
  const key=positionKey(next);next.repetitions[key]=(next.repetitions[key] || 0)+1;
  if(next.repetitions[key]>=3){next.winner='draw';next.reason='repetição tripla';return next;}
  let reason=null;
  if(next.variant==='english') {
    if(next.quietPlies>=80)reason='40 lances por jogador sem captura nem movimento de pedra';
  } else {
    const ending=endingLimit(next),previous=endingLimit(state);
    next.endgame={key:ending?.key || null,plies:ending && previous?.key===ending.key?(state.endgame?.plies || 0)+1:0};
    const total=next.board.filter(Boolean).length;
    const bothKings=['X','O'].every(s=>next.board.some(p=>p?.side===s && p.king));
    if(ending && next.endgame.plies>=ending.limit)reason='limite de final reduzido';
    else if(next.quietPlies>=30)reason='15 lances por jogador somente com damas sem captura';
    else if(bothKings && total>=4 && total<=5 && next.stablePlies>=60)reason='30 lances por jogador em final de 4–5 peças';
    else if(bothKings && total>=6 && total<=7 && next.stablePlies>=120)reason='60 lances por jogador em final de 6–7 peças';
  }
  if(reason){next.winner='draw';next.reason=reason;}
  return next;
}
