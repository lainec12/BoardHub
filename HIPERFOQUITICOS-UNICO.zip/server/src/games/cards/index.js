import {randomInt} from 'node:crypto';
const suits=['♦','♠','♥','♣'];const clone=s=>structuredClone(s);
function shuffled(cards,rng){for(let i=cards.length-1;i>0;i--){const j=rng(i+1);[cards[i],cards[j]]=[cards[j],cards[i]];}return cards;}
export function canClose(cards){if(cards.length!==9)return false;const sorted=[...cards];const valid=g=>new Set(g.map(c=>c.rank)).size===1&&new Set(g.map(c=>c.suit)).size===g.length||new Set(g.map(c=>c.suit)).size===1&&g.map(c=>c.rank).sort((a,b)=>a-b).every((v,i,a)=>!i||v===a[i-1]+1);
function split(left){if(!left.length)return true;for(let mask=1;mask<(1<<left.length);mask++){if(!(mask&1))continue;const g=left.filter((_,i)=>mask&(1<<i));if(g.length<3||!valid(g))continue;if(split(left.filter((_,i)=>!(mask&(1<<i)))))return true;}return false;}return split(sorted);}

export function createCardEngine(kind='cacheta'){
 if(kind!=='cacheta')throw Error('Jogo não disponível.');
 function createState(round=1){return {variant:'cacheta',round,revision:0,players:[],turnIndex:0,pile:[],discard:[],phase:'draw',winner:null,lastEvent:null};}
 function startGame(s,marks,rng=randomInt){if(marks.length<2||marks.length>4)throw Error('Quantidade inválida de jogadores.');const n=clone(s);n.players=marks.map(color=>({color,hand:[]}));n.pile=shuffled(Array.from({length:104},(_,id)=>({id,rank:id%13+1,suit:suits[Math.floor(id/13)%4]})),rng);for(const p of n.players)p.hand=Array.from({length:9},()=>n.pile.pop());n.discard=[n.pile.pop()];n.turnIndex=rng(marks.length);n.revision++;return n;}
 function legalActions(s,mark){if(s.winner||s.players[s.turnIndex]?.color!==mark)return [];const p=s.players[s.turnIndex];return s.phase==='draw'?[{type:'draw-stock'},...(s.discard.length?[{type:'draw-discard'}]:[])]:p.hand.map(c=>({type:'discard',card:c.id}));}
 function applyAction(s,mark,a,rng=randomInt){if(a.round!==s.round||a.revision!==s.revision)throw Error('Ação desatualizada.');if(!legalActions(s,mark).some(x=>Object.entries(x).every(([k,v])=>a[k]===v)))throw Error('Ação inválida.');const n=clone(s),p=n.players[n.turnIndex];n.revision++;n.lastEvent={type:a.type,color:mark};
 if(a.type.startsWith('draw-')){if(a.type==='draw-stock'&&!n.pile.length){const top=n.discard.pop();n.pile=shuffled(n.discard,rng);n.discard=top?[top]:[];}const card=a.type==='draw-stock'?n.pile.pop():n.discard.pop();if(!card){n.winner='draw';n.reason='baralho esgotado';return n;}p.hand.push(card);n.phase='discard';return n;}
 n.discard.push(p.hand.splice(p.hand.findIndex(c=>c.id===a.card),1)[0]);if(canClose(p.hand)){n.winner=mark;n.reason='fechou nove cartas em jogos válidos';}else{n.turnIndex=(n.turnIndex+1)%n.players.length;n.phase='draw';}return n;}
 function publicState(s,mark){const {pile,...v}=clone(s);return {...v,stockCount:pile.length,players:s.players.map(p=>({color:p.color,count:p.hand.length,...(p.color===mark?{hand:clone(p.hand)}:{})}))};}
 return {createState,startGame,legalActions,applyAction,publicState};
}
