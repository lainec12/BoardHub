import {randomInt} from 'node:crypto';
import {populateDrops,collectDrop,populateBonuses,respawnBonus} from './drops.js';
/**
 * Ludo autoritativo para 2–4 jogadores.
 * O cliente nunca informa dado, captura, prêmio aleatório ou inventário.
 */
export const COLORS=['red','green','yellow','blue'];
import {START,SAFE} from '../../../../client/public/ludo-map.js';
export {START,SAFE};
export const POWER_CELLS=new Set([5,18,31,44]);
export const POWERS=['double','control','shield'];


const clone=value=>structuredClone(value);
const randomIndex=(length,rng)=>Math.max(0,Math.min(length-1,Number(rng(length))||0));
const globalCell=(color,progress)=>progress>=0&&progress<52?(START[color]+progress)%52:null;
const totalInventory=inv=>POWERS.reduce((sum,p)=>sum+(inv[p]||0),0);
const playerOf=(state,color)=>state.players.find(p=>p.color===color);
const current=state=>state.players[state.turnIndex];
export const movingPlayer=state=>{const p=current(state);if(!p||!p.tokens.every(v=>v===57))return p;const team=state.teams?.find(t=>t.includes(p.color));return state.players.find(q=>team?.includes(q.color)&&!q.tokens.every(v=>v===57))||p;};
const assertVersion=(s,a)=>{if(a.round!==s.round||a.revision!==s.revision)throw Error('Ação desatualizada.');};

export function createState(round=1,options={}) {
  const mode=options.powersEnabled===false||options.mode==='classic'?'classic':options.mode==='extra'?'extra':'power';
  const acquisition='cells'; // Poderes temporários: sempre coletados nesta partida.
  return {variant:'ludo',mode,acquisition,teams:options.teams||null,round,revision:0,players:[],turnIndex:0,
    powerDrops:[],bonusCells:[],dropSequence:0,distanceDoubled:false,phase:'waiting',die:null,effectiveDie:null,sixes:0,powerUsed:false,bonusChainBlocked:false,
    winner:null,reason:null,lastEvent:null,ranking:[]};
}

export function startGame(state,colors,rng=randomInt) {
  if(!Array.isArray(colors)||colors.length<2||colors.length>4||new Set(colors).size!==colors.length||colors.some(c=>!COLORS.includes(c)))throw Error('O Ludo exige de 2 a 4 cores diferentes.');
  const next=clone(state);
  next.players=colors.map(color=>({color,tokens:[-1,-1,-1,-1],shields:[],inventory:{},turnsTaken:0,frozen:0,shield:null}));
  populateDrops(next,rng);populateBonuses(next,rng);next.phase='roll';next.turnIndex=0;next.revision++;return next;
}

function tokenMoves(state,player,value) {
  if(!Number.isInteger(value)||value<1)return [];
  const moves=[];
  player.tokens.forEach((progress,token)=>{
    if(progress===57)return;
    if(progress===-1){if(state.die===6)moves.push({token,to:0});return;}
    const to=progress+value;if(to<=57)moves.push({token,to});
  });
  return moves;
}

export function legalActions(state,color) {
  if(state.winner||state.phase==='waiting'||current(state)?.color!==color)return [];
  const p=current(state),base=[];
  if(state.phase==='roll')base.push({type:'roll'});
  if(state.phase==='move')base.push(...tokenMoves(state,movingPlayer(state),state.effectiveDie).map(m=>({type:'move',...m})));
  if(state.phase==='move'&&!tokenMoves(state,movingPlayer(state),state.effectiveDie).length)base.push({type:'pass'});
  if(state.phase==='postMove')base.push({type:'end-turn'});
  if(state.mode!=='classic'){
    if(state.phase==='roll'&&(p.inventory.control||0)>0)for(let value=1;value<=6;value++)base.push({type:'power',power:'control',value});
    if(state.phase==='roll'&&(p.inventory.shield||0)>0)movingPlayer(state).tokens.forEach((v,token)=>{if(v!==57&&!movingPlayer(state).shields?.includes(token)&&movingPlayer(state).shield?.token!==token)base.push({type:'power',power:'shield',token});});
    if(state.phase==='roll'&&(p.inventory.double||0)>0&&!state.distanceDoubled)base.push({type:'power',power:'double'});

  }
  return base;
}

function matches(candidate,action){return Object.entries(candidate).every(([k,v])=>action[k]===v);}
function consume(player,power){if((player.inventory[power]||0)<1)throw Error('Poder indisponível no inventário.');player.inventory[power]--;}
function randomPower(player,rng,limit=3){
  if(totalInventory(player.inventory)>=limit)return null;
  const power=POWERS[randomIndex(POWERS.length,rng)];player.inventory[power]=(player.inventory[power]||0)+1;return power;
}
function loseRandomPower(player,rng){
  const bag=POWERS.filter(p=>(player.inventory[p]||0)>0);if(!bag.length)return null;
  const power=bag[randomIndex(bag.length,rng)];player.inventory[power]--;return power;
}
function rank(state){return [...state.players].sort((a,b)=>b.tokens.filter(v=>v===57).length-a.tokens.filter(v=>v===57).length).map((p,i)=>({position:i+1,color:p.color,home:p.tokens.filter(v=>v===57).length}));}
function beginTurn(state,index){
  state.turnIndex=index%state.players.length;const p=current(state);
  if(p.shield)p.shield=null;p.shields=[];
  state.chosenDie=null;state.distanceDoubled=false;state.phase='roll';state.die=null;state.effectiveDie=null;state.sixes=0;state.powerUsed=false;state.bonusChainBlocked=false;
}
function finishTurn(state,extra=false){
  const p=current(state);p.turnsTaken++;
  if(extra){state.chosenDie=null;state.distanceDoubled=false;state.phase='roll';state.die=null;state.effectiveDie=null;state.powerUsed=false;return;}
  beginTurn(state,state.turnIndex+1);
}
function afterMove(state,rolledSix){
  state.phase='postMove';
  if(rolledSix){state.lastEvent={...state.lastEvent,extraRoll:true};}
}

export function applyAction(state,color,action,rng=n=>Math.floor(Math.random()*n)) {
  if(state.winner)throw Error('A partida terminou.');assertVersion(state,action);
  const p=current(state);if(!p||p.color!==color)throw Error('Aguarde sua vez.');
  const allowed=legalActions(state,color);if(!allowed.some(a=>matches(a,action))) {
    if(action.type==='power'&&state.mode==='classic')throw Error('Poderes não existem no modo clássico.');
    
    if(action.type==='power'&&!(p.inventory[action.power]||0))throw Error('Poder indisponível no inventário.');
    if(action.type==='power'&&action.power==='double'&&state.die===6)throw Error('Double Distance não pode ser usado com dado 6.');
    throw Error('Ação ilegal nesta fase.');
  }
  const next=clone(state),me=current(next);next.revision++;
  if(action.type==='roll'){
    const value=next.chosenDie||randomIndex(6,rng)+1;next.chosenDie=null;next.die=value;next.effectiveDie=value*(next.distanceDoubled?2:1);
    if(value===6&&++next.sixes===3){next.lastEvent={type:'triple-six',color};finishTurn(next);return next;}
    next.phase='move';next.lastEvent={type:'roll',color,value};return next;
  }
  if(action.type==='power'){
    consume(me,action.power);
    if(action.power==='control'){next.chosenDie=action.value;next.powerUsed=true;next.lastEvent={type:'power',power:'control',color,value:action.value};}
    if(action.power==='double'){next.distanceDoubled=true;next.powerUsed=true;const rolled=applyAction(next,color,{type:'roll',round:next.round,revision:next.revision},rng);rolled.lastEvent={...rolled.lastEvent,activatedPower:'double'};return rolled;}
    if(action.power==='shield'){const target=movingPlayer(next);target.shields=[...(target.shields||[]),action.token];target.shield={token:action.token};next.powerUsed=true;next.lastEvent={type:'power',power:'shield',color,token:action.token};}
    return next;
  }
  if(action.type==='pass'){next.lastEvent={type:'pass',color};finishTurn(next,next.die===6);return next;}
  if(action.type==='end-turn'){finishTurn(next,!!next.lastEvent?.extraRoll);return next;}
  if(action.type==='move'){
    const mover=movingPlayer(next),moveColor=mover.color;const from=mover.tokens[action.token],rolledTo=action.to;const landed=globalCell(moveColor,rolledTo),bonus=next.mode!=='classic'&&landed!==null&&(next.bonusCells||[]).includes(landed)&&rolledTo<57;const destination=rolledTo;mover.tokens[action.token]=destination;
    const cell=globalCell(moveColor,destination),captured=[];
    if(cell!==null&&!SAFE.has(cell))for(const q of next.players)if(q.color!==moveColor&&!next.teams?.some(team=>team.includes(moveColor)&&team.includes(q.color)))q.tokens.forEach((progress,token)=>{
      if(globalCell(q.color,progress)===cell&&!q.shields?.includes(token)&&q.shield?.token!==token){q.tokens[token]=-1;captured.push({color:q.color,token,lostPower:next.mode!=='classic'?loseRandomPower(q,rng):null});}
    });
    const bonusRespawn=bonus?respawnBonus(next,landed,rng):null;
    const pickup=next.mode!=='classic'?collectDrop(next,me,cell,rng):null,gained=pickup?.power||null;
    next.lastEvent={type:'move',color,movingColor:moveColor,token:action.token,from,to:destination,rolledTo,bonus,bonusRespawn,cell,captured,gained};
    const team=next.teams?.find(t=>t.includes(color));
    if((team?next.players.filter(p=>team.includes(p.color)): [me]).every(p=>p.tokens.every(v=>v===57))){next.winningTeam=team||null;next.winner=color;next.reason=team?'oito peças da dupla chegaram':'quatro peças chegaram';next.ranking=rank(next);for(const player of next.players){player.inventory={};player.shields=[];player.shield=null;}next.powerDrops=[];next.bonusCells=[];return next;}
    next.lastEvent.extraRollReasons=[...(next.die===6?['six']:[]),...(bonus?['bonus-cell']:[]),...(captured.length?['capture']:[]),...(destination===57?['home']:[])];afterMove(next,next.lastEvent.extraRollReasons.length>0);return next;
  }
  throw Error('Ação desconhecida.');
}
