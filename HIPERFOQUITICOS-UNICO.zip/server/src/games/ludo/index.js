/**
 * Ludo autoritativo para 2–4 jogadores.
 * O cliente nunca informa dado, captura, prêmio aleatório ou inventário.
 */
export const COLORS=['red','green','yellow','blue'];
import {START,SAFE} from '../../../../client/public/ludo-map.js';
export {START,SAFE};
export const POWER_CELLS=new Set([5,18,31,44]);
export const POWERS=['double','control','shield','bonus'];
const FIXED={double:2,control:1,shield:2,bonus:2};

const clone=value=>structuredClone(value);
const randomIndex=(length,rng)=>Math.max(0,Math.min(length-1,Number(rng(length))||0));
const globalCell=(color,progress)=>progress>=0&&progress<52?(START[color]+progress)%52:null;
const totalInventory=inv=>POWERS.reduce((sum,p)=>sum+(inv[p]||0),0);
const playerOf=(state,color)=>state.players.find(p=>p.color===color);
const current=state=>state.players[state.turnIndex];
const assertVersion=(s,a)=>{if(a.round!==s.round||a.revision!==s.revision)throw Error('Ação desatualizada.');};

export function createState(round=1,options={}) {
  const mode=['power','extra'].includes(options.mode)?options.mode:'classic';
  const acquisition=options.acquisition==='cells'?'cells':'fixed';
  return {variant:'ludo',mode,acquisition,teams:options.teams||null,round,revision:0,players:[],turnIndex:0,
    phase:'waiting',die:null,effectiveDie:null,sixes:0,powerUsed:false,bonusChainBlocked:false,
    winner:null,reason:null,lastEvent:null,ranking:[]};
}

export function startGame(state,colors) {
  if(!Array.isArray(colors)||colors.length<2||colors.length>4||new Set(colors).size!==colors.length||colors.some(c=>!COLORS.includes(c)))throw Error('O Ludo exige de 2 a 4 cores diferentes.');
  const next=clone(state);
  next.players=colors.map(color=>({color,tokens:[-1,-1,-1,-1],inventory:next.mode!=='classic'&&next.acquisition==='fixed'?Object.fromEntries(Object.entries(FIXED).map(([k,v])=>[k,v*(next.mode==='extra'?2:1)])):{},turnsTaken:0,frozen:0,shield:null}));
  next.phase='roll';next.turnIndex=0;next.revision++;return next;
}

function tokenMoves(state,player,value) {
  if(!Number.isInteger(value)||value<1)return [];
  const moves=[];
  player.tokens.forEach((progress,token)=>{
    if(progress===57)return;
    if(progress===-1){if(value===6)moves.push({token,to:0});return;}
    const to=progress+value;if(to<=57)moves.push({token,to});
  });
  return moves;
}

export function legalActions(state,color) {
  if(state.winner||state.phase==='waiting'||current(state)?.color!==color)return [];
  const p=current(state),base=[];
  if(state.phase==='roll')base.push({type:'roll'});
  if(state.phase==='move')base.push(...tokenMoves(state,p,state.effectiveDie).map(m=>({type:'move',...m})));
  if(state.phase==='move'&&!tokenMoves(state,p,state.effectiveDie).length)base.push({type:'pass'});
  if(state.phase==='postMove')base.push({type:'end-turn'});
  if(state.mode!=='classic'&&p.turnsTaken>=2){
    if(state.phase==='roll'&&!state.powerUsed&&(p.inventory.control||0)>0)for(let value=1;value<=6;value++)base.push({type:'power',power:'control',value});
    if(['roll','move'].includes(state.phase)&&!state.powerUsed&&(p.inventory.shield||0)>0)p.tokens.forEach((v,token)=>{if(v!==57&&p.shield?.token!==token)base.push({type:'power',power:'shield',token});});
    if(state.phase==='move'&&!state.powerUsed&&(p.inventory.double||0)>0&&state.die!==6)base.push({type:'power',power:'double'});
    if(state.phase==='postMove'&&!state.bonusChainBlocked&&(p.inventory.bonus||0)>0)base.push({type:'power',power:'bonus'});
  }
  return base;
}

function matches(candidate,action){return Object.entries(candidate).every(([k,v])=>action[k]===v);}
function consume(player,power){if((player.inventory[power]||0)<1)throw Error('Poder indisponível no inventário.');player.inventory[power]--;}
function randomPower(player,rng,limit=3){
  if(totalInventory(player.inventory)>=limit)return null;
  const power=POWERS[randomIndex(POWERS.length,rng)];player.inventory[power]=(player.inventory[power]||0)+1;return power;
}
function loseRandomPower(player,rng){
  const bag=POWERS.filter(p=>(player.inventory[p]||0)>0);if(!bag.length)return null;
  const power=bag[randomIndex(bag.length,rng)];player.inventory[power]--;return power;
}
function rank(state){return [...state.players].sort((a,b)=>b.tokens.filter(v=>v===57).length-a.tokens.filter(v=>v===57).length).map((p,i)=>({position:i+1,color:p.color,home:p.tokens.filter(v=>v===57).length}));}
function beginTurn(state,index){
  state.turnIndex=index%state.players.length;const p=current(state);
  if(p.shield)p.shield=null;
  state.phase='roll';state.die=null;state.effectiveDie=null;state.sixes=0;state.powerUsed=false;state.bonusChainBlocked=false;
}
function finishTurn(state,extra=false){
  const p=current(state);p.turnsTaken++;
  if(extra){state.phase='roll';state.die=null;state.effectiveDie=null;state.powerUsed=false;return;}
  beginTurn(state,state.turnIndex+1);
}
function afterMove(state,rolledSix){
  state.phase='postMove';
  if(rolledSix){state.lastEvent={...state.lastEvent,extraRoll:true};}
}

export function applyAction(state,color,action,rng=n=>Math.floor(Math.random()*n)) {
  if(state.winner)throw Error('A partida terminou.');assertVersion(state,action);
  const p=current(state);if(!p||p.color!==color)throw Error('Aguarde sua vez.');
  const allowed=legalActions(state,color);if(!allowed.some(a=>matches(a,action))) {
    if(action.type==='power'&&state.mode==='classic')throw Error('Poderes não existem no modo clássico.');
    if(action.type==='power'&&p.turnsTaken<2)throw Error('Poderes bloqueados nos dois primeiros turnos.');
    if(action.type==='power'&&!(p.inventory[action.power]||0))throw Error('Poder indisponível no inventário.');
    if(action.type==='power'&&action.power==='double'&&state.die===6)throw Error('Double Distance não pode ser usado com dado 6.');
    throw Error('Ação ilegal nesta fase.');
  }
  const next=clone(state),me=current(next);next.revision++;
  if(action.type==='roll'){
    const value=randomIndex(6,rng)+1;next.die=value;next.effectiveDie=value;
    if(value===6&&++next.sixes===3){next.lastEvent={type:'triple-six',color};finishTurn(next);return next;}
    next.phase='move';next.lastEvent={type:'roll',color,value};return next;
  }
  if(action.type==='power'){
    consume(me,action.power);
    if(action.power==='control'){if(action.value===6&&++next.sixes===3){next.lastEvent={type:'triple-six',color};finishTurn(next);return next;}next.die=action.value;next.effectiveDie=action.value;next.phase='move';next.powerUsed=true;next.lastEvent={type:'power',power:'control',color,value:action.value};}
    if(action.power==='double'){next.effectiveDie=next.die*2;next.powerUsed=true;next.lastEvent={type:'power',power:'double',color,value:next.effectiveDie};}
    if(action.power==='shield'){me.shield={token:action.token};next.powerUsed=true;next.lastEvent={type:'power',power:'shield',color,token:action.token};}

    if(action.power==='bonus'){next.bonusChainBlocked=true;next.phase='roll';next.die=null;next.effectiveDie=null;next.powerUsed=false;next.lastEvent={type:'power',power:'bonus',color};}
    return next;
  }
  if(action.type==='pass'){next.lastEvent={type:'pass',color};finishTurn(next,next.die===6);return next;}
  if(action.type==='end-turn'){finishTurn(next,!!next.lastEvent?.extraRoll);return next;}
  if(action.type==='move'){
    const from=me.tokens[action.token];me.tokens[action.token]=action.to;
    const cell=globalCell(color,action.to),captured=[];
    if(cell!==null&&!SAFE.has(cell))for(const q of next.players)if(q.color!==color&&!next.teams?.some(team=>team.includes(color)&&team.includes(q.color)))q.tokens.forEach((progress,token)=>{
      if(globalCell(q.color,progress)===cell&&q.shield?.token!==token){q.tokens[token]=-1;captured.push({color:q.color,token,lostPower:next.mode!=='classic'?loseRandomPower(q,rng):null});}
    });
    let gained=null;if(next.mode!=='classic'&&next.acquisition==='cells'&&POWER_CELLS.has(cell))gained=randomPower(me,rng,next.mode==='extra'?6:3);
    next.lastEvent={type:'move',color,token:action.token,from,to:action.to,cell,captured,gained};
    const team=next.teams?.find(t=>t.includes(color));
    if((team?next.players.filter(p=>team.includes(p.color)): [me]).every(p=>p.tokens.every(v=>v===57))){next.winningTeam=team||null;next.winner=color;next.reason=team?'oito peças da dupla chegaram':'quatro peças chegaram';next.ranking=rank(next);return next;}
    afterMove(next,next.die===6);return next;
  }
  throw Error('Ação desconhecida.');
}
