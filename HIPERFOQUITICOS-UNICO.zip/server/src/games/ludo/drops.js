import {SAFE,START} from '../../../../client/public/ludo-map.js';
export const DROP_TYPES=['shield','double','control'];
export const POWER_COUNTS=Object.freeze({shield:2,double:2,control:2});
export const ACTIVE_POWER_COUNT=6;
export const BONUS_CELL_COUNT=4;
const pick=(length,rng)=>Math.max(0,Math.min(length-1,Number(rng(length))||0));
const occupiedCells=state=>state.players.flatMap(p=>p.tokens.filter(v=>v>=0&&v<52).map(v=>(START[p.color]+v)%52));
function availableCells(state,excluded=[]){const used=new Set([...SAFE,...occupiedCells(state),...state.powerDrops.map(d=>d.cell),...(state.bonusCells||[]),...excluded]);return Array.from({length:52},(_,i)=>i).filter(i=>!used.has(i));}
export function spawnDrop(state,rng,power){const available=availableCells(state);if(!available.length)return null;const type=power||DROP_TYPES.find(type=>state.powerDrops.filter(d=>d.power===type).length<POWER_COUNTS[type]);if(!type)return null;return {id:state.dropSequence++,cell:available[pick(available.length,rng)],power:type};}
// Quantidades explícitas; cada coleta repõe o tipo que ficou abaixo da cota.
export function populateDrops(state,rng){if(state.mode==='classic')return;for(const power of DROP_TYPES)while(state.powerDrops.filter(d=>d.power===power).length<POWER_COUNTS[power]){const drop=spawnDrop(state,rng,power);if(!drop)return;state.powerDrops.push(drop);}}
export function collectDrop(state,player,cell,rng){const index=state.powerDrops.findIndex(d=>d.cell===cell);if(index<0)return null;const [drop]=state.powerDrops.splice(index,1);player.inventory[drop.power]=(player.inventory[drop.power]||0)+1;populateDrops(state,rng);return drop;}
export function populateBonuses(state,rng){state.bonusCells=[];if(state.mode==='classic')return;while(state.bonusCells.length<BONUS_CELL_COUNT){const available=availableCells(state);if(!available.length)break;state.bonusCells.push(available[pick(available.length,rng)]);}}
// O +1 também é consumido: sua substituição nasce longe da origem e das peças.
export function respawnBonus(state,cell,rng){if(state.mode==='classic'||!(state.bonusCells||[]).includes(cell))return null;state.bonusCells=state.bonusCells.filter(value=>value!==cell);const available=availableCells(state,[cell]);if(!available.length)return {from:cell,to:null};const next=available[pick(available.length,rng)];state.bonusCells.push(next);return {from:cell,to:next};}
