import {SAFE,START} from '../../../../client/public/ludo-map.js';
export const DROP_TYPES=['shield','double','control','bonus'];
export const ACTIVE_POWER_COUNT=3;
export const BONUS_CELL_COUNT=3;
const pick=(length,rng)=>Math.max(0,Math.min(length-1,Number(rng(length))||0));
const occupiedCells=state=>state.players.flatMap(p=>p.tokens.filter(v=>v>=0&&v<52).map(v=>(START[p.color]+v)%52));
function availableCells(state,excluded=[]){const used=new Set([...SAFE,...occupiedCells(state),...state.powerDrops.map(d=>d.cell),...(state.bonusCells||[]),...excluded]);return Array.from({length:52},(_,i)=>i).filter(i=>!used.has(i));}
export function spawnDrop(state,rng){const available=availableCells(state);if(!available.length)return null;return {id:state.dropSequence++,cell:available[pick(available.length,rng)],power:(()=>{const types=DROP_TYPES.filter(type=>!state.powerDrops.some(d=>d.power===type));return types[pick(types.length,rng)];})()};}
// Última especificação: três itens simultâneos, sorteados pelo servidor.
export function populateDrops(state,rng){if(state.mode==='classic')return;while(state.powerDrops.length<ACTIVE_POWER_COUNT){const drop=spawnDrop(state,rng);if(!drop)return;state.powerDrops.push(drop);}}
export function collectDrop(state,player,cell,rng){const index=state.powerDrops.findIndex(d=>d.cell===cell);if(index<0)return null;const [drop]=state.powerDrops.splice(index,1);player.inventory[drop.power]=(player.inventory[drop.power]||0)+1;populateDrops(state,rng);return drop;}
export function populateBonuses(state,rng){state.bonusCells=[];if(state.mode==='classic')return;while(state.bonusCells.length<BONUS_CELL_COUNT){const available=availableCells(state);if(!available.length)break;state.bonusCells.push(available[pick(available.length,rng)]);}}
// O +1 também é consumido: sua substituição nasce longe da origem e das peças.
export function respawnBonus(state,cell,rng){if(state.mode==='classic'||!(state.bonusCells||[]).includes(cell))return null;state.bonusCells=state.bonusCells.filter(value=>value!==cell);const available=availableCells(state,[cell]);if(!available.length)return {from:cell,to:null};const next=available[pick(available.length,rng)];state.bonusCells.push(next);return {from:cell,to:next};}
