// Contrato reutilizável: createState(), validateAction(), applyAction().
export const winningLines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
export function createState(round = 1) {
  return {board:Array(9).fill(null),turn:'X',winner:null,line:[],round,reason:null};
}
export function validateAction(state, mark, action) {
  if(state.winner) throw Error('Esta partida já terminou.');
  if(action.round!==state.round) throw Error('Partida desatualizada.');
  if(action.type!=='move') throw Error('Ação desconhecida.');
  if(mark!==state.turn) throw Error('Aguarde sua vez.');
  if(!Number.isInteger(action.cell) || action.cell<0 || action.cell>8 || state.board[action.cell]) throw Error('Casa inválida ou ocupada.');
}
export function applyAction(state, mark, action) {
  validateAction(state,mark,action);
  const next=structuredClone(state);
  next.board[action.cell]=mark;next.lastEvent={type:'move',color:mark,cell:action.cell};
  const line=winningLines.find(l=>l.every(i=>next.board[i]===mark));
  if(line) {next.winner=mark;next.line=line;next.reason='line';}
  else if(next.board.every(Boolean)) {next.winner='draw';next.reason='draw';}
  else next.turn=mark==='X'?'O':'X';
  return next;
}
