import {randomInt} from 'node:crypto';
export const COLORS=['red','green','yellow','blue'];
export function deck(){let id=0;const cards=[];for(const color of COLORS){cards.push({id:id++,color,value:'0'});for(const value of ['1','2','3','4','5','6','7','8','9','skip','reverse','draw2'])for(let n=0;n<2;n++)cards.push({id:id++,color,value});}for(const value of ['wild','draw4'])for(let n=0;n<4;n++)cards.push({id:id++,color:null,value});return cards;}
function shuffle(cards,rng){for(let i=cards.length-1;i>0;i--){const j=rng(i+1);[cards[i],cards[j]]=[cards[j],cards[i]];}return cards;}
export function createState(round=1){return {round,revision:0,players:[],turnIndex:0,direction:1,pile:[],discard:[],color:null,drawn:null,pending:null,unoTarget:null,winner:null,reason:null,lastEvent:null};}
const nextIndex=(s,n=1)=>(s.turnIndex+n*s.direction+s.players.length*4)%s.players.length;
function draw(s,p,count,rng){for(let i=0;i<count;i++){if(!s.pile.length){const top=s.discard.pop();s.pile=shuffle(s.discard,rng);s.discard=[top];}if(s.pile.length)p.hand.push(s.pile.pop());}}
export function startGame(s,marks,rng=randomInt){const n=structuredClone(s);n.players=marks.map(color=>({color,hand:[]}));n.pile=shuffle(deck(),rng);for(const p of n.players)draw(n,p,7,rng);let top=n.pile.pop();while(top.value==='draw4'){n.pile.unshift(top);top=n.pile.pop();}n.discard=[top];n.color=top.color;n.revision++;if(!top.color)n.color='red';if(top.value==='skip')n.turnIndex=1;if(top.value==='reverse'){n.direction=-1;n.turnIndex=marks.length-1;}if(top.value==='draw2'){draw(n,n.players[0],2,rng);n.turnIndex=1;}return n;}
function playable(s,p,c){const top=s.discard.at(-1);return !c.color||c.color===s.color||c.value===top.value;}
export function legalActions(s,mark){if(s.winner||!s.players.length)return [];const p=s.players[s.turnIndex];const actions=[];if(s.unoTarget&&s.unoTarget!==mark)actions.push({type:'catch-uno'});if(s.unoTarget===mark)actions.push({type:'say-uno'});if(p.color!==mark)return actions;if(s.pending)return [...actions,{type:'accept-draw'},{type:'challenge'}];for(const c of p.hand)if((s.drawn===null||s.drawn===c.id)&&playable(s,p,c)){if(c.color)actions.push({type:'play',card:c.id});else for(const color of COLORS)actions.push({type:'play',card:c.id,color});}return [...actions,...(s.drawn===null?[{type:'draw'}]:[{type:'pass'}])];}
function settle(s){const p=s.players.find(p=>p.hand.length===0);if(p&&!s.pending){s.winner=p.color;s.reason='ficou sem cartas';}}
export function applyAction(s,mark,a,rng=randomInt){if(a.round!==s.round||a.revision!==s.revision)throw Error('Ação desatualizada.');if(!legalActions(s,mark).some(x=>Object.entries(x).every(([k,v])=>a[k]===v)))throw Error('Carta, turno ou ação inválida.');const n=structuredClone(s),p=n.players[n.turnIndex];n.revision++;n.lastEvent={type:a.type,color:mark};
 if(a.type==='say-uno'){n.unoTarget=null;return n;}if(a.type==='catch-uno'){draw(n,n.players.find(p=>p.color===n.unoTarget),2,rng);n.unoTarget=null;return n;}
 n.unoTarget=null;
 if(a.type==='accept-draw'||a.type==='challenge'){const pending=n.pending;n.pending=null;if(a.type==='challenge'&&pending.illegal){draw(n,n.players.find(p=>p.color===pending.offender),4,rng);}else{draw(n,p,a.type==='challenge'?6:4,rng);n.turnIndex=nextIndex(n);}settle(n);return n;}
 if(a.type==='draw'){draw(n,p,1,rng);n.drawn=p.hand.at(-1)?.id??-1;return n;}if(a.type==='pass'){n.drawn=null;n.turnIndex=nextIndex(n);return n;}
 const i=p.hand.findIndex(c=>c.id===a.card),card=p.hand[i],illegal=card.value==='draw4'&&p.hand.some(c=>c.color===n.color);p.hand.splice(i,1);n.discard.push(card);n.color=card.color||a.color;n.drawn=null;if(p.hand.length===1&&!a.uno)n.unoTarget=mark;
 if(card.value==='reverse')n.direction*=-1;
 if(card.value==='draw4'){n.pending={offender:mark,illegal};n.turnIndex=nextIndex(n);}
 else if(card.value==='draw2'){draw(n,n.players[nextIndex(n)],2,rng);n.turnIndex=nextIndex(n,2);}
 else n.turnIndex=nextIndex(n,card.value==='skip'||(card.value==='reverse'&&n.players.length===2)?2:1);
 settle(n);return n;}
export function publicState(s,mark){return {round:s.round,revision:s.revision,players:s.players.map(p=>({color:p.color,count:p.hand.length,...(p.color===mark?{hand:p.hand}:{} )})),turnIndex:s.turnIndex,direction:s.direction,color:s.color,top:s.discard.at(-1)||null,pileCount:s.pile.length,pending:!!s.pending,unoTarget:s.unoTarget,winner:s.winner,reason:s.reason,lastEvent:s.lastEvent};}
