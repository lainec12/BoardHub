export function resetMatchStats(room){room.matchStats={};room.matchSummary=null;}
export function recordMatchAction(room,mark,action,next){room.matchStats??={};const stats=color=>room.matchStats[color]??=( {moves:0,captures:0,lost:0} );const mine=stats(mark);if(['move','play','fire'].includes(action.type))mine.moves++;
let victims=[];if(room.gameId==='ludo'&&action.type==='move')victims=(next.lastEvent?.captured||[]).map(c=>c.color);
else if(room.gameId.startsWith('checkers')&&action.type==='move')victims=(next.lastMove?.captures||[]).map(()=>room.players.find(p=>p.mark!==mark)?.mark);
else if(room.gameId==='chess'&&action.type==='move'&&next.lastChessMove?.san?.includes('x'))victims=[room.players.find(p=>p.mark!==mark)?.mark];
else if(room.gameId==='battleship'&&action.type==='fire'&&next.lastEvent?.result==='sunk')victims=[room.players.find(p=>p.mark!==mark)?.mark];
for(const victim of victims)if(victim){mine.captures++;stats(victim).lost++;}}
export function finishMatchSummary(room,scores){const rows=room.players.map(p=>({id:p.id,mark:p.mark,name:p.name,bot:!!p.bot,winner:room.game.winningTeam?room.game.winningTeam.includes(p.mark):room.game.winner===p.mark,wins:scores.find(s=>s.player===p.id)?.wins||0,...(room.matchStats?.[p.mark]||{moves:0,captures:0,lost:0})})).sort((a,b)=>b.wins-a.wins||a.name.localeCompare(b.name));let previousWins,position=0;rows.forEach((p,i)=>{if(p.wins!==previousWins)position=i+1;p.position=position;previousWins=p.wins;});return {round:room.game.round,draw:room.game.winner==='draw',rows};}
