import {chooseMove} from '../../client3d/src/games/tic-tac-toe/engine.js';
import {START as starts,SAFE as safe} from '../../client/public/ludo-map.js';
const cell=(color,v)=>v>=0&&v<52?(starts[color]+v)%52:null;
// Avalia apenas o tabuleiro público: não conhece nem altera o próximo dado.
function ludoChoice(s,mark,actions){
 const me=s.players.find(p=>p.color===mark),team=s.teams?.find(t=>t.includes(mark))||[mark];
 const enemies=s.players.filter(p=>!team.includes(p.color));
 const threat=v=>{const c=cell(mark,v);if(c===null||safe.has(c))return 0;return enemies.reduce((sum,p)=>sum+p.tokens.filter(t=>{const x=cell(p.color,t);return x!==null&&(c-x+52)%52>=1&&(c-x+52)%52<=6;}).length,0);};
 const moveScore=(token,to)=>{const from=me.tokens[token],c=cell(mark,to);let score=(to===57?250:to>=52?70:0)+(from===-1?35:to-from)+threat(from)*18-threat(to)*26;
 if(c!==null&&safe.has(c))score+=22;
 if(c!==null&&!safe.has(c))for(const p of enemies)p.tokens.forEach((v,i)=>{if(cell(p.color,v)===c&&p.shield?.token!==i)score+=85+v;});
 return score;};
 const normal=actions.filter(a=>a.type==='move');const best=Math.max(-100,...normal.map(a=>moveScore(a.token,a.to)));
 const scored=actions.map(a=>{let score=-200;
 if(a.type==='move')score=moveScore(a.token,a.to);
 if(a.type==='roll')score=0;if(a.type==='pass'||a.type==='end-turn')score=-5;
 if(a.power==='bonus')score=25;
 if(a.power==='control'){const candidates=me.tokens.map((v,i)=>({i,to:v===-1?(a.value===6?0:-1):v+a.value})).filter(x=>x.to>=0&&x.to<=57);score=Math.max(-100,...candidates.map(x=>moveScore(x.i,x.to)))-12;}
 if(a.power==='double'){const scores=me.tokens.map((v,i)=>({i,to:v===-1?(s.die*2===6?0:-1):v+s.die*2})).filter(x=>x.to>=0&&x.to<=57);const gain=Math.max(-100,...scores.map(x=>moveScore(x.i,x.to)));score=gain>best+15?gain+1:-100;}
 if(a.power==='shield'){score=threat(me.tokens[a.token])>0?best+5:-100;}
 return {a,score};});
 scored.sort((a,b)=>b.score-a.score);return scored[0].a;
}
function boardScore(s,mark){if(s.winner)return s.winner==='draw'?0:s.winner===mark?100000:-100000;
 const chess=!!s.initialFen,side=chess?(mark==='X'?'w':'b'):mark;
 return s.board.reduce((sum,p,i)=>{if(!p)return sum;const own=(chess?p.color:p.side)===side,value=chess?({p:100,n:320,b:330,r:500,q:900,k:20000}[p.type]):p.king?300:100;const center=8-Math.abs(i%8-3.5)-Math.abs(Math.floor(i/8)-3.5);return sum+(own?1:-1)*(value+center*2);},0);
}
function tacticalChoice(engine,s,mark,actions,hard){
 const apply=(state,side,a)=>engine.applyAction(state,side,{type:'move',...a,round:state.round,revision:state.revision,ply:state.ply});
 const scored=actions.map(a=>{const n=apply(s,mark,a);return {a,n,score:boardScore(n,mark)};}).sort((a,b)=>b.score-a.score);
 if(!hard)return scored[0].a;
 for(const item of scored.slice(0,8)){if(item.n.winner)continue;const enemy=item.n.turn,moves=engine.legalMoves(item.n);item.score=moves.length?Math.min(...moves.slice(0,32).map(a=>boardScore(apply(item.n,enemy,a),mark))):item.score;}
 return scored.slice(0,8).sort((a,b)=>b.score-a.score)[0].a;
}
function navalChoice(view,actions,rng,hard){
 const hits=view.shots.filter(s=>s.result==='hit').flatMap(s=>[s.cell-10,s.cell+10,...(s.cell%10?[s.cell-1]:[]),...(s.cell%10<9?[s.cell+1]:[])]),near=actions.filter(a=>hits.includes(a.cell)),pool=near.length?near:actions;
 if(!hard)return pool[rng(pool.length)];
 const blocked=new Set(view.shots.filter(s=>s.result==='water'||s.result==='sunk').flatMap(s=>s.sunk||[s.cell])),scores=new Map();
 for(const length of [5,4,3,3,2])for(let row=0;row<10;row++)for(let col=0;col<10;col++)for(const vertical of [false,true]){const cells=Array.from({length},(_,i)=>(row+(vertical?i:0))*10+col+(vertical?0:i));if(row+(vertical?length:1)>10||col+(vertical?1:length)>10||cells.some(c=>blocked.has(c)))continue;for(const c of cells)scores.set(c,(scores.get(c)||0)+1);}
 return pool.slice().sort((a,b)=>(scores.get(b.cell)||0)-(scores.get(a.cell)||0))[0];
}
function unoChoice(view,mark,actions){const urgent=actions.find(a=>a.type==='say-uno'||a.type==='catch-uno');if(urgent)return urgent;const hand=view.players.find(p=>p.color===mark)?.hand||[],colors={red:0,green:0,yellow:0,blue:0};for(const c of hand)if(c.color)colors[c.color]++;const plays=actions.filter(a=>a.type==='play').map(a=>{const card=hand.find(c=>c.id===a.card);const penalty=card?.value==='draw4'&&hand.some(c=>c.color===view.color)?-100:0;return {a,score:(card?.color?15:0)+(colors[a.color||card?.color]||0)+(['skip','reverse','draw2'].includes(card?.value)?6:0)+penalty};});return plays.length?plays.sort((a,b)=>b.score-a.score)[0].a:actions.find(a=>a.type==='accept-draw')||actions[0];}
// Bots usam apenas as ações legais. Naval e UNO consultam a visão pública.
export function chooseBotAction(engine,state,mark,rng){
 const view=engine.publicState?engine.publicState(state,mark):state;
 let actions=engine.legalActions?.(state,mark)|| (state.turn===mark?engine.legalMoves?.(state):[])||[];
 if(!actions.length&&state.board?.length===9&&state.turn===mark)actions=state.board.flatMap((v,cell)=>v?[]:[{type:'move',cell}]);
 if(!actions.length)return null;
 if(state.board?.length===9&&state.turn===mark)return {type:'move',cell:chooseMove(state.board,state.botDifficulty||'medium',()=>rng(1000000)/1000000),round:state.round};
 let a;
 if(state.board?.length===64&&state.botDifficulty!=='easy'){a=tacticalChoice(engine,state,mark,actions,state.botDifficulty==='hard');
 }else if(view.top&&state.botDifficulty!=='easy'){a=unoChoice(view,mark,actions);
 }else if(state.variant==='ludo'){a=state.botDifficulty==='easy'?actions[rng(actions.length)]:ludoChoice(state,mark,actions);
 }else if(actions[0].type==='place'){
  const used=new Set(),fleet=[];
  for(const length of [5,4,3,3,2]){let cells;do{const start=rng(100),step=rng(2)?10:1;cells=Array.from({length},(_,i)=>start+i*step);if(cells.some(c=>c>99||used.has(c))||(step===1&&Math.floor(cells[0]/10)!==Math.floor(cells.at(-1)/10)))cells=null;}while(!cells);cells.forEach(c=>used.add(c));fleet.push(cells);}a={type:'place',fleet};
 }else if(view.shots){a=state.botDifficulty==='easy'?actions[rng(actions.length)]:navalChoice(view,actions,rng,state.botDifficulty==='hard');
 }else {const preferred=actions.filter(a=>!['draw','pass','challenge'].includes(a.type));const pool=preferred.length?preferred:actions;a=pool[rng(pool.length)];}
 return {type:'move',...a,uno:true,round:state.round,revision:state.revision,ply:state.ply};
}
