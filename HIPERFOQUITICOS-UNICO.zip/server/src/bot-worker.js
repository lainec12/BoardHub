import {parentPort} from 'node:worker_threads';import {randomInt} from 'node:crypto';import {games} from './games/index.js';import {chooseBotAction} from './bots.js';
parentPort.on('message',({id,gameId,state,mark})=>{try{parentPort.postMessage({id,action:chooseBotAction(games[gameId],state,mark,randomInt)});}catch(e){parentPort.postMessage({id,error:e.message});}});
