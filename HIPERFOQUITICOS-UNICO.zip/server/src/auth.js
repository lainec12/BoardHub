import {Passport} from 'passport';
import {Strategy as GoogleStrategy} from 'passport-google-oauth20';
import session from 'express-session';
import {randomBytes,timingSafeEqual} from 'node:crypto';
export function configureAuth(app,io,db,env=process.env){
 const enabled=!!(env.GOOGLE_CLIENT_ID&&env.GOOGLE_CLIENT_SECRET);
 if(!enabled){app.get('/api/me',(_,res)=>res.json({googleEnabled:false,user:null}));app.get('/auth/google',(_,res)=>res.status(503).send('Login Google ainda não configurado. Entre por apelido.'));return;}
 if(!env.SESSION_SECRET||env.SESSION_SECRET.length<32)throw Error('Defina SESSION_SECRET com pelo menos 32 caracteres.');
 const base=new URL(env.PUBLIC_URL||'http://localhost:3000');
 if(env.NODE_ENV==='production'&&base.protocol!=='https:')throw Error('PUBLIC_URL precisa usar HTTPS em produção.');
 db.authInit();
 class SQLiteStore extends session.Store{get(id,cb){try{cb(null,db.getSession(id));}catch(e){cb(e);}}set(id,value,cb){try{db.setSession(id,value);cb?.();}catch(e){cb?.(e);}}destroy(id,cb){try{db.deleteSession(id);cb?.();}catch(e){cb?.(e);}}touch(id,value,cb){this.set(id,value,cb);}}
 if(env.TRUST_PROXY==='1')app.set('trust proxy',1);
 const middleware=session({name:'boardhub.sid',secret:env.SESSION_SECRET,store:new SQLiteStore(),resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:base.protocol==='https:',maxAge:30*86400000}});
 app.use(middleware);io.engine.use(middleware);
 const passport=new Passport();
 passport.use(new GoogleStrategy({clientID:env.GOOGLE_CLIENT_ID,clientSecret:env.GOOGLE_CLIENT_SECRET,callbackURL:new URL('/auth/google/callback',base).href,state:true},(_access,_refresh,profile,done)=>{try{done(null,db.upsertUser(profile.id,String(profile.displayName||'Jogador').slice(0,80)));}catch(e){done(e);}}));
 // Somente identificador na sessão. Tokens OAuth não são armazenados.
 passport.serializeUser((user,done)=>done(null,user.id));passport.deserializeUser((id,done)=>{try{done(null,db.getUser(id)||false);}catch(e){done(e);}});
 app.use(passport.initialize());app.use(passport.session());
 app.get('/auth/google',(req,res,next)=>{const room=String(req.query.room||'');req.session.returnTo=/^[A-Z2-9]{6}$/.test(room)?'/join/'+room:'/';passport.authenticate('google',{scope:['profile']})(req,res,next);});
 app.get('/auth/google/callback',(req,res,next)=>passport.authenticate('google',(err,user)=>{if(err||!user)return res.redirect('/?login=failed');const target=req.session.returnTo||'/';req.logIn(user,e=>{if(e)return next(e);req.session.save(e=>e?next(e):res.redirect(target));});})(req,res,next));
 app.get('/api/me',(req,res)=>{res.set('Cache-Control','no-store');if(!req.session.csrf)req.session.csrf=randomBytes(24).toString('hex');res.json({googleEnabled:true,user:req.user?{name:req.user.name}:null,csrf:req.session.csrf});});
 app.post('/auth/logout',(req,res,next)=>{const actual=Buffer.from(req.get('X-CSRF-Token')||''),expected=Buffer.from(req.session.csrf||'');if(!expected.length||actual.length!==expected.length||!timingSafeEqual(actual,expected))return res.sendStatus(403);req.logout(err=>{if(err)return next(err);req.session.destroy(err=>{if(err)return next(err);res.clearCookie('boardhub.sid');res.sendStatus(204);});});});
}
