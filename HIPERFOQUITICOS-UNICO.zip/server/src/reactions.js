import {randomBytes,randomInt} from 'node:crypto';import {TAUNTS,EMOJIS,GAGS,avatarEffect,BOT_TAUNTS,BOT_ANGRY_TAUNTS} from '../../shared/reactions.js';
export function validateReaction(r,p,{text,kind='reaction',target,effect},now=Date.now()){if(r.status!=='playing'&&r.status!=='finished')throw Error('Comece a partida para reagir.');if(now-(p.lastReaction||0)<4000)throw Error('Aguarde quatro segundos entre brincadeiras.');if(kind==='avatar-effect'){if(!GAGS.includes(effect)||!r.players.some(q=>q.mark===target&&q!==p&&!r.game.teams?.some(t=>t.includes(p.mark)&&t.includes(q.mark))))throw Error('Efeito ou adversário inválido.');}else if(![...TAUNTS,...EMOJIS,...(p.bot?[...BOT_TAUNTS,...BOT_ANGRY_TAUNTS]:[])].includes(text))throw Error('Reação inválida.');return true;}
export function addReaction(r,p,data,now=Date.now()){validateReaction(r,p,data,p.bot?Math.max(now,data.displayAt||0):now);const {text,kind='reaction',target,effect,displayAt,displayFor}=data;p.lastReaction=now;const entry={id:randomBytes(8).toString('hex'),name:p.name,mark:p.mark,text:kind==='avatar-effect'?avatarEffect(effect).icon:text,kind,target,effect,time:now,displayAt:displayAt||now,displayFor:displayFor||7000};r.chat.push(entry);r.chat=r.chat.slice(-100);return entry;}
const BOT_REACTION_INTERVAL = 8000;
const BOT_DISPLAY_TIME = 3000;

export function isEmojiReaction(text) {
  return /^(?:\p{RGI_Emoji}\s*)+$/v.test(text.trim());
}

export function botReaction(r, event) {
  const now = Date.now();
  const bots = r.players.filter(p => p.bot);
  const capture = !!event.captured?.length;
  if (!event.greeting && !event.emoji && !event.goodMove && !event.winner && !capture && !event.taunted) return;

  let displayAt = Math.max(now, r.nextBotSpeechAt || 0);
  // A resposta pode aguardar a abertura, mas não deve acumular vários emojis.
  const reply = event.emoji || event.taunted;
  if (reply && r.pendingBotReplyUntil > now) return;
  const candidates = bots.filter(p => !event.taunted || p.mark === event.taunted);
  const eligible = candidates.filter(p => event.greeting || event.taunted || now - (p.lastReaction || 0) >= BOT_REACTION_INTERVAL);
  const speakers = event.emoji
    ? [candidates.reduce((earliest, p) => !earliest || (p.lastReaction || 0) < (earliest.lastReaction || 0) ? p : earliest, null)].filter(Boolean)
    : eligible;

  let sentEffect = false;
  for (const p of speakers) {
    if (event.greeting) {
      p.lastReaction = 0;
      p.lastBotSpeechAt = 0;
    }
    displayAt = Math.max(displayAt, (p.lastBotSpeechAt || 0) + BOT_REACTION_INTERVAL, (p.lastReaction || 0) + 4000);
    const captured = event.captured?.some(c => c.color === p.mark);
    const angry = captured || event.taunted || (event.winner && event.winner !== p.mark);
    const lines = angry ? BOT_ANGRY_TAUNTS : BOT_TAUNTS;
    const targets = r.players.filter(q => q !== p && !r.game.teams?.some(t => t.includes(p.mark) && t.includes(q.mark)));
    const target = targets.find(q => q.mark === (event.source || event.color)) || targets.find(q => q.bot) || targets[0];
    const useEffect = target && !event.greeting && (event.taunted || (!sentEffect && (capture || event.winner || randomInt(4) === 0)));
    const data = event.emoji
      ? {text: EMOJIS[randomInt(EMOJIS.length)]}
      : useEffect
        ? {kind: 'avatar-effect', effect: GAGS[randomInt(GAGS.length)], target: target.mark}
        : {text: lines[randomInt(lines.length)]};
    addReaction(r, p, {...data, displayAt, displayFor: BOT_DISPLAY_TIME}, now);
    sentEffect ||= data.kind === 'avatar-effect';
    p.lastBotSpeechAt = displayAt;
    if (reply) r.pendingBotReplyUntil = displayAt + BOT_DISPLAY_TIME;
    displayAt += BOT_DISPLAY_TIME;
    r.nextBotSpeechAt = displayAt;
  }
}
