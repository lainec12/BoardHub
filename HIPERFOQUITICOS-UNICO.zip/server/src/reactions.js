import {randomBytes,randomInt} from 'node:crypto';import {TAUNTS,EMOJIS,GAGS,avatarEffect,BOT_TAUNTS,BOT_ANGRY_TAUNTS} from '../../shared/reactions.js';
export function validateReaction(r,p,{text,kind='reaction',target,effect},now=Date.now()){if(r.status!=='playing'&&r.status!=='finished')throw Error('Comece a partida para reagir.');if(now-(p.lastReaction||0)<4000)throw Error('Aguarde quatro segundos entre brincadeiras.');if(kind==='avatar-effect'){if(!GAGS.includes(effect)||!r.players.some(q=>q.mark===target&&q!==p&&!r.game.teams?.some(t=>t.includes(p.mark)&&t.includes(q.mark))))throw Error('Efeito ou adversário inválido.');}else if(![...TAUNTS,...EMOJIS,...(p.bot?[...BOT_TAUNTS,...BOT_ANGRY_TAUNTS]:[])].includes(text))throw Error('Reação inválida.');return true;}
export function addReaction(r,p,data,now=Date.now()){validateReaction(r,p,data,now);const {text,kind='reaction',target,effect,displayAt,displayFor}=data;p.lastReaction=now;return record(r,p,{text,kind,target,effect,displayAt,displayFor},now);}
function record(r,p,{text,kind='reaction',target,effect,displayAt,displayFor},now){const entry={id:randomBytes(8).toString('hex'),name:p.name,mark:p.mark,text:kind==='avatar-effect'?avatarEffect(effect).icon:text,kind,target,effect,time:now,displayAt:displayAt||now,displayFor:displayFor||7000};r.chat.push(entry);r.chat=r.chat.slice(-100);return entry;}

export function isEmojiReaction(text) {
  return /^(?:\p{RGI_Emoji}\s*)+$/v.test(text.trim());
}

export function botReaction(room, event, choose=randomInt, now=Date.now()) {
  const players=room.players;
  const byMark=mark=>players.find(player=>player.mark===mark);
  const pick=items=>items.length ? items[choose(items.length)] : undefined;
  const actor=byMark(event.source || event.color);
  const ready=p=>p?.bot && now-(p.lastReaction||0)>=8000;
  const opponent=(p,q)=>q && p!==q && !room.game.teams?.some(team=>team.includes(p.mark)&&team.includes(q.mark));
  function say(p, target, lines, delay=0) {
    if(!p?.bot) return false;
    const directReply=(event.taunted || event.emoji) && target;
    if(!ready(p) && !directReply) return false;
    if(directReply && (p.replyAfter||0)>now) return false;
    if(directReply) {
      delay=Math.max(delay,(p.lastReaction||0)+3200-now);
      p.replyAfter=now+delay+3200;
    }
    const prefix=target ? target.name+', ' : '';
    p.lastReaction=now;
    record(room,p,{text:prefix+pick(lines),target:target?.mark,displayAt:now+delay,displayFor:3000},now);
    return true;
  }
  function face(p,target) {
    if (!target || !opponent(p,target)) return;
    record(room,p,{kind:'avatar-effect',effect:pick(['glasses','tongue','clown']),target:target.mark},now);
  }
  if(event.emoji) {
    const recent=room.chat.findLast(m=>m.target===actor?.mark && now-(m.displayAt||m.time)<12000 && byMark(m.mark)?.bot);
    const partner=byMark(event.taunted || recent?.mark);
    if(partner) say(partner,actor,['vi essa carinha, hein! 😂','tô de olho! 👀'],900);
    else if(choose(3)===0) say(pick(players.filter(p=>ready(p)&&opponent(actor,p))),actor,['😂','😎'],900);
    return;
  }
  if(event.taunted) {
    say(byMark(event.taunted),actor,['vi essa carinha, hein! 😂','guarda esse deboche pra revanche! 😏'],900);
    return;
  }
  if(event.greeting) {
    say(pick(players.filter(ready)),null,['Bora jogar? 🎲','Quem vai começar? 👀']);
    return;
  }
  if(event.winner) {
    say(byMark(event.winner),null,['Deu bom! Quem topa revanche? 🏆','Essa ficou comigo! 😎']);
    return;
  }
  if(!actor) return;
  const victims=(event.captured||[]).map(c=>byMark(c.color)).filter(q=>opponent(actor,q));
  const target=pick(victims);
  if(target) {
    const ludo=room.gameId==='ludo';
    const spoke=say(actor,target,ludo?['te dei uma carona pra base! 🏠','olha quem voltou pra casa! 😂']:['essa peça ficou comigo! 😏','achei uma brecha! 👀']);
    if(spoke && choose(2)===0) face(actor,target);
    if(!spoke || choose(2)===0) say(target,actor,ludo?['meu peão já tava tão longe! 😭','na volta eu te pego! 🎲']:['essa peça vai fazer falta! 😅','a próxima é minha! 👀'],spoke?3100:600);
  } else if(event.type==='triple-six' || event.type==='pass') {
    if(choose(3)===0) say(actor,null,['Logo agora eu perdi a vez! 🎲','Vai lá, dado. Na próxima você coopera. 🙄']);
  } else if(event.goodMove) {
    const rival=pick(players.filter(q=>opponent(actor,q)));
    if(say(actor,rival,['viu minha jogada? 😎','essa saiu do jeito que eu queria! 🎯']) && choose(3)===0) {
      face(actor,rival);
      if(choose(2)===0) say(rival,actor,['quero ver repetir! 👀','calma que ainda tem jogo! 😏'],3100);
    }
  }
}
