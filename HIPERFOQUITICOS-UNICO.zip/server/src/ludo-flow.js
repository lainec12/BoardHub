// Coordenação de tempo da sala. Regras continuam no motor puro; clientes não passam turnos.
export function createLudoFlow({engine,apply,publish,timings={}}){
 const time={roll:1800,skip:1500,move:1300,think:1500,choice:10000,single:450,...timings};
 return function sync(r){
  if(r.gameId!=='ludo')return;
  const cancel=()=>{clearTimeout(r.ludoTimer);r.ludoTimer=null;r.ludoTimerKey=null;};
  if(r.status!=='playing'||r.game.winner||r.players.some(p=>!p.socket)){cancel();r.game.flow={state:'PROCESSANDO',visualState:'IDLE',message:r.game.winner?'Partida encerrada':'Aguardando jogadores'};return;}
  const s=r.game,color=s.players[s.turnIndex]?.color,actor=r.players.find(p=>p.mark===color),bot=actor?.bot,automatic=!!actor?.autoPlay,now=Date.now();
  let delay,action,message,state,singleMove=false;
  if(r.ludoLockedUntil>now){delay=r.ludoLockedUntil-now;state='PROCESSANDO';message=r.diceAnimation?.endsAt>now?'Dado rolando…':'Movendo peça…';}
  else{
   const actions=engine.legalActions(s,color),moves=actions.filter(a=>a.type==='move');
   if(s.phase==='move'&&!moves.length){delay=time.skip;action={type:'pass'};state='PROCESSANDO';message='Sem movimentos';}
   else if(s.phase==='postMove'){delay=0;action={type:'end-turn'};state='PROCESSANDO';message='Próximo turno…';}
   else if(s.phase==='roll'){state='AGUARDANDO_ROLAGEM';message=bot?'Computador pensando…':'Clique no dado para rolar';delay=bot||automatic?time.think:time.choice;action=bot?{type:'bot'}:{type:'roll'};}
   else if(s.phase==='move'&&!bot&&moves.length===1){singleMove=true;state='PROCESSANDO';message='Movendo seu único peão disponível…';delay=time.single;action=moves[0];}
   else if(s.phase==='move'){state='AGUARDANDO_MOVIMENTO';message='Escolha um peão';delay=bot||automatic?time.think:time.choice;action=bot?{type:'bot'}:moves[0];}
  }
  const key=[s.round,s.revision,s.phase,state,color,automatic,singleMove].join(':');
  if(r.ludoTimerKey===key)return;
  cancel();r.ludoTimerKey=key;
  const until=delay===undefined?null:now+delay;
  s.flow={state,visualState:r.diceAnimation?.endsAt>now?'ROLLING':r.ludoLockedUntil>now?'MOVING':s.phase==='roll'?'IDLE':'MOVING',message,deadline:until,choiceSeconds:Math.round(time.choice/1000)};
  if(delay===undefined)return;
  r.ludoTimer=setTimeout(()=>{r.ludoTimer=null;r.ludoTimerKey=null;if(r.status!=='playing'||r.game!==s||r.players.some(p=>!p.socket))return;
   if(action){if(!bot&&['AGUARDANDO_ROLAGEM','AGUARDANDO_MOVIMENTO'].includes(state))actor.autoPlay=true;try{apply(r,color,{...action,round:s.round,revision:s.revision});}catch(e){console.error('Ludo automático:',e.message);}}
   publish(r);
  },Math.max(0,delay));r.ludoTimer.unref?.();
 };
}
