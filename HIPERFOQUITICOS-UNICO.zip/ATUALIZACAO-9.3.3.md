# Atualização 9.3.3

Frases, mensagens e provocações permanecem visíveis por até sete segundos. Atualizações do tabuleiro não prolongam esse prazo. Número do dado continua com 2,5 segundos; efeitos cosméticos com até cinco segundos.
