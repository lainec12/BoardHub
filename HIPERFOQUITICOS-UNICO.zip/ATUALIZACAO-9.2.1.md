# Atualização 9.2.1

- Cacheta retirada; permanecem os seis jogos anteriores. Truco também permanece ausente.
- Ludo mais próximo: enquadramento ortográfico calculado pela largura e altura projetadas, mantendo inclinação e base local inferior esquerda.
- Área do tabuleiro responde ao tamanho do celular, computador e altura disponível, com rolagem da página quando necessário para preservar os controles.
- Caminho do Ludo desenhado em um único lote de instâncias, em vez de dezenas de caixas arredondadas independentes. Menor resolução de renderização e geometria dos peões; sem sombras pesadas.
- Balões agora usam apenas um agendamento de expiração, eliminando intervalos contínuos em todas as mesas. Relógio da sala só atualiza periodicamente durante o Ludo ativo.
- Estratégias pesadas de Xadrez e Damas executam em uma thread separada para não bloquear conexão, chat e timers do servidor.
- Controles independentes para música e efeitos, com preferências salvas no navegador. É possível desligar música mantendo efeitos ou desligar ambos.
- Regras, poderes, marcas permanentes e sincronização preservados.

A entrega inclui fonte e compilação. Não foi medida a taxa de quadros em aparelhos reais; as melhorias reduzem custos identificados no código, sem prometer ausência absoluta de travadas. Publicação no Render continua dependendo do envio do pacote ao repositório e novo deploy.

- Divisões do caminho mais finas (intervalo de 1,5% da casa), fundo cinza neutro nas linhas e relevo mais baixo.
