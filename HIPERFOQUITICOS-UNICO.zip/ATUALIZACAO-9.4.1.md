# 9.4.1 — correção da migração de temas

Corrige o destino da coluna equippedTheme para a tabela mapeada Usuarios. O início verifica apenas a falha conhecida da migração 202611180005_store_themes, a ausência da coluna e a existência da tabela correta antes de marcar essa tentativa como revertida e reaplicar o SQL corrigido. Não altera outras migrações falhas e não apaga dados.

Conteúdo funcional da versão 9.4.0 preservado integralmente.
