# Atualização 9.3.2

Balões de mensagens e provocações desaparecem em até três segundos. O número do dado no avatar desaparece em até 2,5 segundos, mesmo que o estado continue guardando a última rolagem ou a partida termine. Atualizações comuns da sala não reiniciam esses temporizadores. Efeitos cosméticos continuam temporários.
