# HIPERFOQUITICOS — projeto unificado

Um ZIP, um package.json, um servidor Node.js, uma instalação. Contém os seis jogos multiplayer, React/Three Fiber, Rapier, lobby e salas, perfil, loja e moedas. Não é preciso copiar partes de projetos anteriores.

## Executar

Requer Node.js 24. Extraia o ZIP numa pasta vazia (para não misturar versões).

```bash
npm ci --include=dev
npm run build
npm start
```

Abra http://localhost:3000. O build já está no pacote; `npm run build` recompila a interface React. Usuários convidados jogam sem PostgreSQL ou Google. O servidor cria SQLite em `data/`, com placar das salas; salas ativas ficam em memória e não sobrevivem ao reinício do servidor.

## Telas e fluxo

- `/`: boas-vindas, Google quando configurado e convidado.
- `/lobby`: cards dos seis jogos. As miniaturas são ilustrações da interface, não jogadores online fictícios; vitórias recentes exibidas são do perfil.
- `/room/:gameId`: modo, dificuldade, nome, convite, assentos e chat. Entrada gratuita: 0 moedas; não há apostas financeiras.
- `/game/:gameId`: partida da sala, sincronizada por Socket.io/Zustand.
- `/profile` e `/shop`: conta, histórico, conquistas, inventário e cosméticos.
- `/legacy`: interface alternativa dos seis jogos, preservada para compatibilidade.

O código de seis caracteres continua funcionando. A sala só começa pelo anfitrião. É possível jogar só com um amigo sem bots, completar vagas com bots ou jogar sozinho. No Ludo, duas pessoas podem formar uma dupla ou jogar em duplas opostas com um bot para cada. Parceiros ficam em cantos opostos e vencem quando suas oito peças chegam.

## Ludo automático

Servidor publica três estados de interface: `AGUARDANDO_ROLAGEM`, `AGUARDANDO_MOVIMENTO` e `PROCESSANDO`. O motor puro mantém suas fases internas para regras; a coordenação da sala controla animações, pausas e prazos.

- Clique direto no dado 3D, ou foque a mesa e pressione Enter/Espaço. Não há botão 2D de rolar.
- Rolagem e movimento bloqueiam entradas até a janela do servidor terminar.
- Sem movimento: aviso por 1,5 s, depois passagem automática.
- Com movimento: até 30 s para escolher; ao esgotar o prazo, o servidor executa uma jogada legal. Não escolhe uma casa ilegal nem confia no cliente.
- Depois de mover, passa automaticamente; o seis conserva sua jogada extra. Três seis consecutivos perdem o turno.
- Bot espera aproximadamente 1,5 s antes de agir.
- Cada rolagem tem ID, resultado e horários do servidor. Todos recebem o mesmo resultado e reproduzem a física cosmeticamentemente; as trajetórias não precisam ser determinísticas entre aparelhos. Não se obtém o dado a partir da física local.
- Rolagem bônus pode ser programada durante a escolha do peão; ela é consumida depois do movimento, se legal. Não existe botão de encerrar/pular turno.
- Reconexão pausa a sala enquanto houver humano offline; timers são cancelados na pausa/reinício/encerramento.
- O motor permite dividir casas seguras sem captura. Barreiras por duas peças estão desativadas.

### Coordenadas seguras

Fonte única: `client/public/ludo-map.js`. Coordenadas `(x,y)` são coluna e linha, de 0 a 14. Servidor e cenas compartilham o mesmo caminho com 52 casas.

| Tipo | Cor | x | y |
|---|---|---:|---:|
| Estrela | Verde | 8 | 2 |
| Estrela | Azul | 6 | 12 |
| Estrela | Vermelha | 2 | 6 |
| Estrela | Amarela | 12 | 8 |
| Partida | Azul | 6 | 13 |
| Partida | Amarela | 13 | 8 |
| Partida | Verde | 8 | 1 |
| Partida | Vermelha | 1 | 6 |

Peças em casa segura têm indicador de proteção. Clicar numa peça protegida que não pode ser selecionada mostra aviso e som breve. Sair da zona remove a proteção natural. Escudo de poder é um efeito separado até o próximo turno.

## Cenas 3D

React Three Fiber/Drei/Rapier no Ludo e na Velha da nova interface. Ludo usa RoundedBox na moldura/casas, Sphere/Cylinder nos peões, Html nos avatares e resultados e Rapier para o dado. Damas, Xadrez, UNO e Batalha Naval reutilizam os motores e renderizadores Three.js do projeto, com seleção por raycasting e controles acessíveis.

Não há assets de jogos de terceiros. A arte é procedural; avatares sem foto usam iniciais/emojis. O acabamento visual ainda não é uma reprodução exata das imagens geradas de referência. O modo 3D exige WebGL. Se ele não estiver disponível, a interface indica a opção de compatibilidade; não afirma que uma cena 2D seja 3D.

## Dificuldade

Todos os jogos recebem Fácil/Médio/Difícil. Fácil usa escolhas legais aleatórias. Velha usa vitória/bloqueio no Médio e Minimax no Difícil (garantia de não perder). Ludo avalia risco, captura, chegada e poderes. Damas/Xadrez usam avaliação material e respostas táticas limitadas no Difícil. UNO usa apenas a própria mão; Batalha Naval só usa os próprios tiros e contagem de posições compatíveis. Nenhum bot lê a mão ou a frota adversária nem altera os dados. Não se promete invencibilidade nos demais jogos.

## Google, conta e moedas

Sem configuração externa, o modo convidado funciona. Para Google e progresso entre dispositivos, são necessários Client ID OAuth e PostgreSQL reais.

Copie `.env.example` para `.env` e preencha:

- `GOOGLE_CLIENT_ID`: Client ID de uma aplicação Google Web.
- `VITE_GOOGLE_CLIENT_ID`: o mesmo Client ID, usado no build da interface.
- `JWT_SECRET`: valor aleatório privado com pelo menos 32 caracteres. Gere com `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.
- `DATABASE_URL`: conexão PostgreSQL persistente.
- `FRONTEND_ORIGIN`: URL exata do site; localmente `http://localhost:3000`.
- `PORT`: definido pela hospedagem; padrão local 3000.

No Google Cloud, cadastre a origem do site e http://localhost:3000 para teste local. O novo fluxo usa ID token Google validado por google-auth-library, seguido de JWT próprio. Não requer Client Secret. `GOOGLE_CLIENT_SECRET` pertence ao fluxo antigo Passport e é opcional; evite configurar ambos sem necessidade. Não envie segredos ao GitHub.

Depois de configurar:

```bash
npm run db:generate
npm run db:deploy
npm run build
npm start
```

As migrações estão em `account/prisma/migrations`. Nunca apague o banco para atualizar o esquema. Cliente Google guarda somente o JWT da plataforma, com expiração de 30 dias, no navegador. Tokens Google não são persistidos. No lobby multiplayer, o JWT é validado no handshake e as customizações são carregadas do servidor.

100 moedas iniciais; vitória +20; empate +5; derrota até -10, sem saldo negativo. Recuperação de 15 moedas por dia UTC quando o saldo é zero. Compras são permanentes e uma categoria de cada vez pode ser equipada. Convidados armazenam progresso local editável pelo próprio usuário; contas usam transações PostgreSQL. O servidor calcula resultados e poderes: não aceita prêmio/placar enviado pelo cliente. IDs únicos impedem concessão duplicada. No multiplayer, resultados e poderes entram numa fila persistida no SQLite; o servidor tenta sincronizar com PostgreSQL a cada cinco segundos e só remove a entrada após sucesso. Chaves únicas evitam pagamento duplicado. A confirmação de saldo/histórico aparece no perfil depois da sincronização. O arquivo SQLite precisa estar em disco persistente para conservar a fila em recriações da hospedagem.

Conquistas de primeira vitória, dez vitórias consecutivas e cinquenta poderes. Uso de poder é contabilizado no servidor com chave única por ação. SQLite conserva o placar da sala, e PostgreSQL é a fonte do saldo da conta. Nenhuma moeda pode ser comprada com dinheiro, apostada por dinheiro real ou sacada.

## Deploy no Render

Envie apenas este pacote como `HIPERFOQUITICOS-UNICO.zip` ao repositório do projeto. Preserve o nome exato, sem sufixo `(1)` ou `(2)`.

Build Command:

```bash
unzip -o HIPERFOQUITICOS-UNICO.zip && npm ci --include=dev && npm run build
```

Start Command: `npm start`.

Defina `NODE_VERSION=24`. Se PostgreSQL estiver configurado, execute `npm run db:deploy` como etapa de release antes do servidor; ou no build após instalar as dependências. Não use GitHub Pages para executar Express/Socket.io. Uma instância única é a configuração atual. Plano gratuito pode suspender o serviço e perder SQLite sem disco persistente. Google e banco não são criados automaticamente pelo ZIP.

## Estrutura

```
client3d/src/                 React, rotas, Zustand, telas e componentes Drei
client/public/               renderizadores Three e build em 3d/
server/src/                  Express, Socket.io, salas e motores autoritativos
server/src/ludo-flow.js       coordenação automática de turno
account/api.js               API de conta Google, JWT e transações
account/prisma/              esquema e migrações PostgreSQL
shared/                      documentação de contratos
client3d/test/ e test/        testes puros e de rede
```

## Verificações e limitações de validação

Build Vite e testes de motores, rede, privacidade, IA, economia local, duplas, zonas seguras e transições automáticas. O navegador remoto disponível não oferece WebGL, portanto não houve validação visual final da nova cena React. Também não houve login Google e execução PostgreSQL reais sem credenciais/banco. Antes de considerar a implantação pronta, confirme esses serviços no ambiente escolhido e confira o visual no dispositivo. Esta é uma entrega de código integrado; não confundir build aprovado com validação completa de produção.


# Atualização 7.1 — sistema global de Foticas (substitui a economia e limites anteriores)

- A unidade da carteira é **Foticas (🧠)**; não tem valor monetário, compra por dinheiro ou saque.
- Bots participam apenas do **treino**, com entrada zero. Vitória/derrota no treino não altera diretamente Foticas; a conta recebe XP e histórico. Baús de nível podem conceder Foticas e cosméticos. Modo convidado não participa de apostas/ranking global.
- Contas reais podem escolher 10, 50 ou 100 Foticas de entrada na sala (validação do servidor aceita inteiros de 1 a 1000). O saldo é reservado atomicamente quando a partida é iniciada, antes da primeira jogada. Sem saldo suficiente, ninguém é debitado e a sala não começa. Não se aceita bot em sala apostada.
- O vencedor recebe o pote completo; duplas dividem o pote entre os parceiros. Empates devolvem as entradas. Resto inteiro numa divisão vai para o ID ordenado do vencedor, sem criar nem perder Foticas do pote.
- Capturas válidas em sala apostada dão +10 Foticas por peça (Ludo/Damas/Xadrez; um navio afundado na Naval conta como uma unidade). Treino não concede Foticas por captura. Créditos são identificados por ação canônica e não por informação enviada pelo cliente.
- Não se permite expulsar oponente ou reiniciar uma partida apostada em andamento. Abandono concede a vitória aos adversários restantes (ou à dupla adversária) e encerra a partida. Reservas órfãs de sala perdida no reinício são devolvidas após detecção no PostgreSQL; não afetam ELO.
- Uma conta possui XP global, nível, nickname, avatar, moldura e dado. O nível começa em 1, a cada 100 XP. Partidas de sala dão 20 XP e vitórias 50 XP; o desafio solo de Velha dá 20 XP. Cada novo nível dá um baú com 30 Foticas e um cosmético não adquirido, se ainda houver um disponível.
- Baú diário: 20 Foticas uma vez por dia UTC. Missão de três partidas no dia: 30 Foticas uma vez por dia UTC. São recompensas solicitadas no lobby e validadas no servidor.
- Cada jogo tem sua linha de ranking: ELO inicial 1000, atualização K=24, apenas em partidas apostadas contra humanos. Perfis mostram ELO por jogo e faixas Bronze/Prata/Ouro/Diamante. O botão “Encontrar oponentes pelo ranking” procura sala do mesmo jogo e entrada com diferença de até 200 ELO. Não inventa jogadores: aguarda pessoas reais entrarem e o anfitrião iniciar.
- O perfil mostra o histórico de todos os jogos. A loja continua central, com itens permanentes e equipamento por categoria. O saldo anterior não é apagado: a coluna interna `coins` passa a representar Foticas.

## Poderes 7.1

Nas partidas de Ludo com poderes, são gerados **três itens no caminho**, nunca nas oito casas seguras ou em casas ocupadas. A geração é do servidor e não é uma posição fixa. Ao cair exatamente na casa, o item é coletado e outro nasce imediatamente em uma casa elegível.

Inventário sem limite. Escudo, Duplo, Escolher Dado e Bônus aparecem em faixa horizontal com contadores. É permitido usar diferentes poderes na mesma vez, inclusive escolher o dado + duplo + escudo. Escudos em múltiplas peças são mantidos individualmente até o próximo turno do dono. Os bloqueios dos dois primeiros turnos e de um único poder por turno foram removidos.

Mantêm-se dois limites de mecânica: Duplo não é aplicado a 6 nem duas vezes à mesma rolagem; Bônus não encadeia outro Bônus na mesma sequência. Não existem Congelar/Teleporte. O inventário inicial de Campeonato/Poder Extra continua opcional, mas a coleta em campo não tem teto em nenhum deles. A coleta substitui a aquisição antiga por quatro casas fixas.

## Publicação da atualização

Permanece **um único ZIP e servidor**: `HIPERFOQUITICOS-UNICO.zip`. Mesmo Build Command do Render. `npm start` aplica automaticamente as migrações versionadas se `DATABASE_URL` estiver definida, antes de abrir o serviço. Não executa reset, não apaga histórico nem saldo. Mantenha `npm ci --include=dev` no build para instalar o CLI de migrações.

Google/PostgreSQL continuam exigindo configuração real. Sem ela, o treino de convidados funciona, mas apostas, ELO, baús e a conta global ficam indisponíveis. Testes puros/de rede não substituem validação transacional em um PostgreSQL de homologação: antes de abrir partidas apostadas ao público, valide reservas concorrentes, liquidação e reconexões no banco escolhido.


# Atualização 7.2 — migração para 2D/2.5D (substitui a arquitetura 3D anterior)

Three.js, Fiber, Drei e Rapier foram removidos das dependências e dos renderizadores ativos. A interface principal usa React, CSS e Framer Motion. Não precisa de GPU/WebGL, raycasting, WASM de física ou controles de câmera. O nome interno da pasta `client3d` e o endereço técnico `/3d/assets` foram mantidos apenas para compatibilidade de publicação; não indicam uso de 3D.

Ludo usa grade HTML exata de 15x15, peões de CSS com gradientes/sombras, casas em relevo, bases rebaixadas por sombra interna, dado detalhado com pintas e rotação/quique CSS e movimentos casa a casa pelo Framer Motion. As posições continuam sendo calculadas e validadas no servidor. Clique no peão válido: o destino é determinado pela rolagem, não por uma coordenada arbitrária enviada pelo cliente. Os controles alternativos de peões oferecem áreas de toque maiores.

Damas, Xadrez, UNO e Naval usam seus controles DOM existentes, com sombras e relevos em CSS; Velha usa botões com X/O em relevo. Todos os jogos continuam multiplayer/solo, com as mesmas regras, salas, bots, Foticas, conta, rankings e poderes da versão 7.1. O dado continua compartilhando ID, face e prazo do servidor e reproduzindo a animação visual para os clientes. Não há física local determinando resultado.

O design Hiperfoco usa TailwindCSS v4 via @tailwindcss/vite e tokens @theme: fundo #1a0b2e/#0f172a, primária #8b5cf6, secundária #3b82f6, ganho #10b981, perigo #ef4444. Cards translúcidos, hover roxo, botões arredondados e avatares com borda da vez. Poppins é carregada do Google Fonts, com fallback local de sistema quando a fonte externa não estiver disponível. A mudança de iluminação física por gradientes e sombras é deliberada: não há cena Three a iluminar.

O build observado passou de aproximadamente 4 MB para 500 KB de JavaScript bruto. Isso é tamanho de bundle, não uma medição de FPS em todos os aparelhos. Build e os 94 testes existentes passaram; o novo acabamento visual ainda deve ser conferido no aparelho/navegador de uso. Os requisitos externos de Google/PostgreSQL e validação transacional de apostas continuam válidos.

Arquivo e comandos de publicação permanecem iguais: `HIPERFOQUITICOS-UNICO.zip`, `npm ci --include=dev`, `npm run build`, `npm start`. Não é preciso juntar projetos.


# Atualização 7.2.1 — HUD nos cantos e fallback OAuth

A HUD do Ludo fica em uma camada absoluta pertencente ao tabuleiro: vermelho em cima à esquerda, verde em cima à direita, azul embaixo à esquerda e amarelo embaixo à direita. A grade de assentos da espera é ocultada ao iniciar o Ludo. Cada avatar mostra nome, peças na chegada e vitórias, com anel pulsante na cor da base durante a vez, seta e balão da última rolagem daquele jogador. O efeito respeita preferência por movimento reduzido. É posicionamento CSS/HTML, não Drei, pois a plataforma agora é 2.5D.

## Google aparece indisponível?

O Client ID é uma informação pública, normalmente como `123456-abc.apps.googleusercontent.com`. Não é o Client Secret. Nunca use um ID fictício para fazer o botão parecer ativo.

1. No Render, abra Environment e defina **VITE_GOOGLE_CLIENT_ID** e **GOOGLE_CLIENT_ID** com o mesmo Client ID Web do Google Cloud. As duas variáveis não são segredos, mas `JWT_SECRET` e `DATABASE_URL` são privados.
2. Configure também `JWT_SECRET` (32+ caracteres), `DATABASE_URL` e `FRONTEND_ORIGIN`. Sem backend/banco, o botão não basta para salvar conta global.
3. No Google Cloud, adicione como origem JavaScript autorizada a URL HTTPS exata do seu site. O novo fluxo ID token não utiliza callback Passport.
4. Rode o build novamente após alterar **VITE_***: o Vite incorpora esses valores no JavaScript durante o build, não quando o navegador abre. O `envDir` do Vite aponta para a raiz do projeto; o `.env` local deve ficar junto ao package.json. Reinicie `npm run dev` se estiver usando o dev server.
5. O aplicativo agora tem um fallback: se o valor de build faltar ou for inválido, consulta **GET /api/public-config** e usa apenas o **GOOGLE_CLIENT_ID público do servidor**. Não entrega JWT_SECRET, Client Secret ou URL do banco. A consulta tem limite de cinco segundos e, se falhar, libera o modo convidado.
6. Sem Client ID válido em nenhuma das fontes, o login Google fica indisponível e “Jogar como convidado” continua funcionando. Depois de configurar o serviço, recarregue a página.

`main.jsx` passa ao GoogleOAuthProvider o ID validado após essa leitura; `App.jsx` usa a mesma fonte para decidir renderizar GoogleLogin. Isso evita checar duas configurações diferentes. Para diagnosticar sem abrir credenciais, consulte `/api/public-config`: `googleClientId` deve estar preenchido e `accountsEnabled` deve ser true para a conta global. Não imprima tokens ou segredos no console.
