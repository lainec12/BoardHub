# HIPERFOQUITICOS — projeto unificado

Um ZIP, um package.json, um servidor Node.js, uma instalação. Contém os seis jogos multiplayer, React/Three Fiber, Rapier, lobby e salas, perfil, loja e moedas. Não é preciso copiar partes de projetos anteriores.

## Executar

Requer Node.js 24. Extraia o ZIP numa pasta vazia (para não misturar versões).

```bash
npm ci --include=dev
npm run build
npm start
```

Abra http://localhost:3000. O build já está no pacote; `npm run build` recompila a interface React. Usuários convidados jogam sem PostgreSQL ou Google. O servidor cria SQLite em `data/`, com placar das salas; salas ativas ficam em memória e não sobrevivem ao reinício do servidor.

## Telas e fluxo

- `/`: boas-vindas, Google quando configurado e convidado.
- `/lobby`: cards dos seis jogos. As miniaturas são ilustrações da interface, não jogadores online fictícios; vitórias recentes exibidas são do perfil.
- `/room/:gameId`: modo, dificuldade, nome, convite, assentos e chat. Entrada gratuita: 0 moedas; não há apostas financeiras.
- `/game/:gameId`: partida da sala, sincronizada por Socket.io/Zustand.
- `/profile` e `/shop`: conta, histórico, conquistas, inventário e cosméticos.
- `/legacy`: interface alternativa dos seis jogos, preservada para compatibilidade.

O código de seis caracteres continua funcionando. A sala só começa pelo anfitrião. É possível jogar só com um amigo sem bots, completar vagas com bots ou jogar sozinho. No Ludo, duas pessoas podem formar uma dupla ou jogar em duplas opostas com um bot para cada. Parceiros ficam em cantos opostos e vencem quando suas oito peças chegam.

## Ludo automático

Servidor publica três estados de interface: `AGUARDANDO_ROLAGEM`, `AGUARDANDO_MOVIMENTO` e `PROCESSANDO`. O motor puro mantém suas fases internas para regras; a coordenação da sala controla animações, pausas e prazos.

- Clique direto no dado 3D, ou foque a mesa e pressione Enter/Espaço. Não há botão 2D de rolar.
- Rolagem e movimento bloqueiam entradas até a janela do servidor terminar.
- Sem movimento: aviso por 1,5 s, depois passagem automática.
- Com movimento: até 30 s para escolher; ao esgotar o prazo, o servidor executa uma jogada legal. Não escolhe uma casa ilegal nem confia no cliente.
- Depois de mover, passa automaticamente; o seis conserva sua jogada extra. Três seis consecutivos perdem o turno.
- Bot espera aproximadamente 1,5 s antes de agir.
- Cada rolagem tem ID, resultado e horários do servidor. Todos recebem o mesmo resultado e reproduzem a física cosmeticamentemente; as trajetórias não precisam ser determinísticas entre aparelhos. Não se obtém o dado a partir da física local.
- Rolagem bônus pode ser programada durante a escolha do peão; ela é consumida depois do movimento, se legal. Não existe botão de encerrar/pular turno.
- Reconexão pausa a sala enquanto houver humano offline; timers são cancelados na pausa/reinício/encerramento.
- O motor permite dividir casas seguras sem captura. Barreiras por duas peças estão desativadas.

### Coordenadas seguras

Fonte única: `client/public/ludo-map.js`. Coordenadas `(x,y)` são coluna e linha, de 0 a 14. Servidor e cenas compartilham o mesmo caminho com 52 casas.

| Tipo | Cor | x | y |
|---|---|---:|---:|
| Estrela | Verde | 8 | 2 |
| Estrela | Azul | 6 | 12 |
| Estrela | Vermelha | 2 | 6 |
| Estrela | Amarela | 12 | 8 |
| Partida | Azul | 6 | 13 |
| Partida | Amarela | 13 | 8 |
| Partida | Verde | 8 | 1 |
| Partida | Vermelha | 1 | 6 |

Peças em casa segura têm indicador de proteção. Clicar numa peça protegida que não pode ser selecionada mostra aviso e som breve. Sair da zona remove a proteção natural. Escudo de poder é um efeito separado até o próximo turno.

## Cenas 3D

React Three Fiber/Drei/Rapier no Ludo e na Velha da nova interface. Ludo usa RoundedBox na moldura/casas, Sphere/Cylinder nos peões, Html nos avatares e resultados e Rapier para o dado. Damas, Xadrez, UNO e Batalha Naval reutilizam os motores e renderizadores Three.js do projeto, com seleção por raycasting e controles acessíveis.

Não há assets de jogos de terceiros. A arte é procedural; avatares sem foto usam iniciais/emojis. O acabamento visual ainda não é uma reprodução exata das imagens geradas de referência. O modo 3D exige WebGL. Se ele não estiver disponível, a interface indica a opção de compatibilidade; não afirma que uma cena 2D seja 3D.

## Dificuldade

Todos os jogos recebem Fácil/Médio/Difícil. Fácil usa escolhas legais aleatórias. Velha usa vitória/bloqueio no Médio e Minimax no Difícil (garantia de não perder). Ludo avalia risco, captura, chegada e poderes. Damas/Xadrez usam avaliação material e respostas táticas limitadas no Difícil. UNO usa apenas a própria mão; Batalha Naval só usa os próprios tiros e contagem de posições compatíveis. Nenhum bot lê a mão ou a frota adversária nem altera os dados. Não se promete invencibilidade nos demais jogos.

## Google, conta e moedas

Sem configuração externa, o modo convidado funciona. Para Google e progresso entre dispositivos, são necessários Client ID OAuth e PostgreSQL reais.

Copie `.env.example` para `.env` e preencha:

- `GOOGLE_CLIENT_ID`: Client ID de uma aplicação Google Web.
- `VITE_GOOGLE_CLIENT_ID`: o mesmo Client ID, usado no build da interface.
- `JWT_SECRET`: valor aleatório privado com pelo menos 32 caracteres. Gere com `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.
- `DATABASE_URL`: conexão PostgreSQL persistente.
- `FRONTEND_ORIGIN`: URL exata do site; localmente `http://localhost:3000`.
- `PORT`: definido pela hospedagem; padrão local 3000.

No Google Cloud, cadastre a origem do site e http://localhost:3000 para teste local. O novo fluxo usa ID token Google validado por google-auth-library, seguido de JWT próprio. Não requer Client Secret. `GOOGLE_CLIENT_SECRET` pertence ao fluxo antigo Passport e é opcional; evite configurar ambos sem necessidade. Não envie segredos ao GitHub.

Depois de configurar:

```bash
npm run db:generate
npm run db:deploy
npm run build
npm start
```

As migrações estão em `account/prisma/migrations`. Nunca apague o banco para atualizar o esquema. Cliente Google guarda somente o JWT da plataforma, com expiração de 30 dias, no navegador. Tokens Google não são persistidos. No lobby multiplayer, o JWT é validado no handshake e as customizações são carregadas do servidor.

100 moedas iniciais; vitória +20; empate +5; derrota até -10, sem saldo negativo. Recuperação de 15 moedas por dia UTC quando o saldo é zero. Compras são permanentes e uma categoria de cada vez pode ser equipada. Convidados armazenam progresso local editável pelo próprio usuário; contas usam transações PostgreSQL. O servidor calcula resultados e poderes: não aceita prêmio/placar enviado pelo cliente. IDs únicos impedem concessão duplicada. No multiplayer, resultados e poderes entram numa fila persistida no SQLite; o servidor tenta sincronizar com PostgreSQL a cada cinco segundos e só remove a entrada após sucesso. Chaves únicas evitam pagamento duplicado. A confirmação de saldo/histórico aparece no perfil depois da sincronização. O arquivo SQLite precisa estar em disco persistente para conservar a fila em recriações da hospedagem.

Conquistas de primeira vitória, dez vitórias consecutivas e cinquenta poderes. Uso de poder é contabilizado no servidor com chave única por ação. SQLite conserva o placar da sala, e PostgreSQL é a fonte do saldo da conta. Nenhuma moeda pode ser comprada com dinheiro, apostada por dinheiro real ou sacada.

## Deploy no Render

Envie apenas este pacote como `HIPERFOQUITICOS-UNICO.zip` ao repositório do projeto. Preserve o nome exato, sem sufixo `(1)` ou `(2)`.

Build Command:

```bash
unzip -o HIPERFOQUITICOS-UNICO.zip && npm ci --include=dev && npm run build
```

Start Command: `npm start`.

Defina `NODE_VERSION=24`. Se PostgreSQL estiver configurado, execute `npm run db:deploy` como etapa de release antes do servidor; ou no build após instalar as dependências. Não use GitHub Pages para executar Express/Socket.io. Uma instância única é a configuração atual. Plano gratuito pode suspender o serviço e perder SQLite sem disco persistente. Google e banco não são criados automaticamente pelo ZIP.

## Estrutura

```
client3d/src/                 React, rotas, Zustand, telas e componentes Drei
client/public/               renderizadores Three e build em 3d/
server/src/                  Express, Socket.io, salas e motores autoritativos
server/src/ludo-flow.js       coordenação automática de turno
account/api.js               API de conta Google, JWT e transações
account/prisma/              esquema e migrações PostgreSQL
shared/                      documentação de contratos
client3d/test/ e test/        testes puros e de rede
```

## Verificações e limitações de validação

Build Vite e testes de motores, rede, privacidade, IA, economia local, duplas, zonas seguras e transições automáticas. O navegador remoto disponível não oferece WebGL, portanto não houve validação visual final da nova cena React. Também não houve login Google e execução PostgreSQL reais sem credenciais/banco. Antes de considerar a implantação pronta, confirme esses serviços no ambiente escolhido e confira o visual no dispositivo. Esta é uma entrega de código integrado; não confundir build aprovado com validação completa de produção.
