# HIPERFOQUITICOS — projeto unificado

Um ZIP, um package.json, um servidor Node.js, uma instalação. Contém os seis jogos multiplayer, React/Three Fiber, Rapier, lobby e salas, perfil, loja e moedas. Não é preciso copiar partes de projetos anteriores.

## Executar

Requer Node.js 24. Extraia o ZIP numa pasta vazia (para não misturar versões).

```bash
npm ci --include=dev
npm run build
npm start
```

Abra http://localhost:3000. O build já está no pacote; `npm run build` recompila a interface React. Usuários convidados jogam sem PostgreSQL ou Google. O servidor cria SQLite em `data/`, com placar das salas; salas ativas ficam em memória e não sobrevivem ao reinício do servidor.

## Telas e fluxo

- `/`: boas-vindas, Google quando configurado e convidado.
- `/lobby`: cards dos seis jogos. As miniaturas são ilustrações da interface, não jogadores online fictícios; vitórias recentes exibidas são do perfil.
- `/room/:gameId`: modo, dificuldade, nome, convite, assentos e chat. Entrada gratuita: 0 moedas; não há apostas financeiras.
- `/game/:gameId`: partida da sala, sincronizada por Socket.io/Zustand.
- `/profile` e `/shop`: conta, histórico, conquistas, inventário e cosméticos.
- `/legacy`: interface alternativa dos seis jogos, preservada para compatibilidade.

O código de seis caracteres continua funcionando. A sala só começa pelo anfitrião. É possível jogar só com um amigo sem bots, completar vagas com bots ou jogar sozinho. No Ludo, duas pessoas podem formar uma dupla ou jogar em duplas opostas com um bot para cada. Parceiros ficam em cantos opostos e vencem quando suas oito peças chegam.

## Ludo automático

Servidor publica três estados de interface: `AGUARDANDO_ROLAGEM`, `AGUARDANDO_MOVIMENTO` e `PROCESSANDO`. O motor puro mantém suas fases internas para regras; a coordenação da sala controla animações, pausas e prazos.

- Clique direto no dado 3D, ou foque a mesa e pressione Enter/Espaço. Não há botão 2D de rolar.
- Rolagem e movimento bloqueiam entradas até a janela do servidor terminar.
- Sem movimento: aviso por 1,5 s, depois passagem automática.
- Com movimento: até 30 s para escolher; ao esgotar o prazo, o servidor executa uma jogada legal. Não escolhe uma casa ilegal nem confia no cliente.
- Depois de mover, passa automaticamente; o seis conserva sua jogada extra. Três seis consecutivos perdem o turno.
- Bot espera aproximadamente 1,5 s antes de agir.
- Cada rolagem tem ID, resultado e horários do servidor. Todos recebem o mesmo resultado e reproduzem a física cosmeticamentemente; as trajetórias não precisam ser determinísticas entre aparelhos. Não se obtém o dado a partir da física local.
- Rolagem bônus pode ser programada durante a escolha do peão; ela é consumida depois do movimento, se legal. Não existe botão de encerrar/pular turno.
- Reconexão pausa a sala enquanto houver humano offline; timers são cancelados na pausa/reinício/encerramento.
- O motor permite dividir casas seguras sem captura. Barreiras por duas peças estão desativadas.

### Coordenadas seguras

Fonte única: `client/public/ludo-map.js`. Coordenadas `(x,y)` são coluna e linha, de 0 a 14. Servidor e cenas compartilham o mesmo caminho com 52 casas.

| Tipo | Cor | x | y |
|---|---|---:|---:|
| Estrela | Verde | 8 | 2 |
| Estrela | Azul | 6 | 12 |
| Estrela | Vermelha | 2 | 6 |
| Estrela | Amarela | 12 | 8 |
| Partida | Azul | 6 | 13 |
| Partida | Amarela | 13 | 8 |
| Partida | Verde | 8 | 1 |
| Partida | Vermelha | 1 | 6 |

Peças em casa segura têm indicador de proteção. Clicar numa peça protegida que não pode ser selecionada mostra aviso e som breve. Sair da zona remove a proteção natural. Escudo de poder é um efeito separado até o próximo turno.

## Cenas 3D

React Three Fiber/Drei/Rapier no Ludo e na Velha da nova interface. Ludo usa RoundedBox na moldura/casas, Sphere/Cylinder nos peões, Html nos avatares e resultados e Rapier para o dado. Damas, Xadrez, UNO e Batalha Naval reutilizam os motores e renderizadores Three.js do projeto, com seleção por raycasting e controles acessíveis.

Não há assets de jogos de terceiros. A arte é procedural; avatares sem foto usam iniciais/emojis. O acabamento visual ainda não é uma reprodução exata das imagens geradas de referência. O modo 3D exige WebGL. Se ele não estiver disponível, a interface indica a opção de compatibilidade; não afirma que uma cena 2D seja 3D.

## Dificuldade

Todos os jogos recebem Fácil/Médio/Difícil. Fácil usa escolhas legais aleatórias. Velha usa vitória/bloqueio no Médio e Minimax no Difícil (garantia de não perder). Ludo avalia risco, captura, chegada e poderes. Damas/Xadrez usam avaliação material e respostas táticas limitadas no Difícil. UNO usa apenas a própria mão; Batalha Naval só usa os próprios tiros e contagem de posições compatíveis. Nenhum bot lê a mão ou a frota adversária nem altera os dados. Não se promete invencibilidade nos demais jogos.

## Google, conta e moedas

Sem configuração externa, o modo convidado funciona. Para Google e progresso entre dispositivos, são necessários Client ID OAuth e PostgreSQL reais.

Copie `.env.example` para `.env` e preencha:

- `GOOGLE_CLIENT_ID`: Client ID de uma aplicação Google Web.
- `VITE_GOOGLE_CLIENT_ID`: o mesmo Client ID, usado no build da interface.
- `JWT_SECRET`: valor aleatório privado com pelo menos 32 caracteres. Gere com `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.
- `DATABASE_URL`: conexão PostgreSQL persistente.
- `FRONTEND_ORIGIN`: URL exata do site; localmente `http://localhost:3000`.
- `PORT`: definido pela hospedagem; padrão local 3000.

No Google Cloud, cadastre a origem do site e http://localhost:3000 para teste local. O novo fluxo usa ID token Google validado por google-auth-library, seguido de JWT próprio. Não requer Client Secret. `GOOGLE_CLIENT_SECRET` pertence ao fluxo antigo Passport e é opcional; evite configurar ambos sem necessidade. Não envie segredos ao GitHub.

Depois de configurar:

```bash
npm run db:generate
npm run db:deploy
npm run build
npm start
```

As migrações estão em `account/prisma/migrations`. Nunca apague o banco para atualizar o esquema. Cliente Google guarda somente o JWT da plataforma, com expiração de 30 dias, no navegador. Tokens Google não são persistidos. No lobby multiplayer, o JWT é validado no handshake e as customizações são carregadas do servidor.

100 moedas iniciais; vitória +20; empate +5; derrota até -10, sem saldo negativo. Recuperação de 15 moedas por dia UTC quando o saldo é zero. Compras são permanentes e uma categoria de cada vez pode ser equipada. Convidados armazenam progresso local editável pelo próprio usuário; contas usam transações PostgreSQL. O servidor calcula resultados e poderes: não aceita prêmio/placar enviado pelo cliente. IDs únicos impedem concessão duplicada. No multiplayer, resultados e poderes entram numa fila persistida no SQLite; o servidor tenta sincronizar com PostgreSQL a cada cinco segundos e só remove a entrada após sucesso. Chaves únicas evitam pagamento duplicado. A confirmação de saldo/histórico aparece no perfil depois da sincronização. O arquivo SQLite precisa estar em disco persistente para conservar a fila em recriações da hospedagem.

Conquistas de primeira vitória, dez vitórias consecutivas e cinquenta poderes. Uso de poder é contabilizado no servidor com chave única por ação. SQLite conserva o placar da sala, e PostgreSQL é a fonte do saldo da conta. Nenhuma moeda pode ser comprada com dinheiro, apostada por dinheiro real ou sacada.

## Deploy no Render

Envie apenas este pacote como `HIPERFOQUITICOS-UNICO.zip` ao repositório do projeto. Preserve o nome exato, sem sufixo `(1)` ou `(2)`.

Build Command:

```bash
unzip -o HIPERFOQUITICOS-UNICO.zip && npm ci --include=dev && npm run build
```

Start Command: `npm start`.

Defina `NODE_VERSION=24`. Se PostgreSQL estiver configurado, execute `npm run db:deploy` como etapa de release antes do servidor; ou no build após instalar as dependências. Não use GitHub Pages para executar Express/Socket.io. Uma instância única é a configuração atual. Plano gratuito pode suspender o serviço e perder SQLite sem disco persistente. Google e banco não são criados automaticamente pelo ZIP.

## Estrutura

```
client3d/src/                 React, rotas, Zustand, telas e componentes Drei
client/public/               renderizadores Three e build em 3d/
server/src/                  Express, Socket.io, salas e motores autoritativos
server/src/ludo-flow.js       coordenação automática de turno
account/api.js               API de conta Google, JWT e transações
account/prisma/              esquema e migrações PostgreSQL
shared/                      documentação de contratos
client3d/test/ e test/        testes puros e de rede
```

## Verificações e limitações de validação

Build Vite e testes de motores, rede, privacidade, IA, economia local, duplas, zonas seguras e transições automáticas. O navegador remoto disponível não oferece WebGL, portanto não houve validação visual final da nova cena React. Também não houve login Google e execução PostgreSQL reais sem credenciais/banco. Antes de considerar a implantação pronta, confirme esses serviços no ambiente escolhido e confira o visual no dispositivo. Esta é uma entrega de código integrado; não confundir build aprovado com validação completa de produção.


# Atualização 7.1 — sistema global de Foticas (substitui a economia e limites anteriores)

- A unidade da carteira é **Foticas (🧠)**; não tem valor monetário, compra por dinheiro ou saque.
- Bots participam apenas do **treino**, com entrada zero. Vitória/derrota no treino não altera diretamente Foticas; a conta recebe XP e histórico. Baús de nível podem conceder Foticas e cosméticos. Modo convidado não participa de apostas/ranking global.
- Contas reais podem escolher 10, 50 ou 100 Foticas de entrada na sala (validação do servidor aceita inteiros de 1 a 1000). O saldo é reservado atomicamente quando a partida é iniciada, antes da primeira jogada. Sem saldo suficiente, ninguém é debitado e a sala não começa. Não se aceita bot em sala apostada.
- O vencedor recebe o pote completo; duplas dividem o pote entre os parceiros. Empates devolvem as entradas. Resto inteiro numa divisão vai para o ID ordenado do vencedor, sem criar nem perder Foticas do pote.
- Capturas válidas em sala apostada dão +10 Foticas por peça (Ludo/Damas/Xadrez; um navio afundado na Naval conta como uma unidade). Treino não concede Foticas por captura. Créditos são identificados por ação canônica e não por informação enviada pelo cliente.
- Não se permite expulsar oponente ou reiniciar uma partida apostada em andamento. Abandono concede a vitória aos adversários restantes (ou à dupla adversária) e encerra a partida. Reservas órfãs de sala perdida no reinício são devolvidas após detecção no PostgreSQL; não afetam ELO.
- Uma conta possui XP global, nível, nickname, avatar, moldura e dado. O nível começa em 1, a cada 100 XP. Partidas de sala dão 20 XP e vitórias 50 XP; o desafio solo de Velha dá 20 XP. Cada novo nível dá um baú com 30 Foticas e um cosmético não adquirido, se ainda houver um disponível.
- Baú diário: 20 Foticas uma vez por dia UTC. Missão de três partidas no dia: 30 Foticas uma vez por dia UTC. São recompensas solicitadas no lobby e validadas no servidor.
- Cada jogo tem sua linha de ranking: ELO inicial 1000, atualização K=24, apenas em partidas apostadas contra humanos. Perfis mostram ELO por jogo e faixas Bronze/Prata/Ouro/Diamante. O botão “Encontrar oponentes pelo ranking” procura sala do mesmo jogo e entrada com diferença de até 200 ELO. Não inventa jogadores: aguarda pessoas reais entrarem e o anfitrião iniciar.
- O perfil mostra o histórico de todos os jogos. A loja continua central, com itens permanentes e equipamento por categoria. O saldo anterior não é apagado: a coluna interna `coins` passa a representar Foticas.

## Poderes 7.1

Nas partidas de Ludo com poderes, são gerados **três itens no caminho**, nunca nas oito casas seguras ou em casas ocupadas. A geração é do servidor e não é uma posição fixa. Ao cair exatamente na casa, o item é coletado e outro nasce imediatamente em uma casa elegível.

Inventário sem limite. Escudo, Duplo, Escolher Dado e Bônus aparecem em faixa horizontal com contadores. É permitido usar diferentes poderes na mesma vez, inclusive escolher o dado + duplo + escudo. Escudos em múltiplas peças são mantidos individualmente até o próximo turno do dono. Os bloqueios dos dois primeiros turnos e de um único poder por turno foram removidos.

Mantêm-se dois limites de mecânica: Duplo não é aplicado a 6 nem duas vezes à mesma rolagem; Bônus não encadeia outro Bônus na mesma sequência. Não existem Congelar/Teleporte. O inventário inicial de Campeonato/Poder Extra continua opcional, mas a coleta em campo não tem teto em nenhum deles. A coleta substitui a aquisição antiga por quatro casas fixas.

## Publicação da atualização

Permanece **um único ZIP e servidor**: `HIPERFOQUITICOS-UNICO.zip`. Mesmo Build Command do Render. `npm start` aplica automaticamente as migrações versionadas se `DATABASE_URL` estiver definida, antes de abrir o serviço. Não executa reset, não apaga histórico nem saldo. Mantenha `npm ci --include=dev` no build para instalar o CLI de migrações.

Google/PostgreSQL continuam exigindo configuração real. Sem ela, o treino de convidados funciona, mas apostas, ELO, baús e a conta global ficam indisponíveis. Testes puros/de rede não substituem validação transacional em um PostgreSQL de homologação: antes de abrir partidas apostadas ao público, valide reservas concorrentes, liquidação e reconexões no banco escolhido.


# Atualização 7.2 — migração para 2D/2.5D (substitui a arquitetura 3D anterior)

Three.js, Fiber, Drei e Rapier foram removidos das dependências e dos renderizadores ativos. A interface principal usa React, CSS e Framer Motion. Não precisa de GPU/WebGL, raycasting, WASM de física ou controles de câmera. O nome interno da pasta `client3d` e o endereço técnico `/3d/assets` foram mantidos apenas para compatibilidade de publicação; não indicam uso de 3D.

Ludo usa grade HTML exata de 15x15, peões de CSS com gradientes/sombras, casas em relevo, bases rebaixadas por sombra interna, dado detalhado com pintas e rotação/quique CSS e movimentos casa a casa pelo Framer Motion. As posições continuam sendo calculadas e validadas no servidor. Clique no peão válido: o destino é determinado pela rolagem, não por uma coordenada arbitrária enviada pelo cliente. Os controles alternativos de peões oferecem áreas de toque maiores.

Damas, Xadrez, UNO e Naval usam seus controles DOM existentes, com sombras e relevos em CSS; Velha usa botões com X/O em relevo. Todos os jogos continuam multiplayer/solo, com as mesmas regras, salas, bots, Foticas, conta, rankings e poderes da versão 7.1. O dado continua compartilhando ID, face e prazo do servidor e reproduzindo a animação visual para os clientes. Não há física local determinando resultado.

O design Hiperfoco usa TailwindCSS v4 via @tailwindcss/vite e tokens @theme: fundo #1a0b2e/#0f172a, primária #8b5cf6, secundária #3b82f6, ganho #10b981, perigo #ef4444. Cards translúcidos, hover roxo, botões arredondados e avatares com borda da vez. Poppins é carregada do Google Fonts, com fallback local de sistema quando a fonte externa não estiver disponível. A mudança de iluminação física por gradientes e sombras é deliberada: não há cena Three a iluminar.

O build observado passou de aproximadamente 4 MB para 500 KB de JavaScript bruto. Isso é tamanho de bundle, não uma medição de FPS em todos os aparelhos. Build e os 94 testes existentes passaram; o novo acabamento visual ainda deve ser conferido no aparelho/navegador de uso. Os requisitos externos de Google/PostgreSQL e validação transacional de apostas continuam válidos.

Arquivo e comandos de publicação permanecem iguais: `HIPERFOQUITICOS-UNICO.zip`, `npm ci --include=dev`, `npm run build`, `npm start`. Não é preciso juntar projetos.


# Atualização 7.2.1 — HUD nos cantos e fallback OAuth

A HUD do Ludo fica em uma camada absoluta pertencente ao tabuleiro: vermelho em cima à esquerda, verde em cima à direita, azul embaixo à esquerda e amarelo embaixo à direita. A grade de assentos da espera é ocultada ao iniciar o Ludo. Cada avatar mostra nome, peças na chegada e vitórias, com anel pulsante na cor da base durante a vez, seta e balão da última rolagem daquele jogador. O efeito respeita preferência por movimento reduzido. É posicionamento CSS/HTML, não Drei, pois a plataforma agora é 2.5D.

## Google aparece indisponível?

O Client ID é uma informação pública, normalmente como `123456-abc.apps.googleusercontent.com`. Não é o Client Secret. Nunca use um ID fictício para fazer o botão parecer ativo.

1. No Render, abra Environment e defina **VITE_GOOGLE_CLIENT_ID** e **GOOGLE_CLIENT_ID** com o mesmo Client ID Web do Google Cloud. As duas variáveis não são segredos, mas `JWT_SECRET` e `DATABASE_URL` são privados.
2. Configure também `JWT_SECRET` (32+ caracteres), `DATABASE_URL` e `FRONTEND_ORIGIN`. Sem backend/banco, o botão não basta para salvar conta global.
3. No Google Cloud, adicione como origem JavaScript autorizada a URL HTTPS exata do seu site. O novo fluxo ID token não utiliza callback Passport.
4. Rode o build novamente após alterar **VITE_***: o Vite incorpora esses valores no JavaScript durante o build, não quando o navegador abre. O `envDir` do Vite aponta para a raiz do projeto; o `.env` local deve ficar junto ao package.json. Reinicie `npm run dev` se estiver usando o dev server.
5. O aplicativo agora tem um fallback: se o valor de build faltar ou for inválido, consulta **GET /api/public-config** e usa apenas o **GOOGLE_CLIENT_ID público do servidor**. Não entrega JWT_SECRET, Client Secret ou URL do banco. A consulta tem limite de cinco segundos e, se falhar, libera o modo convidado.
6. Sem Client ID válido em nenhuma das fontes, o login Google fica indisponível e “Jogar como convidado” continua funcionando. Depois de configurar o serviço, recarregue a página.

`main.jsx` passa ao GoogleOAuthProvider o ID validado após essa leitura; `App.jsx` usa a mesma fonte para decidir renderizar GoogleLogin. Isso evita checar duas configurações diferentes. Para diagnosticar sem abrir credenciais, consulte `/api/public-config`: `googleClientId` deve estar preenchido e `accountsEnabled` deve ser true para a conta global. Não imprima tokens ou segredos no console.


### Client ID Google incluído
Client ID público em shared/oauth-config.js; variáveis de ambiente têm prioridade. Autorize a origem JavaScript https://boardhub-wr54.onrender.com no Google Cloud. Configure DATABASE_URL, JWT_SECRET e FRONTEND_ORIGIN no Render para contas persistentes. Client ID sozinho não habilita banco de dados. Reenvie este ZIP e faça deploy. Nenhum segredo OAuth está incluído.


## 8.0 — Ludo em 3D real (revisão do bloco 28)
A decisão anterior de remover Three foi substituída pelo pedido explícito de visual 3D. O Ludo agora carrega React Three Fiber/Drei/Three sob demanda: moldura arredondada de madeira, casas elevadas, bases com cavidades visuais, peões sólidos, estrelas extrudadas nas coordenadas compartilhadas e dado branco clicável. A câmera em perspectiva ajusta o enquadramento. HUD HTML ancorada nos quatro cantos, turno central e poderes em pílulas com contador e animação após confirmação do servidor. Botão Rolar dado incluído como fallback conforme bloco 28.
O dado usa animação controlada, não física Rapier; o resultado continua autoritativo. Jogadas e inventários continuam validados no servidor. Dispositivos sem WebGL2 mantêm a mesa 2.5D acessível. Os outros jogos permanecem como na versão anterior; esta alteração aplica 3D ao Ludo.
Dependências externas npm: three, @react-three/fiber, @react-three/drei. A cena é importada dinamicamente. Build e testes de lógica não equivalem a inspeção visual em GPU; validar aparência em dispositivo com WebGL2 após deploy.


## 8.1 — Blocos 29–30 (substitui regras anteriores conflitantes)
- Tema claro #f8fafc, textos azul escuro #1e3a8a, ações roxas #7e22ce. HUD absoluta com avatares nos quatro cantos a 16px, turno e placar central; sem cabeçalho separado no Ludo. Barra de poderes fixa no rodapé com botão Rolar dado acima; clique direto no dado mantido.
- Matriz imutável 15x15 em client/public/ludo-grid.js, tipos 0–5 e estrelas exatas. Peões, estrela e dado seguem sendo malhas 3D. Bases usam cavidade visual escura.
- Canvas demand, duas luzes (ambiente/direcional), sombras desativadas, DPR limitado e geometria reduzida. Invalidação é solicitada enquanto dado/peças animam e para mudanças de estado. Nenhuma física é executada no servidor; dado usa animação controlada. Fallback 2.5D se WebGL2 indisponível.
- flow.visualState usa IDLE, ROLLING e MOVING; estados detalhados internos continuam separados para validar jogadas. Sem movimentos: mensagem por 1500ms e avanço automático; nenhum botão passar/pular.
- Poderes exclusivamente temporários: todos os modos iniciam com inventário vazio, coletam casas especiais durante a partida, zeram na vitória/derrota/desistência e revanche. Reconectar dentro dos 60s preserva a partida, sem transferir poderes para outra. Nenhuma tabela de perfil guarda inventário de poderes; apenas contagens de uso para conquistas continuam persistidas.
- Jogar Sozinho (vs Bots) aceita apostas na conta Google para todos os motores de sala. Os bots são criados pelo servidor e contribuem virtualmente para o pote, sem contas ou carteiras no banco. Exemplo: 10 contra três bots = débito 10; vitória credita 40 (lucro 30), derrota não credita, empate devolve 10. Partidas contra bots não alteram ELO. Capturas seguem a regra vigente de +10 Foticas em partidas apostadas. Treino gratuito continua disponível.
- Apostas globais precisam de conexão com servidor e PostgreSQL: não se aceitam resultados de partidas offline enviados pelo cliente. Saldo/pote/histórico persistem na conta. Desistir perde a aposta; cancelamento do servidor devolve apenas entradas humanas, sem subsidiar bots.
- Economia validada com testes de política e serviço com banco simulado (débito/prêmio idempotentes, empate, derrota, cancelamento, saldo insuficiente e nenhum ELO contra bots). A transação real do PostgreSQL e o visual em GPU devem ser conferidos na implantação. Não foi publicado automaticamente.
Deploy: manter DATABASE_URL, JWT_SECRET e FRONTEND_ORIGIN existentes. Não precisa recriar banco ou trocar credenciais. Build: unzip -o HIPERFOQUITICOS-UNICO.zip && npm ci --include=dev && npm run build; Start: npm start.


## 8.1.1 — Tela branca e estrelas conforme referência enviada
Erro reproduzido no site publicado ao iniciar Damas: Cannot set properties of null (setting hidden). O renderizador antigo exigia um botão global undoPath ausente na interface React. Agora recebe o controle por referência opcional, com botões Cancelar seleção e Girar tabuleiro na sala. Nenhum renderizador depende desse elemento existir globalmente.
Adicionada barreira de erro global com recuperação por recarregar/vitrine/compatibilidade, conteúdo inicial HTML para falhas ao carregar scripts, e no-store no HTML das rotas. Erros ao entrar na sala também liberam os botões e exibem mensagem.
Teste de montagem React em DOM simulado abre todas as seis mesas com estados reais dos motores e verifica casas/cartas/peças, incluindo seleção em Damas sem undoPath. Isso complementa testes de servidor e não substitui conferência visual de WebGL no dispositivo.
Coordenadas finais das estrelas (x=coluna, y=linha, 0–14), conforme imagem enviada: vermelha (6,2), verde (12,6), azul (2,8), amarela (8,12). Substituem coordenadas anteriores conflitantes. Casas de partida mantidas: vermelha (1,6), verde (8,1), azul (6,13), amarela (13,8). Mapa compartilhado atualiza renderizadores 2D/3D, proteção e sorteio de poderes.
Multiplayer continua pela mesma sala/código/link: cada amigo pode estar em local/aparelho diferente. No Ludo, duplas ficam em cantos opostos.


## 8.2 — Loja ampliada
30 estilos de dados, 36 opções de avatar (35 retratos SVG originais + foto/padrão Google) e as cinco molduras anteriores. Novas coleções de animais, fantasia, robôs e exploração espacial; dados com acabamentos lavanda, oceano, metal, galáxia, aurora, cristais, lava, sakura e outros. Busca por nome, raridade e prévias de cada item na vitrine.
IDs/preços antigos preservados, sem migração de banco ou perda de compras. Novos itens seguem a mesma compra permanente e validação autoritativa de saldo/posse. Avatares equipados aparecem no perfil, lobby e salas; o dado equipado altera material, textura e pintas no Ludo 3D, além das versões 2D. Ilustrações SVG e texturas procedurais incluídas, sem dependência de APIs externas de imagem.
Deploy pelo mesmo ZIP e comandos existentes. Não é necessário recriar banco ou alterar variáveis de ambiente.


## 8.3 — Diretrizes 31–34 consolidadas
As regras abaixo substituem os trechos históricos conflitantes.

### Ludo (blocos 31–33)
- Câmera ortográfica quase vertical, posição (0,15,1.5), sem rotação pelo usuário, ajuste de zoom ao tamanho da tela. Inclinação mínima segue a referência mais recente (Bloco 33); tabuleiro ocupa cerca de 86% da área quadrada. Casas claras, borda de madeira clara, bases com interior rebaixado visualmente e pinos sólidos.
- Nome e nível real da conta dentro da base via Html do Drei; bots são identificados como bots, sem simular níveis de humanos. HUD dos avatares nas extremidades, turno/placar no centro. Navegação superior: sair, ranking, missões reais e Foticas.
- Poderes LIGADOS por padrão em solo/bots, amigos, treino e apostas do Ludo. Toggle explícito desliga e seleciona clássico. Modo Extra continua disponível; todos começam sem inventário. Nunca se transfere inventário de poderes entre partidas ou para perfil/banco.
- Três powerDrops autoritativos ativos no caminho, sem estrelas, saídas seguras ou casas +1. Coleta exige parada exata, remove o item, incrementa inventário ilimitado e repõe imediatamente em outro espaço vazio. Ícones diferenciados de poções, escudo e dado; animação de surgimento/coleta e brilho CSS pulsante sem renderização WebGL contínua ociosa.
- Três casas +1 sorteadas ao iniciar e fixas durante a partida com poderes: avançam a peça uma casa adicional (não geram Foticas diretamente), apenas uma vez por movimento, inclusive se a próxima casa também tiver +1. Captura e coleta ocorrem no destino final efetivo; chegada mantém regra do dado exato. Servidor ignora tentativas do cliente de escolher o bônus ou o destino efetivo.
- Setas nas saídas, estrelas conforme imagem anterior já corrigida. Barra inferior circular com contadores e sinal + quando houver unidades, botões esmaecidos sem estoque; botão roxo central Rolar dado e clique direto no dado. Emoji/Chat no canto inferior esquerdo. O chat continua apenas entre membros da mesma sala.
- Duas luzes, nenhuma sombra computada/física de servidor, Canvas demand e queda para 2.5D em aparelhos sem WebGL2. Aparência em GPU precisa ser conferida no aparelho após deploy.

### Lobby (Bloco 34)
- Gradiente externo #1a0b2e → #0f172a, textos claros, cards glass escuros compactos. Duas colunas em telas pequenas, três a partir de 720px e quatro a partir de 1120px; altura máxima 280px.
- Seis artes SVG estáticas próprias, cada uma correspondente ao jogo, sem cenas WebGL/canvas dentro dos cards e sem as antigas caixas CSS marrons. Artes incluídas em client/public/previews; sem downloads de imagens de terceiros.
- Título branco, chat roxo, arte central, avatar/nickname real (EZ_LINE como rótulo de convidado), vitórias e capacidade/entrada gratuita. Apostar é escolhido na configuração da sala.
- Indicadores extras de atividade usam /api/lobby/activity com dados reais apenas de salas públicas de matchmaking; nunca inventam jogadores ou expõem códigos, tokens, conversas, fotos ou participantes de salas privadas por convite.

Mantém conta Google, compras anteriores, loja expandida, multiplayer à distância, apostas virtuais contra bots e correção da tela branca. Mesmo ZIP/variáveis/Start Command; não é necessário recriar o banco.


## 8.3.1 — Dois poderes de cada tipo e +1 com respawn
Substitui a quantidade anterior de três poderes aleatórios. Agora são oito itens no caminho: dois Escudos, dois Duplos, dois Escolher Dado e dois Bônus. Ao coletar, o servidor repõe o mesmo tipo em outra casa livre, mantendo duas unidades de cada tipo. Isso não concede poderes iniciais: o inventário de cada jogador continua vazio no começo e ilimitado após coletar.
As três casas +1 também são consumidas quando acionadas e reaparecem imediatamente em outra posição aleatória, sem estrelas, partidas seguras, peões, poderes ou outros +1. O avanço extra continua sendo de uma casa e não encadeia outro +1 na mesma jogada. Todos os clientes recebem as mesmas posições autoritativas. Clássico explicitamente desligado mantém o tabuleiro sem poderes e sem +1.


## 8.4 — Revisão das outras cinco mesas
Todas as regras, salas, apostas e validação do servidor permanecem nos motores existentes. O Ludo mantém a versão anterior com 2 itens de cada poder e +1 que reaparece; o lobby mantém cards estáticos compactos e tema escuro.

- Estrutura comum das cinco mesas: avatares equipados, indicador de vez, placar de vitórias por participante, partida atual, regras acessíveis e pote/treino. Chat em coluna lateral no desktop e abaixo do tabuleiro em telas menores; botões de convite e saída continuam disponíveis.
- Jogo da Velha: tabuleiro ampliado, X azul/O vermelho com relevo visual, linha vencedora destacada. Dado removido desta mesa porque não faz parte da regra, inclusive na interface solo local antiga.
- Damas: discos com relevo e anéis, coroação distinguida por coroa, tabuleiro de madeira discreta, origem/destino/último lance claros, cancelar seleção e girar. Controles por teclado preservados.
- Xadrez: 12 imagens SVG próprias para seis tipos de peças em duas cores, sem depender de fontes de símbolos. Último lance e rei em xeque destacados, histórico compacto e foco preservado na seleção, setas de navegação. Roque/en passant/promoção continuam validados por chess.js no servidor.
- UNO: mesa de feltro, monte clicável com quantidade, carta descartada central, costas das mãos rivais com contagem pública, mão do jogador horizontal com rolagem, cartas especiais e seletor de cor legíveis. Checkbox de anúncio UNO permanece marcado entre atualizações. Apenas a mão autorizada é renderizada.
- Batalha Naval: painéis separados para os dois oceanos, legenda água/acerto/afundado e progresso dos cinco navios na preparação; foco e navegação por setas. A frota do adversário nunca é renderizada.
- Casas 8x8 mantêm mínimo de 44px; grades maiores podem rolar horizontalmente em telas estreitas para preservar alvos de toque.

Novos estilos isolados em client3d/src/styles/tables.css; peças vetoriais em client/public/pieces. Sem novas dependências de execução. Testes de interação dos renderizadores: UNO envia ações válidas e mantém anúncio, Xadrez seleciona/move preservando foco, Naval posiciona e confirma frota e atira sem revelar oponente. Build concluído e 121 testes passaram. A revisão de aparência no dispositivo publicado continua necessária; nenhuma publicação automática foi realizada.


## 8.4.1 — Ângulo dos peões e barra inferior sem sobreposição
Câmera ortográfica em (0,18,9), com inclinação de aproximadamente 27 graus em relação à vertical para mostrar corpo e base dos pinos, conforme ajuste pedido após a captura. Não há controles de câmera livres. Botão Rolar dado e poderes passam a uma área própria abaixo da mesa, no fluxo da página; não cobrem mais a base amarela. Emoji/chat também ficam no fluxo. Regras, dois itens de cada poder, respawn e partidas existentes preservados. Esta revisão ajusta o visual implementado; a imagem ilustrativa não é uma captura pixel a pixel do projeto.


## 8.4.2 — Enquadramento e novas artes do lobby
O limite da mesa agora considera a altura disponível da janela (100dvh), preservando um mínimo de leitura e deixando controles abaixo da mesa em fluxo normal. Poderes do caminho e da barra recebem ícones SVG distintos e nomes acessíveis, com explicação de que o inventário começa em zero e cada tipo tem duas casas para coletar.
As artes simples dos cards foram substituídas por uma coleção ilustrativa de seis renderizações estáticas geradas, incluída em client/public/previews/table-collection.png. Janelas SVG exibem cada arte sem editar/cortar o arquivo original. Essas imagens decorativas são ilustrações, não capturas dos tabuleiros reais nem definição das regras/posições. Lógica do jogo segue independente das artes.


## 9.0 — Interface Premium refeita conforme as últimas diretrizes
Esta seção prevalece sobre os layouts/quantidades históricos acima. A interface de Ludo foi substituída por PremiumLudo.jsx e premium.css; a lógica de contas, compras, economia, salas, bots e os cinco outros jogos permanece preservada.

- Tema único #1a0b2e → #2d1457 → #0f172a; painéis escuros translúcidos, bordas brancas suaves e desfoque. Sem barra branca e sem navegação superior no Ludo.
- Câmera ortográfica exatamente (0,15,0), mirando o centro, enquadramento de cerca de 80% do canvas. Moldura espessa âmbar #b45309 com friso #fbbf24, bases plásticas com interior escuro, caminho claro e estrelas douradas. Pinos têm leve inclinação local estilizada para preservar leitura do corpo sem alterar a câmera vertical.
- Avatares nos cantos com aro de 3px na cor correspondente, nome/nível abaixo, brilho pulsante na vez e opacidade 70% nos demais. Controles e mesa cabem em uma composição com linhas reservadas, sem botão sobre bases.
- Dado padrão branco no centro com pintas em relevo, brilho no hover, clique direto e botão Rolar dado. Movimento visual usa gravidade/colisão e amortecimento somente no navegador; resultado e turno são definidos pelo servidor. A física não determina o resultado. Skins equipadas continuam válidas.
- Barra de vidro escuro com exatamente quatro controles circulares e contadores, apagados sem estoque. Ícones IGUAIS no caminho e na HUD: Duplo=dois dados; Escolher=dado com marcador; Proteção=escudo; Bônus=+1 azul (última correção da usuária). +1 no ícone de Bônus significa uma rolagem extra; as casas douradas +1 continuam avançando uma casa.
- A última especificação textual pede TRÊS poderes ativos simultaneamente: substitui a regra anterior de oito/dois de cada. Três tipos distintos são sorteados entre os quatro; coleta repõe imediatamente em casa vazia, sem estrelas/saídas/+1/peças. Inventário ilimitado durante a partida e descartado ao finalizar. Três casas douradas +1 continuam com respawn. Clássico só quando explicitamente desligado.
- Lobby em três colunas desktop (duas no celular), artes estáticas ilustrativas geradas e incluídas no projeto, identidade/avatar/Foticas no header, convite e chat da sala. As artes não são capturas do jogo nem alteram o mapeamento do tabuleiro.
- Loja ampliada: 50 estilos de dado, 60 opções de avatar (inclui Google/padrão) e 20 molduras. Novos retratos incluem variações de trajes/paleta dos personagens; molduras têm aparência própria no perfil e no Ludo. IDs/preços antigos preservados; sem migração de banco.
- Testes adicionais para física visual e orientação das seis faces, além da montagem da nova interface, quatro controles e ícone +1. Conferência visual em dispositivo com WebGL2 ainda é necessária; não houve deploy automático.

Mesmo nome de ZIP e comandos de build/start. Mantenha as variáveis já configuradas no Render; não recrie o banco.


## 9.0.1 — Recorte isolado das artes dos cards
Corrigido o vazamento das imagens vizinhas no lobby. O viewBox sozinho não corta as margens adicionais de um SVG largo com preserveAspectRatio=meet; agora cada imagem tem clipPath próprio em coordenadas do sprite, além de overflow hidden. A janela mantém um jogo por card sem deformar a arte. Ajustados largura máxima da vitrine, altura da arte e espaçamento dos rodapés. O teste de montagem verifica os seis recortes e suas referências; regras, conta, compras, loja e Ludo permanecem inalterados.


## 9.1 — Mesa maior, rolagem direta e casas de base marcadas
Último ajuste após captura: câmera continua vertical, mas a mesa passa de cerca de 80% para 91% da área do canvas e a área de ações diminui. Botão HTML Rolar dado removido; dado central continua clicável e a área da mesa aceita Enter/Espaço durante o turno para acessibilidade. Fundo WebGL transparente, sem retângulo branco ao redor.
Cada base tem quatro encaixes circulares com preenchimento claro e anel contrastante, visíveis com ou sem peões. Removidos nomes duplicados dentro do canvas; apenas a tag de cada avatar permanece. Nomes de bots foram abreviados visualmente sem alterar identificadores ou nomes da sala.
Poderes aumentados novamente conforme pedido mais recente: oito itens, dois de cada tipo (Escudo, Duplo, Escolher e Bônus), com reposição do mesmo tipo; três casas +1 com respawn preservadas. Isso substitui a quantidade anterior de três poderes. Compras e regras restantes preservadas.

Poderes no caminho foram reduzidos para aproximadamente 0,63 casa por ícone, com escala vinculada ao mundo 3D para não crescerem conforme a largura da janela. Após o último ajuste, as casas douradas +1 também têm ícone reduzido: cerca de dois terços da casa, assim como os outros poderes, mantendo borda livre ao redor. A apresentação do dado recebeu inclinação própria para mostrar laterais e profundidade; a câmera do tabuleiro permanece vertical. A face sorteada continua legível e validada pelo servidor.


### Referência final de quantidade e bases
Conforme a última imagem enviada: seis ícones de poder e quatro casas +1. Todos os quatro tipos de poder ficam representados (uma ou duas cópias por tipo), com respawn aleatório sem sobreposição. Esta quantidade prevalece sobre a regra anterior de oito itens. As bases exibem quatro círculos escuros permanentes: ao mover um peão para o caminho, o encaixe vazio permanece visível, inclusive no fallback acessível. Os ícones de poderes e +1 ocupam aproximadamente dois terços da casa. O dado tem inclinação própria e o tabuleiro permanece vertical, sem botão HTML de rolagem.
