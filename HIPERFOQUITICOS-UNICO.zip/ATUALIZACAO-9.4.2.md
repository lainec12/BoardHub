# 9.4.2 — acabamento da Loja Hiperfoquítica

Título e descrição da loja usam a cor de texto da paleta equipada, preservando contraste nos temas claros e escuros. Conteúdo da 9.4.1 e recuperação restrita da migração mantidos.
