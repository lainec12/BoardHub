import {BrowserRouter,Routes,Route,Navigate,useSearchParams} from 'react-router-dom';import RoomPage from './rooms/RoomPage.jsx';
import {GoogleOAuthProvider} from '@react-oauth/google';
import React from 'react';import {createRoot} from 'react-dom/client';import App from './App.jsx';import './styles/app.css';
function GameRoute(){const [query]=useSearchParams();return query.get('solo')==='1'?<App/>:<RoomPage/>;}
const routed=<BrowserRouter><Routes><Route path="/" element={<App/>}/><Route path="/lobby" element={<App/>}/><Route path="/profile" element={<App/>}/><Route path="/shop" element={<App/>}/><Route path="/room/:gameId" element={<RoomPage/>}/><Route path="/game/:gameId" element={<GameRoute/>}/><Route path="/3d/*" element={<Navigate to="/lobby" replace/>}/></Routes></BrowserRouter>;
createRoot(document.getElementById('root')).render(import.meta.env.VITE_GOOGLE_CLIENT_ID?<GoogleOAuthProvider clientId={import.meta.env.VITE_GOOGLE_CLIENT_ID}>{routed}</GoogleOAuthProvider>:routed);
