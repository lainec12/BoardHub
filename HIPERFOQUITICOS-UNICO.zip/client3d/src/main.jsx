import UIThemeSync from './components/UIThemeSync.jsx';
import {getGoogleClientId,loadAuthConfig} from './services/authConfig.js';
import {BrowserRouter,Routes,Route,Navigate,useSearchParams} from 'react-router-dom';import RoomPage from './rooms/RoomPage.jsx';
import {GoogleOAuthProvider} from '@react-oauth/google';
import React from 'react';import {createRoot} from 'react-dom/client';import App from './App.jsx';import AppBoundary from './components/AppBoundary.jsx';import './styles/app.css';
function GameRoute(){const [query]=useSearchParams();return query.get('solo')==='1'?<App/>:<RoomPage/>;}
const routed=<BrowserRouter><UIThemeSync/><AppBoundary><Routes><Route path="/" element={<App/>}/><Route path="/lobby" element={<App/>}/><Route path="/profile" element={<App/>}/><Route path="/shop" element={<App/>}/><Route path="/room/:gameId" element={<RoomPage/>}/><Route path="/game/:gameId" element={<GameRoute/>}/><Route path="/3d/*" element={<Navigate to="/lobby" replace/>}/></Routes></AppBoundary></BrowserRouter>;
function Bootstrap(){const [ready,setReady]=React.useState(false),[clientId,setClientId]=React.useState(getGoogleClientId);React.useEffect(()=>{let live=true;loadAuthConfig().then(id=>{if(live){setClientId(id);setReady(true);}});return()=>{live=false;};},[]);if(!ready)return <main><p role="status">Preparando acesso…</p></main>;return clientId?<GoogleOAuthProvider clientId={clientId}>{routed}</GoogleOAuthProvider>:routed;}
createRoot(document.getElementById('root')).render(<Bootstrap/>);

import './styles/hiperfoco.css';
import './styles/tables.css';
import './styles/premium.css';
