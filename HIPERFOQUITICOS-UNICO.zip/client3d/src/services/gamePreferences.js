import {useSyncExternalStore} from 'react';
let cached;const defaults={detail:'auto',theme:'royal',uiTheme:'theme-midnight',muteReactions:false};const listeners=new Set();
export function gamePreferences(){if(!cached){try{cached={...defaults,...JSON.parse(localStorage.getItem('hiper:preferences:v1'))};}catch{cached={...defaults};}}return cached;}
export function setGamePreferences(patch){cached={...gamePreferences(),...patch};try{localStorage.setItem('hiper:preferences:v1',JSON.stringify(cached));}catch{}listeners.forEach(fn=>fn());}
export const useGamePreferences=()=>useSyncExternalStore(fn=>{listeners.add(fn);return()=>listeners.delete(fn);},gamePreferences,gamePreferences);
export function isLowDetail(p=gamePreferences()){if(p.detail==='low')return true;if(p.detail==='high')return false;return typeof navigator!=='undefined'&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))||typeof matchMedia!=='undefined'&&matchMedia('(prefers-reduced-motion: reduce)').matches;}
export const BOARD_THEMES={royal:{name:'Dourado suave',rim:'#dfb968',wood:'#926237'},silver:{name:'Prata lunar',rim:'#cbd5e1',wood:'#475569'},violet:{name:'Violeta',rim:'#b79af2',wood:'#4c1d95'}};
