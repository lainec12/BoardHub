const valid=value=>typeof value==='string'&&/^[a-zA-Z0-9._-]+\.apps\.googleusercontent\.com$/.test(value.trim())?value.trim():'';
let clientId=valid(import.meta.env.VITE_GOOGLE_CLIENT_ID),request;
export const getGoogleClientId=()=>clientId;
// Client ID é público. Este endpoint nunca entrega Client Secret, JWT_SECRET ou DATABASE_URL.
export function loadAuthConfig(){if(!request)request=fetch('/api/public-config',{signal:AbortSignal.timeout(5000)}).then(r=>r.ok?r.json():{}).then(config=>{clientId=clientId||valid(config.googleClientId);return clientId;}).catch(()=>clientId);return request;}
