import {sanitizeProfile,emptyProfile} from '../metagame/model.js';
const KEY='hiperfoquiticos:r3f:profile:v1';
// Troque apenas este adaptador por fetch('/api/profile') na futura integração Prisma.
export const profileRepository={load(){try{return sanitizeProfile(JSON.parse(localStorage.getItem(KEY)));}catch{return emptyProfile();}},save(profile){try{localStorage.setItem(KEY,JSON.stringify(profile));return true;}catch{return false;}}};
