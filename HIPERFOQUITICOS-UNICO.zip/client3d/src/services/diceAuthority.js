import {api,tokenStore} from './api.js';
// Adaptador LOCAL. No multiplayer, substituir por ACK do Socket.io que já retorna o dado.
export async function requestRoll(){if(tokenStore.get())return (await api('/dice',{})).value;const a=new Uint32Array(1),limit=4294967292;do{crypto.getRandomValues(a);}while(a[0]>=limit);return 1+a[0]%6;}
