// Nitidez e complexidade são independentes: poucos núcleos não tornam a tela Retina 1x.
export function boardQuality({detail='auto',pixelRatio=1}={}){
 const ratio=Number.isFinite(pixelRatio)&&pixelRatio>0?pixelRatio:1;
 const dpr=Math.min(Math.max(1,ratio),detail==='low'?1.5:detail==='high'?3:2);
 return {dpr,minDpr:Math.min(dpr,1.5),adaptive:detail!=='high',antialias:true};
}
