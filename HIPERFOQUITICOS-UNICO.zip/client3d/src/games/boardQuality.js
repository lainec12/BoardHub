// Densidade real da tela, com teto de custo: não muda câmera, layout ou regras.
export function boardQuality({detail='auto',low=false,pixelRatio=1}={}){const ratio=Number.isFinite(pixelRatio)&&pixelRatio>0?pixelRatio:1;return {dpr:Math.min(Math.max(1,ratio),low?1:detail==='high'?2.5:2),antialias:true};}
