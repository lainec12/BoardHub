// Física leve somente no navegador: gravidade + colisão elástica com a mesa.
// A trajetória visual nunca determina o valor; esse resultado vem do servidor.
export const DICE_FLOOR=.9;
export function newDiceMotion(){return {height:DICE_FLOOR,velocity:5.7,elapsed:0};}
export function stepDiceMotion(state,seconds){const dt=Math.max(0,Math.min(seconds,.04));let velocity=state.velocity-18*dt,height=state.height+velocity*dt;if(height<DICE_FLOOR){height=DICE_FLOOR;velocity=Math.abs(velocity)*.36;if(velocity<.25)velocity=0;}return {height,velocity,elapsed:state.elapsed+dt};}

export const DICE_FACE_ROTATIONS={1:[0,0,0],6:[Math.PI,0,0],2:[-Math.PI/2,0,0],5:[Math.PI/2,0,0],3:[0,0,Math.PI/2],4:[0,0,-Math.PI/2]};
export const LUDO_CAMERA_POSITION=[0,15,0];
