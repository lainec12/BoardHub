// Centros simétricos em relação a cada base 6×6, independentes da câmera.
export const LUDO_BASES={red:[[1.5,1.5],[1.5,3.5],[3.5,1.5],[3.5,3.5]],green:[[1.5,10.5],[1.5,12.5],[3.5,10.5],[3.5,12.5]],blue:[[10.5,1.5],[10.5,3.5],[12.5,1.5],[12.5,3.5]],yellow:[[10.5,10.5],[10.5,12.5],[12.5,10.5],[12.5,12.5]]};
export const BASE_CENTERS={red:[2.5,2.5],green:[2.5,11.5],blue:[11.5,2.5],yellow:[11.5,11.5]};
export const safeRadius=(args,radius)=>Math.max(.001,Math.min(radius,Math.min(...args)/2-.001));
