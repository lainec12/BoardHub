const steps={blue:0,red:1,green:2,yellow:3};
export const viewSteps=me=>steps[me]??0;
export function viewCorner(color,me){const corners=['red','green','yellow','blue'];return corners[(corners.indexOf(color)-viewSteps(me)+4)%4];}
export function cameraUp(me){return [[0,0,-1],[1,0,0],[0,0,1],[-1,0,0]][viewSteps(me)];}
export function moverColor(game){const actor=game.players[game.turnIndex];if(!actor?.tokens.every(v=>v===57))return actor?.color;const team=game.teams?.find(t=>t.includes(actor.color));return game.players.find(p=>team?.includes(p.color)&&!p.tokens.every(v=>v===57))?.color||actor.color;}

export function cameraPosition(me){return [[0,15,9],[-9,15,0],[0,15,-9],[9,15,0]][viewSteps(me)];}
