import {LatheGeometry,SphereGeometry,TorusGeometry,Vector2} from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
// Mesma silhueta, centros e inclinação: corpo/cabeça/anel em um buffer compartilhado.
export function createPawnGeometry(){
 const profile=[[0,0],[.26,0],[.34,.05],[.35,.11],[.3,.17],[.23,.2],[.2,.3],[.15,.47],[.14,.57],[0,.59]].map(([x,y])=>new Vector2(x,y));
 const parts=[new LatheGeometry(profile,32).translate(0,.03,0),new SphereGeometry(.235,28,18).translate(0,.72,0),new TorusGeometry(.28,.025,8,32).rotateX(Math.PI/2).translate(0,.19,0)];
 const geometry=mergeGeometries(parts,false);parts.forEach(p=>p.dispose());geometry.computeBoundingBox();geometry.computeBoundingSphere();return geometry;
}
