// Ajuste local e conservador: nunca muda câmera, casas ou regras da sala.
// Não mede quadros isolados do modo demand nem o tempo com a aba oculta.
export function createFrameBudget(targetDpr=1){
 let dpr=targetDpr,frames=0,seconds=0;
 const reset=()=>{frames=0;seconds=0;};
 return {reset,sample(dt){
  if(!Number.isFinite(dt)||dt<=0||dt>.25){reset();return null;}
  frames++;seconds+=dt;
  if(frames<24||seconds<1.2)return null;
  const fps=frames/seconds;reset();
  if(fps>=38||dpr<=1)return null;
  dpr=Math.max(1,Math.round((dpr-.25)*100)/100);
  return dpr;
 }};
}
