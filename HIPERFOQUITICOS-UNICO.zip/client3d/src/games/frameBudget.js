// Ajuste local e conservador: nunca muda câmera, casas ou regras da sala.
// Não mede quadros isolados do modo demand nem o tempo com a aba oculta.
export function createFrameBudget(targetDpr=1,{minDpr=Math.min(targetDpr,1.5),adaptive=true}={}){
 let dpr=targetDpr,frames=0,seconds=0;
 const reset=()=>{frames=0;seconds=0;};
 return {reset,restore(){const changed=dpr!==targetDpr;dpr=targetDpr;reset();return changed?dpr:null;},sample(dt){
  if(!Number.isFinite(dt)||dt<=0||dt>.25){reset();return null;}
  frames++;seconds+=dt;
  if(frames<24||seconds<1.2)return null;
  const fps=frames/seconds;reset();
  if(!adaptive||fps>=38||dpr<=minDpr)return null;
  dpr=Math.max(minDpr,Math.round((dpr-.25)*100)/100);
  return dpr;
 }};
}
