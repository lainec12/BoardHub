export const DIFFICULTIES=['easy','medium','hard'];
export const LINES=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
export function result(board){for(const line of LINES)if(board[line[0]]&&line.every(i=>board[i]===board[line[0]]))return board[line[0]];return board.every(Boolean)?'draw':null;}
export const legal=board=>board.flatMap((v,i)=>v?[]:[i]);
function minimax(board,turn,depth=0){const r=result(board);if(r)return r==='O'?10-depth:r==='X'?depth-10:0;const scores=legal(board).map(i=>{const next=[...board];next[i]=turn;return minimax(next,turn==='O'?'X':'O',depth+1);});return turn==='O'?Math.max(...scores):Math.min(...scores);}
export function chooseMove(board,difficulty='hard',random=Math.random){if(!DIFFICULTIES.includes(difficulty))throw Error('Dificuldade inválida');if(result(board))return null;const moves=legal(board);if(difficulty==='easy')return moves[Math.min(moves.length-1,Math.floor(random()*moves.length))];
 const winning=mark=>moves.find(i=>{const next=[...board];next[i]=mark;return result(next)===mark;});
 const win=winning('O');if(win!==undefined)return win;const block=winning('X');if(block!==undefined)return block;
 if(difficulty==='medium')return moves[Math.min(moves.length-1,Math.floor(random()*moves.length))];
 let best=-Infinity,choice=moves[0];for(const i of moves){const next=[...board];next[i]='O';const score=minimax(next,'X');if(score>best){best=score;choice=i;}}return choice;
}
