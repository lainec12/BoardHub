// Ilustrações vetoriais próprias. Sem fontes externas ou imagens de terceiros.
export function animalSvg(a){const k=a.key,c=a.color,e=a.accent;let behind='',details='',face=`<ellipse cx="32" cy="44" rx="24" ry="23" fill="${c}" stroke="${e}" stroke-width="2"/>`;
const ellipse=(x,y,rx,ry,fill)=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${fill}"/>`;
if(a.ears==='long')behind=`${ellipse(21,17,7,16,c)}${ellipse(43,17,7,16,c)}<path d="M21 7v19M43 7v19" stroke="#f9a8d4" stroke-width="5"/>`;
else if(a.ears==='point'||a.ears==='horn')behind=`<path d="M9 33 8 8 27 26M37 26 56 8 55 33" fill="${c}" stroke="${e}" stroke-width="2"/>`;
else if(a.ears==='round'||a.ears==='floppy')behind=ellipse(12,28,k==='mouse'||k==='koala'?12:9,a.ears==='floppy'?19:10,e)+ellipse(52,28,k==='mouse'||k==='koala'?12:9,a.ears==='floppy'?19:10,e);
else if(a.ears==='tiny')behind=ellipse(17,26,5,6,e)+ellipse(47,26,5,6,e);
if(k==='lion'){behind=`<path d="M32 8 38 16 49 12 50 23 61 27 55 37 61 47 50 52 49 63 38 61 32 71 26 61 15 63 14 52 3 47 9 37 3 27 14 23 15 12 26 16Z" fill="${e}"/>`;}
if(a.ears==='spike')behind=`<path d="M4 47 1 37 9 33 6 23 17 24 18 12 28 17 34 7 40 18 52 14 52 27 63 32 58 43 63 52 49 61 18 63Z" fill="${e}"/>`;
if(a.ears==='gills')behind=`<path d="m15 33-12-8m12 13L1 38m14 6L3 51m46-18 12-8m-12 13 14 0m-14 6 12 7" stroke="${e}" stroke-width="5" stroke-linecap="round"/>`;
if(a.ears==='antler')behind=`<path d="M19 32 15 9m1 10L6 12m10 7 7-12m22 25 4-23m-1 10 10-7m-10 7-7-12" stroke="${e}" stroke-width="4" stroke-linecap="round"/>`;
if(a.ears==='wool')behind=Array.from({length:10},(_,i)=>{const r=i*Math.PI/5;return ellipse(32+22*Math.cos(r),40+22*Math.sin(r),10,10,'#fff');}).join('');
if(a.ears==='wing')behind=k==='bat'?`<path d="M15 33 2 18 2 50 8 44 13 54 21 48m28-15 13-15 0 32-6-6-5 10-8-6" fill="${e}"/>`:ellipse(13,27,12,20,'#dbeafe')+ellipse(51,27,12,20,'#fbcfe8');
if(k==='panda'||k==='raccoon')details+=ellipse(22,40,9,10,'#334155')+ellipse(42,40,9,10,'#334155');
if(k==='owl')details+=ellipse(21,40,11,12,'#fff')+ellipse(43,40,11,12,'#fff');
if(['hamster','otter','seal','capybara'].includes(k))details+=ellipse(23,51,10,8,'#fff4df')+ellipse(41,51,10,8,'#fff4df');
if(k==='koala')details+=ellipse(32,48,7,10,'#475569');
if(['pig','cow','capybara'].includes(k))details+=ellipse(32,53,k==='capybara'?16:13,9,k==='cow'?'#fbcfe8':'#f9a8d4')+ellipse(27,53,2,3,e)+ellipse(37,53,2,3,e);
if(k==='cow')details+=`<path d="M12 30q15-12 13 9t-13 1Z" fill="#334155"/>`;
if(k==='tiger')details+=`<path d="m23 24 4 9m14-9-4 9m-5-11v9M9 40l7 3m-7 5 7 1m39-9-7 3m7 5-7 1" stroke="#78350f" stroke-width="3"/>`;
if(k==='bee')details+=`<path d="M12 48h40M17 60h30" stroke="#78350f" stroke-width="6"/><path d="M24 25 19 9m21 16 5-16" stroke="${e}" stroke-width="2"/>`;
if(k==='unicorn')details+=`<path d="m26 27 6-25 6 25Z" fill="#fde68a" stroke="#a855f7"/><path d="m29 15 6 3m-5-10 3 1" stroke="#e879f9"/>`;
if(k==='penguin'){face=`<ellipse cx="32" cy="43" rx="25" ry="26" fill="#172033"/>`;details+=ellipse(32,46,19,20,'#fff');}
if(['penguin','chick','duck','owl'].includes(k))details+=k==='duck'?ellipse(32,53,15,6,'#fb923c'):`<path d="m27 49 5 8 5-8Z" fill="#fb923c"/>`;
const eyes=['panda','raccoon'].includes(k)?'#fff':'#172033';details+=ellipse(22,41,3.2,3.8,eyes)+ellipse(42,41,3.2,3.8,eyes);
if(!['koala','cow','pig','penguin','chick','duck','owl','capybara'].includes(k))details+=`<path d="m28 50 4 4 4-4Z" fill="${e}"/>`;
details+=`<path d="M24 57q8 7 16 0" fill="none" stroke="${e}" stroke-width="1.8" stroke-linecap="round"/>`;
if(['cat','fox','tiger','mouse','seal'].includes(k))details+=`<path d="m4 45 13 3M4 53l13-1m30-4 13-3m-13 7 13 1" stroke="${e}" stroke-width="1.5"/>`;
return `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="72" viewBox="0 0 64 72">${behind}${face}${details}<circle cx="15" cy="49" r="3" fill="#fb7185" opacity=".3"/><circle cx="49" cy="49" r="3" fill="#fb7185" opacity=".3"/></svg>`;}
