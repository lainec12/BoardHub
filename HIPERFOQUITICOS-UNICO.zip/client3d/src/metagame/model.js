import {result} from '../games/tic-tac-toe/engine.js';
import {SKINS,CATALOG} from './catalog.js';export {SKINS};
export const emptyProfile=()=>({version:1,coins:100,owned:['classic'],inventory:[],equipped:'classic',avatar:'google',frame:'none',achievements:[],lastRecoveryDay:null,history:[]});
export function sanitizeProfile(p){const initial=emptyProfile();if(!p||p.version!==1)return initial;const owned=Array.isArray(p.owned)?p.owned.filter(x=>SKINS.some(s=>s.id===x)):['classic'];if(!owned.includes('classic'))owned.unshift('classic');return {...initial,inventory:Array.isArray(p.inventory)?p.inventory.filter(id=>CATALOG.some(x=>x.id===id)):[],avatar:CATALOG.some(x=>x.id===p.avatar&&x.category==='avatar')?p.avatar:'google',frame:CATALOG.some(x=>x.id===p.frame&&x.category==='frame')?p.frame:'none',lastRecoveryDay:typeof p.lastRecoveryDay==='string'?p.lastRecoveryDay:null,version:1,coins:Number.isSafeInteger(p.coins)&&p.coins>=0?p.coins:0,owned,equipped:owned.includes(p.equipped)?p.equipped:'classic',history:Array.isArray(p.history)?p.history.filter(h=>h&&typeof h.id==='string'&&['victory','defeat','draw'].includes(h.result)).slice(0,300):[]};}
export function reducer(state,action){
 if(action.type==='hydrate')return {...state,...action.value};
 if(action.type==='recover'){if(state.profile.coins!==0||state.profile.lastRecoveryDay===action.day)return state;return {...state,profile:{...state.profile,coins:15,lastRecoveryDay:action.day}};}
 if(action.type==='start')return {...state,game:{id:action.id,board:Array(9).fill(null),turn:'X',difficulty:action.difficulty,finished:null}};
 if(action.type==='move'){const g=state.game;if(!g||g.finished||g.turn!==action.mark||!Number.isInteger(action.cell)||action.cell<0||action.cell>8||g.board[action.cell])return state;const board=[...g.board];board[action.cell]=action.mark;const finished=result(board),game={...g,board,finished,turn:g.turn==='X'?'O':'X'};if(!finished)return {...state,game};
 if(state.profile.history.some(h=>h.id===g.id))return {...state,game};
 const outcome=finished==='draw'?'draw':finished==='X'?'victory':'defeat',coins=outcome==='victory'?20:outcome==='draw'?5:-Math.min(10,state.profile.coins);
 return {game,profile:{...state.profile,coins:state.profile.coins+coins,history:[{id:g.id,date:action.date,game:'Jogo da Velha',opponent:'Bot',difficulty:g.difficulty,result:outcome,coins},...state.profile.history].slice(0,300)}};
 }
 if(action.type==='buy'){const item=CATALOG.find(s=>s.id===action.id);if(!item||!item.price||state.profile.inventory.includes(item.id)||state.profile.owned.includes(item.id)||state.profile.coins<item.price)return state;return {...state,profile:{...state.profile,coins:state.profile.coins-item.price,inventory:[...state.profile.inventory,item.id],owned:item.category==='dice'?[...state.profile.owned,item.id]:state.profile.owned}};}
 if(action.type==='equip'){const item=CATALOG.find(i=>i.id===action.id);if(!item||item.price&&!state.profile.inventory.includes(item.id)&&!state.profile.owned.includes(item.id))return state;return {...state,profile:{...state.profile,[{dice:'equipped',avatar:'avatar',frame:'frame'}[item.category]]:item.id}};}
 return state;
}
