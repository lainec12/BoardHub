export function reactionClock(room) {
  return room.serverNow && room.receivedAt != null
    ? room.serverNow + performance.now() - room.receivedAt
    : Date.now();
}

export function reactionStart(message) {
  return message.displayAt ?? message.time;
}

export function reactionEnd(message) {
  const duration = message.kind === 'avatar-effect'
    ? Math.min(message.displayFor ?? 5000, 5000)
    : message.displayFor ?? 7000;
  return reactionStart(message) + duration;
}
