import {create} from 'zustand';import {io} from 'socket.io-client';import {tokenStore} from '../services/api.js';
let socket;const key='hiper:room:v1';const load=()=>{try{return JSON.parse(sessionStorage.getItem(key));}catch{return null;}};
export const useRoom=create((set,get)=>({room:null,credentials:load(),playerId:null,error:'',connected:false,
 async send(event,data={}){if(!socket?.connected){set({error:'Sem conexão. Aguarde.'});return null;}return new Promise(resolve=>socket.timeout(6000).emit(event,data,(err,r)=>{if(err||!r?.ok)set({error:err?'Servidor sem resposta.':r.error});else set({error:''});resolve(err?null:r);}));},
 async enter(data,create=false){set({error:''});if(socket){socket.disconnect();}socket=io({auth:tokenStore.get()?{token:tokenStore.get()}:{},autoConnect:false});socket.on('game:state',room=>set({room}));socket.on('disconnect',()=>set({connected:false}));socket.on('connect_error',e=>set({error:e.message}));socket.on('room:removed',d=>{set({room:null,credentials:null,error:d.reason});try{sessionStorage.removeItem(key);}catch{}});
 let first=true;socket.on('connect',async()=>{set({connected:true});if(!first&&get().credentials){const r=await get().send('room:join',get().credentials);if(r?.ok)set({playerId:r.playerId});}});
 socket.connect();await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('Conexão indisponível')),7000);socket.once('connect',()=>{clearTimeout(t);resolve();});socket.once('connect_error',e=>{clearTimeout(t);reject(e);});}).catch(e=>set({error:e.message}));if(!socket.connected)return;first=false;
 const r=await get().send(create?'room:create':'room:join',data);if(!r?.ok)return;
 const credentials={name:data.name,code:r.code,token:r.token,gameId:get().room?.gameId||data.gameId};try{sessionStorage.setItem(key,JSON.stringify(credentials));}catch{}set({credentials,playerId:r.playerId});return r;
 },async leave(){await get().send('room:leave');socket?.disconnect();try{sessionStorage.removeItem(key);}catch{}set({room:null,credentials:null,playerId:null,connected:false});}
}));
