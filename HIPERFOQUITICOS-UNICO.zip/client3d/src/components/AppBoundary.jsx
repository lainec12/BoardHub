import React from 'react';
// Um erro num renderizador não deve apagar toda a página e impedir a recuperação.
export default class AppBoundary extends React.Component{
 state={failed:false};
 static getDerivedStateFromError(){return {failed:true};}
 componentDidCatch(error){console.error('Falha na interface do jogo:',error.message);}
 render(){return this.state.failed?<main><section className="panel" role="alert"><h1>Não foi possível abrir esta mesa</h1><p>Sua conta permanece salva. Você pode recarregar a página ou abrir a interface de compatibilidade.</p><button onClick={()=>window.location.reload()}>Recarregar jogo</button> <a href="/lobby">Voltar à vitrine</a> · <a href="/legacy">Modo de compatibilidade</a></section></main>:this.props.children;}
}
