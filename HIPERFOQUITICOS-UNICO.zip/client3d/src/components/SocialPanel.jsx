import {badgeName} from '../../../shared/progression.js';
import React,{useEffect,useState} from 'react';import {useNavigate} from 'react-router-dom';import {api,tokenStore} from '../services/api.js';import {useRoom} from '../rooms/store.js';import AvatarPortrait from './AvatarPortrait.jsx';
export default function SocialPanel({profile}){const [data,setData]=useState({friends:[],requests:[],invites:[]}),[id,setId]=useState(''),[note,setNote]=useState(''),[busy,setBusy]=useState(false),[friend,setFriend]=useState(null);const navigate=useNavigate(),room=useRoom(s=>s.room),logged=!!tokenStore.get();const refresh=()=>api('/friends').then(setData).catch(e=>setNote(e.message));useEffect(()=>{if(!logged)return;let live=true;const run=()=>api('/friends').then(d=>{if(live)setData(d);}).catch(e=>{if(live)setNote(e.message);});run();const t=setInterval(()=>{if(!document.hidden)run();},20000);return()=>{live=false;clearInterval(t);};},[logged]);const act=async(path,body)=>{if(busy)return;setBusy(true);try{await api('/friends/'+path,body);setNote('Pronto.');await refresh();}catch(e){setNote(e.message);}finally{setBusy(false);}};const accept=async invite=>{if(room){setNote('Saia da sala atual antes de aceitar outro convite.');return;}setBusy(true);try{const {invite:i}=await api('/friends/invite-answer',{id:invite.id,accept:true}),result=await useRoom.getState().enter({code:i.code,gameId:i.gameId,name:profile?.user?.name||'Jogador'},false);if(!result)throw Error(useRoom.getState().error||'Sala indisponível.');navigate('/room/'+i.gameId);await refresh();}catch(e){setNote(e.message);}finally{setBusy(false);}};
return <section className="panel friends-panel friends-compact">
  {!logged ? <p>Entre com Google para convidar amigos ou use o código da sala.</p> : <>
    {data.friends.length===0 && <p>Adicione seu primeiro amigo pelo ID.</p>}
    {data.friends.length>0 && !room && <p>Crie uma sala com amigos para enviar um convite.</p>}
    {data.friends.map(f=><article key={f.id} className="friend-row">
      <div className="friend-identity"><AvatarPortrait avatar={f.avatar} picture={f.picture}/>
        <span><b>{f.name}</b><small>{f.online?'Online':'Offline'}</small></span></div>
      <button className="friend-invite" disabled={busy||!f.online||!room||room.status!=='waiting'||room.solo}
        onClick={()=>act('invite',{userId:f.id,code:room.code})} aria-label={'Convidar '+f.name}>Convidar</button>
      <details className="friend-more" name="acoes-amigo"><summary aria-label={'Mais opções para '+f.name}>Mais opções</summary>
        <div><button onClick={()=>api('/friends/'+encodeURIComponent(f.id)+'/profile').then(v=>setFriend(v.friend)).catch(e=>setNote(e.message))}>Ver perfil</button>
        <button disabled={busy} onClick={()=>act('remove',{userId:f.id})}>Remover amigo</button></div>
      </details>
    </article>)}
    {friend&&<section className="panel"><AvatarPortrait avatar={friend.avatar} picture={friend.picture}/><h3>{friend.name}</h3><p>Nível {friend.level} · {friend.rank} · {friend.xp} XP</p><p>{friend.badges.map(b=>b.name).join(' · ')||'Vitrine vazia'}</p><p>{friend.achievements.map(badgeName).filter(Boolean).join(' · ')||'Nenhuma conquista'}</p><button onClick={()=>setFriend(null)}>Fechar perfil</button></section>}
    <details className="settings-fold" name="amigos"><summary>Adicionar amigo</summary><div className="fold-body"><p>Seu ID para adicionar: <code>{profile?.user?.id}</code></p><form onSubmit={e=>{e.preventDefault();act('request',{userId:id});}}><input aria-label="ID do amigo" value={id} onChange={e=>setId(e.target.value)} placeholder="Cole o ID da conta do amigo" maxLength={100} required/><button disabled={busy}>Adicionar amigo</button></form></div></details>
    {data.requests.length>0 && <details className="settings-fold" name="amigos"><summary>Pedidos de amizade ({data.requests.length})</summary><div className="fold-body">{data.requests.map(r=><article key={r.id}><b>{r.user.name}</b> · {r.incoming?'Quer ser seu amigo':'Pedido enviado'}{r.incoming&&<><button disabled={busy} onClick={()=>act('answer',{id:r.id,accept:true})}>Aceitar</button><button disabled={busy} onClick={()=>act('answer',{id:r.id,accept:false})}>Recusar</button></>}</article>)}</div></details>}
    {data.invites.length>0 && <details className="settings-fold" name="amigos"><summary>Convites recebidos ({data.invites.length})</summary><div className="fold-body">{data.invites.map(i=><article key={i.id}><b>{i.from.name}</b> convidou você para {i.gameId}<button disabled={busy} onClick={()=>accept(i)}>Aceitar convite</button><button disabled={busy} onClick={()=>act('invite-answer',{id:i.id,accept:false})}>Recusar</button></article>)}</div></details>}
  </>}
  {note && <p role="status">{note}</p>}
</section>;}
