import {ludoCelebrationTiming} from '../../../shared/ludo-motion.js';
import React,{useEffect,useRef,useState} from 'react';
const ludoSounds={
  capture:[[0,165,.18,.065,'triangle',65],[40,86,.14,.04,'sine',42]],
  home:[[0,659,.18,.035],[80,988,.27,.031],[160,1319,.3,.025]],
  victory:[[0,392,.22,.038,'triangle'],[115,523,.23,.04,'triangle'],[230,659,.25,.04,'triangle'],[350,784,.52,.041,'triangle'],[350,523,.46,.027],[350,988,.46,.022]]
};
const themes={ludo:[261.63,329.63,392,329.63],uno:[293.66,369.99,440,369.99],chess:[220,261.63,329.63,261.63],'tic-tac-toe':[392,493.88,587.33,493.88],'checkers-brazilian':[246.94,293.66,369.99,293.66],'checkers-english':[246.94,293.66,369.99,293.66],battleship:[196,233.08,293.66,233.08]};
function preferences(){try{const saved=JSON.parse(localStorage.getItem('hiper:audio:v2'));if(saved)return {music:saved.music===true,effects:saved.effects===true};}catch{}return {music:false,effects:false};}
export default function GameAudio({room}){const [settings,setSettings]=useState(preferences),ctx=useRef(),last=useRef(''),timers=useRef(new Set());
const note=(hz,duration=.13,volume=.025,wave='sine',endHz)=>{const c=ctx.current;if(document.hidden||!c||c.state!=='running')return;const o=c.createOscillator(),g=c.createGain();o.type=wave;o.frequency.value=hz;if(endHz)o.frequency.exponentialRampToValueAtTime(endHz,c.currentTime+duration);g.gain.setValueAtTime(volume,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+duration);o.connect(g);g.connect(c.destination);o.onended=()=>{o.disconnect();g.disconnect();};o.start();o.stop(c.currentTime+duration);};
const unlock=async()=>{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;ctx.current??=new Audio();await ctx.current.resume();};
const later=(fn,ms)=>{const t=setTimeout(()=>{timers.current.delete(t);fn();},ms);timers.current.add(t);};
useEffect(()=>{if(!settings.music&&!settings.effects)return;const resume=()=>{unlock().catch(()=>{});};document.addEventListener('pointerdown',resume,{once:true});return()=>document.removeEventListener('pointerdown',resume);},[settings.music,settings.effects]);
useEffect(()=>{if(!settings.music)return;let i=0;const melody=themes[room.gameId]||themes.ludo,t=setInterval(()=>note(melody[i++%melody.length],.45,.013),700);return()=>clearInterval(t);},[settings.music,room.gameId]);
useEffect(()=>{if(!settings.effects)return;const click=()=>note(700,.05,.012);document.addEventListener('click',click);return()=>document.removeEventListener('click',click);},[settings.effects]);
useEffect(()=>{const g=room.game,e=g.lastEvent,key=g.round+':'+(g.revision??g.ply);if(last.current===key)return;last.current=key;if(!settings.effects)return;if((room.gameId!=='ludo'&&e?.captured?.length)||g.lastMove?.captures?.length||g.lastChessMove?.san?.includes('x')){note(880,.2);later(()=>note(1174,.2),100);}else if(e?.type==='power'||e?.activatedPower)note(660,.3);else if(e?.type==='roll'){note(180,.08);later(()=>note(240,.1),100);}else if(e?.type==='move'||g.lastMove||g.lastChessMove)note(330,.08,.016);},[room.game.revision,room.game.ply,settings.effects]);
const {landed,victory}=room.gameId==='ludo'?ludoCelebrationTiming(room.game):{};
const capture=!!room.game.celebration?.captured.length;
useEffect(()=>{
  if(!settings.effects || !landed&&!victory)return;
  const now=room.serverNow && Number.isFinite(room.receivedAt)
    ? room.serverNow+performance.now()-room.receivedAt : Date.now();
  const pending=[];
  for(const [time,kind] of [[landed,capture?'capture':'home'],[victory,'victory']]){
    if(!time || time<now-220)continue;
    const id=setTimeout(()=>{
      for(const [offset,...sound] of ludoSounds[kind])later(()=>note(...sound),offset);
    },Math.max(0,time-now));
    pending.push(id);
  }
  return ()=>pending.forEach(clearTimeout);
},[landed,victory,capture,settings.effects]);
useEffect(()=>{if(!settings.effects){timers.current.forEach(clearTimeout);timers.current.clear();}},[settings.effects]);
useEffect(()=>()=>{timers.current.forEach(clearTimeout);ctx.current?.close();},[]);
const toggle=async key=>{if(!settings[key])await unlock();const next={...settings,[key]:!settings[key]};setSettings(next);try{localStorage.setItem('hiper:audio:v2',JSON.stringify(next));}catch{}};
return <div className="audio-controls" role="group" aria-label="Áudio da partida"><button aria-pressed={settings.music} onClick={()=>toggle('music')}>{settings.music?'♫ Música ligada':'♫ Música desligada'}</button><button aria-pressed={settings.effects} onClick={()=>toggle('effects')}>{settings.effects?'♪ Efeitos ligados':'♪ Efeitos desligados'}</button></div>;}
