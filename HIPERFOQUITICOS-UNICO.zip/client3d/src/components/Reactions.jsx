import React,{useState,useEffect,useRef} from 'react';import {createPortal} from 'react-dom';import {TAUNTS,EMOJIS,AVATAR_EFFECTS,avatarEffect} from '../../../shared/reactions.js';import {api,tokenStore} from '../services/api.js';
import {reactionClock,reactionStart,reactionEnd} from '../reaction-timing.js';
export function ReactionPicker({send}){const [open,setOpen]=useState(false);return <div className="reaction-picker"><button onClick={()=>setOpen(v=>!v)} aria-expanded={open}>😏 Reações e provocações</button>{open&&<div>{[...EMOJIS,...TAUNTS].map(text=><button key={text} onClick={()=>{send('room:reaction',{text});setOpen(false);}}>{text}</button>)}</div>}</div>;}
export function AvatarGags({room,mark,me,send}){const [open,setOpen]=useState(false),[balance,setBalance]=useState(0),[note,setNote]=useState(''),[busy,setBusy]=useState(false);if(mark===me||room.game.teams?.some(t=>t.includes(me)&&t.includes(mark)))return null;const toggle=()=>{setOpen(v=>!v);if(tokenStore.get())api('/profile').then(({profile})=>setBalance(profile.coins)).catch(e=>setNote(e.message));};const play=async effect=>{setBusy(true);try{const r=await send('room:reaction',{kind:'avatar-effect',effect,target:mark,requestId:crypto.randomUUID()});if(r?.ok){setBalance(r.coins);setOpen(false);}else setNote(r?.error||'Não foi possível usar.');}finally{setBusy(false);}};return <><button className="avatar-gag-trigger" aria-label={'Brincadeiras com '+room.players.find(p=>p.mark===mark)?.name} onClick={toggle}/>{open&&createPortal(<div className="gag-picker-shade"><section className="avatar-gag-menu" role="dialog" aria-modal="true" aria-label="Enviar reação animada"><h3>Enviar para {room.players.find(p=>p.mark===mark)?.name}</h3><p>{balance} Foticas · cada envio é cobrado de quem envia</p>{['Zoadas','Fofas'].map(group=><div key={group}><h4>{group}</h4><div className="gag-grid">{AVATAR_EFFECTS.filter(e=>e.group===group).map(e=><button key={e.id} disabled={busy||!tokenStore.get()||balance<e.price} onClick={()=>play(e.id)}><span>{e.icon}</span>{e.name}<b>Enviar · {e.price} Foticas</b></button>)}</div></div>)}{!tokenStore.get()&&<p>Entre com Google para usar Foticas da conta.</p>}<p role="status">{note}</p><button disabled={busy} onClick={()=>setOpen(false)}>Fechar</button></section></div>,document.body)}</>;}
export function AvatarEffect({message}){const e=avatarEffect(message?.effect);return e?<span className={'avatar-effect effect-'+e.id} aria-label={e.name}><span className="effect-main">{e.id==='moustache'?'〰':e.id==='glasses'?'🕶️':e.icon}</span>{Array.from({length:5},(_,i)=><i key={i} style={{'--i':i}}>{['egg','tomato','pie'].includes(e.id)?'●':e.group==='Fofas'?'✦':'·'}</i>)}</span>:null;}
export function ReactionFlight({room}) {
  const seen = useRef(new Set());
  const timers = useRef(new Set());
  const [flights,setFlights] = useState([]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  useEffect(() => {
    const pending = [];
    for (const message of room.chat || []) {
      if (message.kind !== 'avatar-effect' || seen.current.has(message.id) || reactionEnd(message) <= reactionClock(room)) continue;
      const launch = () => {
        const avatars = [...document.querySelectorAll('[data-avatar-mark]')];
        const source = avatars.find(n => n.dataset.avatarMark === message.mark)?.getBoundingClientRect();
        const target = avatars.find(n => n.dataset.avatarMark === message.target)?.getBoundingClientRect();
        if (!source || !target || seen.current.has(message.id)) return;
        seen.current.add(message.id);
        const x = source.left + source.width / 2;
        const y = source.top + source.height / 2;
        const flight = {message,x,y,dx:target.left + target.width / 2 - x,dy:target.top + target.height / 2 - y};
        setFlights(old => [...old,flight].slice(-12));
        const timer = setTimeout(() => {
          setFlights(old => old.filter(f => f.message.id !== message.id));
          timers.current.delete(timer);
        },850);
        timers.current.add(timer);
      };
      const wait = reactionStart(message) - reactionClock(room);
      if (wait > 0) pending.push(setTimeout(launch,Math.ceil(wait)));
      else launch();
    }
    if (seen.current.size > 500) seen.current = new Set((room.chat || []).filter(m => seen.current.has(m.id)).map(m => m.id));
    return () => pending.forEach(clearTimeout);
  },[room.chat,room.serverNow,room.receivedAt]);
  return flights.length ? createPortal(<>{flights.map(({message,x,y,dx,dy}) =>
    <span key={message.id} className="reaction-flight" style={{left:x,top:y,'--dx':dx+'px','--dy':dy+'px'}}>{avatarEffect(message.effect)?.icon}</span>
  )}</>,document.body) : null;
}
