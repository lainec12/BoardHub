import LudoCelebration from './LudoCelebration.jsx';
import {pawnStep} from '../../../shared/ludo-motion.js';
import TimedDiceBubble from './TimedDiceBubble.jsx';
import {AvatarGags} from './Reactions.jsx';
import {LUDO_BASES as BASES} from '../games/ludoBases.js';
import {tokenLayout} from '../games/ludoTokenLayout.js';
import PowerBurst from './PowerBurst.jsx';
import {ComicBubble} from './TableSocial.jsx';
import {viewSteps,viewCorner,moverColor} from '../games/ludoPerspective.js';
import React,{lazy,Suspense,useEffect,useRef,useState} from 'react';
import AvatarPortrait from './AvatarPortrait.jsx';
import PowerIcon,{PowerHudIcon,POWER_NAMES} from './PowerIcon.jsx';
import {TRACK,START,SAFE,STAR_ZONES,START_ZONES} from '../../../client/public/ludo-map.js';
const Board3D=lazy(()=>import('./LudoBoard3D.jsx'));
const COLORS=['red','green','blue','yellow'];

const LANES={red:[[7,1],[7,2],[7,3],[7,4],[7,5],[7,6]],green:[[1,7],[2,7],[3,7],[4,7],[5,7],[6,7]],blue:[[13,7],[12,7],[11,7],[10,7],[9,7],[8,7]],yellow:[[7,13],[7,12],[7,11],[7,10],[7,9],[7,8]]};
function supportsWebGL(){try{const canvas=document.createElement('canvas'),gl=canvas.getContext('webgl2');gl?.getExtension('WEBGL_lose_context')?.loseContext();return !!gl;}catch{return false;}}
class BoardBoundary extends React.Component{state={failed:false};static getDerivedStateFromError(){return {failed:true};}componentDidCatch(){this.props.onFail();}render(){return this.state.failed?null:this.props.children;}}
function FlatBoard({game,clockOffset,me,viewer,pieces,canPick,onPick,onRoll,canRoll}){
 const board=useRef(null);
 React.useLayoutEffect(()=>{
   const event=game.lastEvent;
   if(!event?.startedAt || event.type!=='move')return;
   const pieces=[{color:event.movingColor||event.color,token:event.token},...event.captured]
     .map(p=>({...p,node:board.current.querySelector('[data-pawn="'+p.color+'-'+p.token+'"]')}));
   const cell=(color,v,i)=>v<0?BASES[color][i]:v<52?TRACK[(START[color]+v)%52]:LANES[color][v-52];
   let frame;
   function update(){
     let active=false;
     for(const {color,token,node} of pieces){
       if(!node)continue;
       const step=pawnStep(event,color,token,performance.now()+clockOffset-event.startedAt);
       if(!step){node.style.removeProperty('--walk-x');node.style.removeProperty('--walk-y');node.style.removeProperty('--pawn-tilt');continue;}
       const [r,c]=cell(color,step.from,token),[r2,c2]=cell(color,step.to,token);
       node.style.setProperty('--walk-x',((c+.5+(c2-c)*step.t)/15*100)+'%');
       node.style.setProperty('--walk-y',((r+.5+(r2-r)*step.t-step.lift*.4)/15*100)+'%');
       node.style.setProperty('--pawn-tilt',(step.tilt||0)+'rad');
       active=true;
     }
     if(active)frame=requestAnimationFrame(update);
   }
   update();
   return ()=>{cancelAnimationFrame(frame);for(const {node} of pieces){node?.style.removeProperty('--walk-x');node?.style.removeProperty('--walk-y');node?.style.removeProperty('--pawn-tilt');}};
 },[game.lastEvent?.startedAt,clockOffset]);
 const layout=tokenLayout(game.players);const cells=new Map(TRACK.map(([r,c])=>[r+','+c,{r,c}]));
 for(const [color,path] of Object.entries(LANES))path.forEach(([r,c])=>cells.set(r+','+c,{r,c,color}));
 START_ZONES.forEach(({x:c,y:r,color})=>cells.set(r+','+c,{r,c,color}));
 return <div ref={board} className="p-flat-board" style={{transform:`rotate(${-90*viewSteps(viewer)}deg)`}} aria-label="Tabuleiro Ludo acessível">{COLORS.map(color=><div key={color} className={'p-flat-base '+color}/>)}{[...cells.values()].map(({r,c,color})=><span key={r+','+c} className={'p-flat-cell '+(color||'')} style={{gridRow:r+1,gridColumn:c+1}}>{STAR_ZONES.some(z=>z.x===c&&z.y===r)?<span className="p-start-shadow">★</span>:START_ZONES.some(z=>z.x===c&&z.y===r)?<span className="p-start-shadow">★</span>:''}</span>)}<div className="p-flat-center"/>{COLORS.flatMap(color=>BASES[color].map(([r,c],i)=><span key={color+i} className="p-flat-slot" style={{left:(c+.5)/15*100+'%',top:(r+.5)/15*100+'%'}} aria-hidden="true"/>))}{game.players.map(p=>p.tokens.map((v,i)=>{const [r,c]=v<0?BASES[p.color][i]:v<52?TRACK[(START[p.color]+v)%52]:LANES[p.color][v-52];const place=layout[p.color+':'+i];const enabled=p.color===me&&canPick&&pieces.some(a=>a.token===i);return <button data-pawn={p.color+'-'+i} key={p.color+i} className={'p-flat-token '+p.color+(p.shields?.includes(i)?' shield-active':'')+(enabled?' available':'')+(game.lastEvent?.type==='move'&&(game.lastEvent.movingColor||game.lastEvent.color)===p.color&&game.lastEvent.token===i?' last-moved':'')} style={{left:'var(--walk-x,'+(c+.5+place.x)/15*100+'%)',top:'var(--walk-y,'+(r+.5+place.z)/15*100+'%)',transition:'none',transform:'translate(-50%,-50%) rotate(var(--pawn-tilt,0rad)) scale('+place.scale+')'}} disabled={!enabled} aria-label={p.color+' peão '+(i+1)} onClick={()=>onPick(i)}><span/>{i+1}</button>;}))}{game.powerDrops.map(d=>{const [r,c]=TRACK[d.cell];return <span className="p-flat-drop" style={{left:(c+.5)/15*100+'%',top:(r+.5)/15*100+'%'}} key={d.id} title={POWER_NAMES[d.power]}><PowerIcon power={d.power}/></span>;})}{(game.bonusCells||[]).map(cell=>{const [r,c]=TRACK[cell];return <span className="p-flat-bonus" key={cell} style={{left:(c+.5)/15*100+'%',top:(r+.5)/15*100+'%'}}>+1</span>;})}<button className="p-flat-die" disabled={!canRoll} onClick={onRoll} aria-label="Rolar dado no tabuleiro">{['⚀','⚁','⚂','⚃','⚄','⚅'][(game.diceAnimation?.value||game.die||1)-1]}</button></div>;
}
function ChooseDie({actions,onChoose,onClose}){const box=useRef();useEffect(()=>{box.current?.querySelector('button:not(:disabled)')?.focus();},[]);return <div className="p-dialog-shade" onClick={onClose}><section ref={box} className="p-die-dialog" role="dialog" aria-modal="true" aria-label="Escolha o dado" onClick={e=>e.stopPropagation()} onKeyDown={e=>{if(e.key==='Escape')onClose();if(e.key==='Tab'){const buttons=[...box.current.querySelectorAll('button:not(:disabled)')],first=buttons[0],last=buttons.at(-1);if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}}}}><h2>Escolha seu dado</h2><p>Use uma unidade de Escolher para definir o resultado.</p><div>{[1,2,3,4,5,6].map(value=><button key={value} disabled={!actions.some(a=>a.power==='control'&&a.value===value)} onClick={()=>onChoose(actions.find(a=>a.power==='control'&&a.value===value))}>{value}</button>)}</div><button className="p-cancel" onClick={onClose}>Cancelar</button></section></div>;}
export default function PremiumLudo({room,me,send,connected=true,serverNow,onChat,onInvite,onLeave}){
 const game=room.game,actor=game.players[game.turnIndex]?.color,animation=game.diceAnimation;
 const mine=game.players.find(p=>p.color===me),actions=room.legalMoves||[];
 const [webgl,setWebgl]=useState(supportsWebGL),[choose,setChoose]=useState(false),[emoji,setEmoji]=useState(false),[spent,setSpent]=useState('');
 const previous=useRef(mine?.inventory),previousRound=useRef(game.round);
 const rolling=!!animation&&animation.endsAt>serverNow;
 const canRoll=connected&&room.status==='playing'&&actor===me&&game.flow?.state==='AGUARDANDO_ROLAGEM'&&!choose;
 const canMove=connected&&room.status==='playing'&&actor===me&&game.flow?.state==='AGUARDANDO_MOVIMENTO'&&!choose;
 const moving=moverColor(game);const pieces=actions.filter(a=>a.type==='move');
 const act=action=>action&&send('game:action',{...action,round:game.round,revision:game.revision});
 const roll=()=>{if(canRoll&&!rolling)act({type:'roll'});};
 const pick=token=>{const action=pieces.find(a=>a.token===token);if(action){act(action);}};
 useEffect(()=>{if(previousRound.current!==game.round||actor!==me){setChoose(false);}previousRound.current=game.round;},[game.round,actor,me]);
 useEffect(()=>{const current=mine?.inventory;if(current&&previous.current){const used=Object.keys(previous.current).find(key=>(current[key]||0)<previous.current[key]);if(used)setSpent(used);}previous.current=current?{...current}:{};},[mine?.inventory]);
 useEffect(()=>{if(!spent)return;const timer=setTimeout(()=>setSpent(''),600);return()=>clearTimeout(timer);},[spent]);
 const usePower=power=>{if(power==='control'){setChoose(true);return;}act(actions.find(a=>a.power===power));};
 const team=game.teams?.find(t=>t.includes(me))||[me];
 const scores=marks=>{const list=room.players.filter(p=>marks(p.mark)).map(p=>room.scores.find(s=>s.player===p.id)?.wins||0);return game.teams?Math.max(0,...list):list.reduce((a,b)=>a+b,0);};
 const displayName=p=>p?.bot?p.name.replace(/\s*·\s*Bot\s*\d*$/i,''):p?.name||'jogador';
 const actorName=displayName(room.players.find(p=>p.mark===actor));
 const status=game.winner?(game.winner==='draw'?'Empate':(room.players.find(p=>p.mark===game.winner)?.name||'Jogador')+' venceu!'):actor===me?'Sua vez • '+actorName:'Vez de • '+actorName;
 return <section className="p-ludo-screen" aria-label="Ludo Premium"><div className="p-board-area"><div className="p-ludo-stage"><PowerBurst game={game}/><LudoCelebration room={room} me={me}/><div className="p-turn-plates"><span role="status">{status}</span><span>Nós {scores(mark=>team.includes(mark))} • Eles {scores(mark=>!team.includes(mark))}</span></div><div className="p-ludo-board" tabIndex={webgl?0:undefined} role="group" aria-label="Tabuleiro. Enter ou Espaço para rolar o dado na sua vez." onKeyDown={e=>{if(e.target===e.currentTarget&&(e.key==='Enter'||e.key===' ')){e.preventDefault();roll();}}}>{webgl?<BoardBoundary onFail={()=>setWebgl(false)}><Suspense fallback={<p className="p-loading" role="status">Preparando sua mesa…</p>}><Board3D clockOffset={room.serverNow-room.receivedAt} game={game} players={room.players} diceSkin={room.players.find(p=>p.mark===actor)?.dice||'classic'} me={moving} viewer={me} pieces={pieces} canPick={canMove} canRoll={canRoll} rolling={rolling} onPick={pick} onRoll={roll}/></Suspense></BoardBoundary>:<FlatBoard clockOffset={room.serverNow-room.receivedAt} game={game} me={moving} viewer={me} pieces={pieces} canPick={canMove} onPick={pick} onRoll={roll} canRoll={canRoll}/>}</div>{room.players.map(p=><article key={p.id} style={{'--seat':({red:'#ef4444',green:'#10b981',blue:'#3b82f6',yellow:'#eab308'})[p.mark]}} className={'p-seat '+viewCorner(p.mark,me)+(room.status==='playing'&&p.mark===actor?' is-active':'')}><div data-avatar-mark={p.mark} className={'p-seat-photo frame-'+(p.frame||'none')}><AvatarPortrait avatar={p.avatar} picture={p.picture}/><ComicBubble room={room} mark={p.mark}/><AvatarGags room={room} mark={p.mark} me={me} send={send}/><TimedDiceBubble animation={animation} mark={p.mark} serverNow={serverNow}/></div><div className="p-seat-name">{p.bot?'Bot •':'Nv.'+(p.level||1)} {displayName(p)}</div></article>)}</div></div><footer className="p-ludo-footer"><div className="p-timer-tools"><span role="timer">{game.flow?.deadline&&game.flow?.state!=='PROCESSANDO'?Math.max(0,Math.ceil((game.flow.deadline-serverNow)/1000))+'s':''}</span><button onClick={()=>send('ludo:auto',{enabled:!room.players.find(p=>p.mark===me)?.autoPlay})}>{room.players.find(p=>p.mark===me)?.autoPlay?'Desativar Auto-Jogar':'Ativar Auto-Jogar'}</button></div><p className="p-flow-message" role="status">{game.flow?.message||''}{game.lastEvent?.extraRollReasons?.includes('capture')?' • Capturou: jogue novamente!':game.lastEvent?.extraRollReasons?.includes('home')?' • Peão na chegada: jogue novamente!':''}{game.lastEvent?.gained?' • '+POWER_NAMES[game.lastEvent.gained]+' coletado':''}</p><div className="p-bottom-row"><div className="p-social"><button aria-expanded={emoji} onClick={()=>setEmoji(v=>!v)}>☻ Emoji</button><button onClick={onChat}>☏ Chat</button>{emoji&&<div className="p-emoji-picker" role="group" aria-label="Escolha um emoji">{['😀','👏','🎲','😎','🔥','💜'].map(icon=><button key={icon} onClick={()=>{send('chat:message',{text:icon});setEmoji(false);}}>{icon}</button>)}</div>}</div><div className="p-power-bar" aria-label="Inventário de poderes">{[['shield',mine?.shields?.length===4?'Escudo ativo':'Escudo'],['double','Duplo'],['control','Escolher']].map(([power,label])=>{const count=mine?.inventory[power]||0,legal=actions.some(a=>a.power===power),enabled=count>0&&legal&&canRoll&&game.mode!=='classic';return <button key={power} className={'p-power '+power+(spent===power?' was-used':'')} disabled={!enabled} aria-label={label+' • '+count+' disponíveis'} aria-pressed={power==='shield'?mine?.shields?.length===4:undefined} title={count?POWER_NAMES[power]:'Colete no tabuleiro para usar'} onClick={()=>usePower(power)}><span className="p-power-disc"><PowerHudIcon power={power}/><b>{count}</b></span><small>{label}</small></button>;})}</div><div className="p-room-tools"><button onClick={onInvite} title="Copiar convite">Convite</button><button onClick={onLeave} title="Sair da sala">Sair</button></div></div>{game.mode==='classic'&&<small className="p-classic-note">Clássico · poderes desligados nesta sala</small>}{(canMove)&&<details className="p-accessible"><summary>Selecionar peão pelo teclado</summary>{pieces.map(a=><button key={a.token} onClick={()=>pick(a.token)}>Peão {a.token+1}</button>)}</details>}</footer>{choose&&<ChooseDie actions={actions} onClose={()=>setChoose(false)} onChoose={action=>{act(action);setChoose(false);}}/>}</section>;
}
