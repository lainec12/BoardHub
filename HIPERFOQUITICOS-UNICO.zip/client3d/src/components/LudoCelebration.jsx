import React,{useEffect,useState} from 'react';
import {ludoCelebrationTiming} from '../../../shared/ludo-motion.js';

const dice=['⚀','⚁','⚂','⚃','⚄','⚅'];

export default function LudoCelebration({room,me}){
 const {celebration,winner,winningTeam}=room.game;
 const [now,setNow]=useState(Date.now);
 const {landed,end,victory}=ludoCelebrationTiming(room.game);

 useEffect(()=>{
   const clock=()=>room.serverNow && Number.isFinite(room.receivedAt)
     ? room.serverNow+performance.now()-room.receivedAt
     : Date.now();
   let timer;
   function update(){
     const t=clock();
     setNow(t);
     const next=[landed,end,victory,victory+3200].filter(time=>time>t).sort((a,b)=>a-b)[0];
     if(next)timer=setTimeout(update,Math.ceil(next-t));
   }
   update();
   return ()=>clearTimeout(timer);
 },[landed,end,victory,room.serverNow,room.receivedAt]);

 const won=victory && now>=victory && now<victory+3200;
 const landedNow=landed && now>=landed && now<end;
 if(!won&&!landedNow)return null;
 const isCapture=!!celebration?.captured.length;
 const kind=won?'victory':isCapture?'capture':'home';
 const marks=winningTeam || [winner];
 const names=room.players.filter(player=>marks.includes(player.mark)).map(player=>player.name);
 const label=won
   ? marks.includes(me) ? 'Você venceu!' : names.length>1 ? names.join(' e ')+' venceram!' : (names[0]||'O vencedor')+' venceu!'
   : isCapture ? (celebration.captured.length>1?'Peões capturados!':'Peão capturado!') : 'Peão na chegada!';
 const symbol=won?'🏆':isCapture?'✴':dice[celebration.die-1]||'✦';
 const count=won?18:8;
 return <div key={kind+':'+(won?victory:landed)} className={'ludo-celebration ludo-celebration--'+kind} role="status">
   <span className="ludo-celebration-icon" aria-hidden="true">{symbol}</span>
   <strong>{label}</strong>
   {Array.from({length:count},(_,i)=><i aria-hidden="true" key={i} style={{'--angle':i*360/count+'deg','--particle':i}}/>)}
 </div>;
}
