import React,{useEffect,useRef,useState,useSyncExternalStore} from 'react';
import {useNavigate,useLocation} from 'react-router-dom';
import {api,tokenStore} from '../services/api.js';
import {useRoom} from '../rooms/store.js';
import {GAMES} from '../rooms/Lobby.jsx';

function subscribe(update) {
  window.addEventListener('storage',update);
  window.addEventListener('account-session-change',update);
  return ()=>{
    window.removeEventListener('storage',update);
    window.removeEventListener('account-session-change',update);
  };
}

export default function RoomInvites() {
  const token=useSyncExternalStore(subscribe,tokenStore.get);
  return token ? <Inbox key={token} token={token}/> : null;
}

function Inbox({token}) {
  const navigate=useNavigate();
  const lobby=useLocation().pathname==='/lobby';
  const [requests,setRequests]=useState([]);
  const dismissedRequests=useRef(new Set());
  const room=useRoom(s=>s.room);
  const credentials=useRoom(s=>s.credentials);
  const [invites,setInvites]=useState([]);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const hidden=useRef(new Map());
  const dialog=useRef(null);
  const answering=useRef(false);
  const invite=invites[0];
  const request=lobby&&!invite?requests.find(r=>!dismissedRequests.current.has(r.id)):null;
  const notification=invite||request;
  const currentCode=room?.code || credentials?.code;
  const switching=currentCode && currentCode!==invite?.code;

  useEffect(()=>{
    let active=true,loading=false;
    async function refresh() {
      if(document.hidden || loading || answering.current) return;
      loading=true;
      try {
        const data=await api(lobby?'/friends':'/friends/invites',null,token);
        if(active && !answering.current) {
          for(const [id,end] of hidden.current) if(end<=Date.now()) hidden.current.delete(id);
          setRequests(lobby?(data.requests||[]).filter(r=>r.incoming):[]);
          setInvites(data.invites.filter(i=>!hidden.current.has(i.id)&&Date.parse(i.expiresAt)>Date.now()));
        }
      } catch {} finally {loading=false;}
    }
    refresh();
    const timer=setInterval(refresh,5000);
    window.addEventListener('focus',refresh);
    document.addEventListener('visibilitychange',refresh);
    return ()=>{
      active=false;
      clearInterval(timer);
      window.removeEventListener('focus',refresh);
      document.removeEventListener('visibilitychange',refresh);
    };
  },[token,lobby]);

  useEffect(()=>{
    setError('');
    const el=dialog.current;
    if(!notification || !el) return;
    el.showModal();
    return ()=>el.close();
  },[notification?.id]);

  function hide() {
    if(request){dismissedRequests.current.add(request.id);setRequests(queue=>queue.filter(r=>r.id!==request.id));return;}
    hidden.current.set(invite.id,Date.parse(invite.expiresAt));
    setInvites(queue=>queue.filter(i=>i.id!==invite.id));
  }

  async function answer(accept) {
    if(answering.current) return;
    answering.current=true;
    setBusy(true);
    setError('');
    try {
      if(request){await api('/friends/answer',{id:request.id,accept},token);hide();return;}
      const profile=accept ? (await api('/profile',null,token)).profile : null;
      if(tokenStore.get()!==token) return;
      const result=await api('/friends/invite-answer',{id:invite.id,accept},token);
      if(accept && tokenStore.get()===token) {
        const {code,gameId}=result.invite;
        const current=useRoom.getState();
        if(current.room?.code!==code) {
          if(current.room || current.credentials) await current.leave();
          const joined=await current.enter({code,gameId,name:profile.user.name},false);
          if(!joined) throw Error(useRoom.getState().error || 'Não foi possível entrar nessa sala.');
        }
        navigate('/room/'+gameId);
      }
      hide();
    } catch(e) {
      setError(e.message);
    } finally {
      answering.current=false;
      setBusy(false);
    }
  }

  if(request)return <dialog className="room-invite" ref={dialog} aria-labelledby="invite-heading" onCancel={e=>{e.preventDefault();if(!busy)hide();}}>
    <h2 id="invite-heading">Pedido de amizade</h2>
    <p><strong>{request.user.name}</strong> quer adicionar você como amigo.</p>
    {error&&<p role="alert">{error}</p>}
    <div><button className="primary" disabled={busy} onClick={()=>answer(true)}>Aceitar</button>
    <button disabled={busy} onClick={()=>answer(false)}>Recusar</button>
    <button disabled={busy} onClick={hide}>Agora não</button></div>
  </dialog>;
  if(!invite) return null;
  const game=GAMES.find(g=>g[0]===invite.gameId)?.[1] || invite.gameId;
  return <dialog className="room-invite" ref={dialog} aria-labelledby="invite-heading"
    onCancel={e=>{e.preventDefault();if(!busy)hide();}}>
    <h2 id="invite-heading">Convite para jogar {game}</h2>
    <p><strong>{invite.from.name}</strong> convidou você para a sala <b>{invite.code}</b>.</p>
    {switching && <p>Ao aceitar, você sai da sala atual.</p>}
    {error && <p role="alert">{error}</p>}
    <div><button className="primary" disabled={busy} onClick={()=>answer(true)}>{switching?'Sair e aceitar':'Aceitar convite'}</button>
    <button disabled={busy} onClick={()=>answer(false)}>Recusar</button>
    <button disabled={busy} onClick={hide}>Agora não</button></div>
  </dialog>;
}
