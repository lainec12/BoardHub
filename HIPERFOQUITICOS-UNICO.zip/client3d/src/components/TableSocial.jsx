import {BubbleContent} from './AnimalDecor.jsx';
import React,{useEffect,useLayoutEffect,useRef,useState} from 'react';import {createPortal} from 'react-dom';import {AvatarEffect} from './Reactions.jsx';
import {reactionClock,reactionStart,reactionEnd} from '../reaction-timing.js';

export function ComicBubble({room,mark}) {
  const anchor = useRef();
  const [{message,effect},setActive] = useState({});
  useEffect(() => {
    let timer;
    const update = () => {
      const now = reactionClock(room);
      const entries = (room.chat || []).filter(m => !m.system && (m.kind === 'avatar-effect' ? m.target === mark : m.mark === mark));
      const visible = entries.filter(m => reactionStart(m) <= now && reactionEnd(m) > now);
      setActive({
        message: visible.findLast(m => m.kind !== 'avatar-effect'),
        effect: visible.findLast(m => m.kind === 'avatar-effect')
      });
      const next = Math.min(...entries.flatMap(m => [reactionStart(m),reactionEnd(m)]).filter(time => time > now));
      if (Number.isFinite(next)) timer = setTimeout(update, Math.ceil(next - now));
    };
    update();
    return () => clearTimeout(timer);
  }, [room.chat,room.serverNow,room.receivedAt,mark]);
  return <><span ref={anchor} aria-hidden="true"/>
    {message && <SpeechBubble anchor={anchor} styleId={room.players.find(p=>p.mark===mark)?.bubble||'classic-bubble'}>{message.text}</SpeechBubble>}
    {effect && <AvatarEffect key={effect.id} message={effect}/>}
  </>;
}
export function TableChat({send,onClose}){const [text,setText]=useState('');return <form className="comic-composer" onSubmit={async e=>{e.preventDefault();if(text.trim()&&(await send('chat:message',{text}))?.ok){setText('');onClose?.();}}}><input autoFocus aria-label="Mensagem para os jogadores" placeholder="Diga algo ou envie um emoji…" value={text} maxLength={400} onChange={e=>setText(e.target.value)}/><button>Enviar</button><button type="button" onClick={onClose}>Fechar</button></form>;}

function SpeechBubble({anchor,styleId,children}){const ref=useRef(),[position,setPosition]=useState(null);useLayoutEffect(()=>{const update=()=>{if(!anchor.current?.parentElement||!ref.current)return;const a=anchor.current.parentElement.getBoundingClientRect(),b=ref.current.getBoundingClientRect(),v=window.visualViewport,w=v?.width||window.innerWidth,h=v?.height||window.innerHeight,y=v?.offsetTop||0;const left=Math.max(8,Math.min(w-b.width-8,a.left<w/2?a.right+8:a.left-b.width-8)),top=Math.max(y+8,Math.min(y+h-b.height-8,a.top<y+110?a.bottom+8:a.top-b.height-8));let point;if(top>=a.bottom)point='top';else if(top+b.height<=a.top)point='bottom';else if(left>=a.right)point='left';else point='right';const pointX=Math.max(18,Math.min(b.width-18,a.left+a.width/2-left)),pointY=Math.max(18,Math.min(b.height-18,a.top+a.height/2-top));setPosition({left,top,point,pointX,pointY});};update();window.addEventListener('resize',update);window.addEventListener('scroll',update,{passive:true,capture:true});window.visualViewport?.addEventListener('resize',update);return()=>{window.removeEventListener('resize',update);window.removeEventListener('scroll',update,true);window.visualViewport?.removeEventListener('resize',update);};},[children,anchor]);return createPortal(<span ref={ref} role="status" className={'comic-bubble viewport-bubble bubble-'+styleId+(position?' bubble-points-'+position.point:'')} style={{position:'fixed',left:position?.left||0,top:position?.top||0,bottom:'auto',right:'auto',visibility:position?'visible':'hidden','--tail-x':(position?.pointX||18)+'px','--tail-y':(position?.pointY||18)+'px'}}><BubbleContent styleId={styleId}>{children}</BubbleContent></span>,document.body);}
