import {BubbleContent} from './AnimalDecor.jsx';
import React,{useEffect,useLayoutEffect,useRef,useState} from 'react';import {createPortal} from 'react-dom';import {AvatarEffect} from './Reactions.jsx';
import {reactionClock,reactionStart,reactionEnd} from '../reaction-timing.js';

export function ComicBubble({room,mark}) {
  const anchor = useRef();
  const [{message,effect},setActive] = useState({});
  useEffect(() => {
    let timer;
    const update = () => {
      const now = reactionClock(room);
      const entries = (room.chat || []).filter(m => !m.system && (m.kind === 'avatar-effect' ? m.target === mark : m.mark === mark));
      const visible = entries.filter(m => reactionStart(m) <= now && reactionEnd(m) > now);
      setActive({
        message: visible.findLast(m => m.kind !== 'avatar-effect'),
        effect: visible.findLast(m => m.kind === 'avatar-effect')
      });
      const next = Math.min(...entries.flatMap(m => [reactionStart(m),reactionEnd(m)]).filter(time => time > now));
      if (Number.isFinite(next)) timer = setTimeout(update, Math.ceil(next - now));
    };
    update();
    return () => clearTimeout(timer);
  }, [room.chat,room.serverNow,room.receivedAt,mark]);
  return <><span ref={anchor} aria-hidden="true"/>
    {message && <SpeechBubble anchor={anchor} styleId={room.players.find(p=>p.mark===mark)?.bubble||'classic-bubble'}>{message.text}</SpeechBubble>}
    {effect && <AvatarEffect key={effect.id} message={effect}/>}
  </>;
}
export function TableChat({send,onClose}){const [text,setText]=useState('');return <form className="comic-composer" onSubmit={async e=>{e.preventDefault();if(text.trim()&&(await send('chat:message',{text}))?.ok){setText('');onClose?.();}}}><input autoFocus aria-label="Mensagem para os jogadores" placeholder="Diga algo ou envie um emoji…" value={text} maxLength={400} onChange={e=>setText(e.target.value)}/><button>Enviar</button><button type="button" onClick={onClose}>Fechar</button></form>;}

function SpeechBubble({anchor,styleId,children}) {
  const ref=useRef();
  const [position,setPosition]=useState(null);
  useLayoutEffect(()=>{
    const avatar=anchor.current?.closest('[data-avatar-mark]');
    const bubble=ref.current;
    if (!avatar || !bubble) return;
    const viewport=window.visualViewport;
    const update=()=>{
      const photo=avatar.getBoundingClientRect();
      const x=viewport?.offsetLeft || 0;
      const y=viewport?.offsetTop || 0;
      const width=viewport?.width || window.innerWidth;
      const height=viewport?.height || window.innerHeight;
      const right=photo.left+photo.width/2 < x+width/2;
      const gap=10;
      const space=right ? x+width-photo.right : photo.left-x;
      bubble.style.maxWidth=Math.max(1,Math.min(210,width*.58,space-gap-8))+'px';
      bubble.style.minWidth='min(65px, '+bubble.style.maxWidth+')';
      const box=bubble.getBoundingClientRect();
      const middle=photo.top+photo.height/2;
      const top=Math.max(y+4,Math.min(middle-box.height/2,y+height-box.height-4));
      setPosition({left:right?photo.right+gap:photo.left-gap-box.width,top,
        point:right?'left':'right',pointY:Math.max(8,Math.min(box.height-8,middle-top))});
    };
    update();
    const observer=new ResizeObserver(update);
    observer.observe(avatar);
    observer.observe(bubble);
    const stage=avatar.closest('.p-ludo-stage,.table-arena35');
    if(stage) observer.observe(stage);
    window.addEventListener('resize',update);
    window.addEventListener('scroll',update,true);
    viewport?.addEventListener('scroll',update);
    viewport?.addEventListener('resize',update);
    return ()=>{
      observer.disconnect();
      window.removeEventListener('resize',update);
      window.removeEventListener('scroll',update,true);
      viewport?.removeEventListener('scroll',update);
      viewport?.removeEventListener('resize',update);
    };
  },[children,anchor]);
  return createPortal(<span ref={ref} role="status" className={'comic-bubble viewport-bubble bubble-'+styleId+(position?' bubble-points-'+position.point:'')} style={{position:'fixed',left:position?.left||0,top:position?.top||0,bottom:'auto',right:'auto',visibility:position?'visible':'hidden','--tail-x':(position?.pointX||18)+'px','--tail-y':(position?.pointY||18)+'px'}}><BubbleContent styleId={styleId}>{children}</BubbleContent></span>,document.body);}
