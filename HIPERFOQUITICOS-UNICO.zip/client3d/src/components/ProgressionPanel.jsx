import React,{useEffect,useState} from 'react';
import {CATALOG} from '../metagame/catalog.js';
import {badgeName,levelFromXp,rankFromXp,xpForLevel} from '../../../shared/progression.js';
export const xpLevel=p=>p.level||levelFromXp(p.xp||0);
export function DailyMission({profile,remote}){
 const mission=profile.dailyMission;
 const [busy,setBusy]=useState(false),[notice,setNotice]=useState('');
 async function update(claim){
   if(busy)return;
   setBusy(true);setNotice('');
   try{
    const result=await remote(claim?'/rewards/legendary':'/profile',claim?{}:null);
    if(!result){setNotice('Não foi possível confirmar. Atualize o progresso para conferir.');return;}
    if(claim){
      const item=CATALOG.find(i=>i.id===result.rewardItemId);
      setNotice(item?item.name+' disponível por 48 horas em Perfil → Meus Aluguéis.':'Missão concluída. Você recebeu 75 XP.');
    }else setNotice('Progresso atualizado.');
   }finally{setBusy(false);}
 }
 if(!mission)return null;
 return <section className="panel"><h2>Missão do dia</h2><p>{mission.label} · {Math.min(mission.goal,mission.progress)}/{mission.goal}</p><button disabled={busy||mission.claimed||mission.progress<mission.goal} onClick={()=>update(true)}>{mission.claimed?'Recompensa resgatada':'Resgatar item lendário por 48h · +75 XP'}</button> <button disabled={busy} onClick={()=>update(false)}>Atualizar progresso</button><p role="status">{busy?'Consultando sua conta…':notice}</p></section>;
}
export default function ProgressionPanel({profile,remote,purchase}){
 const [tab,setTab]=useState('badges'),[now,setNow]=useState(Date.now()),[query,setQuery]=useState('');
 const level=xpLevel(profile),badges=profile.badges||[];
 const collection=(profile.achievements||[]).filter(badgeName);
 for(let n=2;n<=level;n+=2){collection.push('level:'+n);if(n%10===0)collection.push('veteran:'+n);if(n%50===0)collection.push('legend:'+n);}
 const visible=collection.filter(id=>badgeName(id).toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR'))).slice(-100);
 useEffect(()=>{if(tab!=='rentals')return;setNow(Date.now());const id=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(id);},[tab]);
 return <section className="progression-panel"><h2>Nível {level} · {profile.rank||rankFromXp(profile.xp||0)}</h2><p>{profile.xp||0} XP · {xpForLevel(level+1)-(profile.xp||0)} XP para o próximo nível</p>
 <div className="tabs"><button aria-pressed={tab==='badges'} onClick={()=>setTab('badges')}>Vitrine de etiquetas</button><button aria-pressed={tab==='rentals'} onClick={()=>setTab('rentals')}>Meus Aluguéis</button></div>
 {tab==='badges'?<><label>Buscar na coleção <input value={query} onChange={e=>setQuery(e.target.value)}/></label><p>{collection.length} etiquetas conquistadas</p><div className="badge-slots">{Array.from({length:7},(_,i)=>{const slot=i+1,current=badges.find(b=>b.slot===slot),options=[...new Set([...(current?[current.id]:[]),...visible])];return <label key={slot}>Posição {slot}<select disabled={!profile.user} value={current?.id||''} onChange={e=>remote('/profile/badge',{slot,badgeId:e.target.value||null})}><option value="">Vazio</option>{options.map(id=><option key={id} value={id}>{badgeName(id)}</option>)}</select></label>;})}</div></>:<>{!(profile.rentals||[]).some(r=>Date.parse(r.expiresAt)>now)&&<p>Nenhum aluguel ativo.</p>}{(profile.rentals||[]).map(r=>{const seconds=Math.ceil((Date.parse(r.expiresAt)-now)/1000),item=CATALOG.find(i=>i.id===r.itemId);return item&&seconds>0&&<p key={r.itemId}>{item.icon||'✦'} {item.name} · {Math.floor(seconds/3600)}h {Math.floor(seconds%3600/60)}min {seconds%60}s <button onClick={()=>purchase(item,true)}>Equipar</button></p>;})}</>}
 </section>;
}
