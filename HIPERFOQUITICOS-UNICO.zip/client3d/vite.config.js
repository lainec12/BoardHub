import {defineConfig} from 'vite';import tailwindcss from '@tailwindcss/vite';import {fileURLToPath} from 'node:url';
export default defineConfig({plugins:[tailwindcss()],root:fileURLToPath(new URL('./',import.meta.url)),base:'/3d/',envDir:fileURLToPath(new URL('../',import.meta.url)),build:{outDir:'../client/public/3d',emptyOutDir:true}});
