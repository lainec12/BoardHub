# Atualização 9.2.4

- Posições iniciais dos peões e das marcas corrigidas para um quadrado 2×2 centralizado em cada base, com margens iguais nos quatro lados.
- Coordenadas compartilhadas pelas versões 3D e alternativa, independentes da câmera.
- Raio de arredondamento limitado à metade da espessura de cada caixa, evitando geometria invertida nas placas finas que podia encobrir as marcações.
- Quatro marcas permanentes por base, desenhadas separadamente das peças e com contraste reforçado; continuam quando a base esvazia.
