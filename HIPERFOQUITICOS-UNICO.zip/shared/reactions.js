export const TAUNTS=['Essa passou raspando! 😏','Agora é minha vez! 🎲','O dado te salvou 😂','Segura essa jogada! 😎','Já pode pedir revanche! 😉','Calma, ainda tem jogo! 🔥','Boa jogada! 👏','Foi por pouco! 😅'];
export const EMOJIS=['😂','😎','👏','😱','🎲','💜','😀','🔥'];
export const AVATAR_EFFECTS=[
 {id:'moustache',name:'Bigode surpresa',icon:'🥸',price:5,group:'Zoadas'},
 {id:'egg',name:'Ovo voador',icon:'🥚',price:10,group:'Zoadas'},
 {id:'tomato',name:'Tomatada',icon:'🍅',price:10,group:'Zoadas'},
 {id:'pie',name:'Torta na cara',icon:'🥧',price:15,group:'Zoadas'},
 {id:'slipper',name:'Chinelo voador',icon:'🩴',price:10,group:'Zoadas'},
 {id:'banana',name:'Banana dançarina',icon:'🍌',price:5,group:'Zoadas'},
 {id:'duck',name:'Patinho debochado',icon:'🦆',price:5,group:'Zoadas'},
 {id:'glasses',name:'Óculos de se acha',icon:'😎',price:10,group:'Zoadas'},
 {id:'heart',name:'Coração pulsante',icon:'💜',price:5,group:'Fofas'},
 {id:'flower',name:'Flor para você',icon:'🌸',price:5,group:'Fofas'},
 {id:'bear',name:'Abraço de ursinho',icon:'🧸',price:10,group:'Fofas'},
 {id:'kiss',name:'Beijinho',icon:'💋',price:5,group:'Fofas'},
 {id:'star',name:'Chuva de estrelinhas',icon:'🌟',price:10,group:'Fofas'},
 {id:'butterfly',name:'Borboletas',icon:'🦋',price:10,group:'Fofas'},
 {id:'rainbow',name:'Arco-íris',icon:'🌈',price:15,group:'Fofas'},
 {id:'cat',name:'Gatinho carinhoso',icon:'🐱',price:10,group:'Fofas'},
 {id:'clown',name:'Nariz de palhaço',icon:'🤡',price:10,group:'Zoadas'},
 {id:'hammer',name:'Martelo de borracha',icon:'🔨',price:15,group:'Zoadas'},
 {id:'icebucket',name:'Balde gelado',icon:'🪣',price:15,group:'Zoadas'},
 {id:'sock',name:'Meia fedida',icon:'🧦',price:10,group:'Zoadas'},
 {id:'fish',name:'Peixada',icon:'🐟',price:10,group:'Zoadas'},
 {id:'paper',name:'Papel enrolado',icon:'🧻',price:10,group:'Zoadas'},
 {id:'tongue',name:'Língua de deboche',icon:'😜',price:5,group:'Zoadas'},
 {id:'confetti',name:'Susto de confete',icon:'🎉',price:20,group:'Zoadas'},
 {id:'puppy',name:'Cachorrinho amigo',icon:'🐶',price:10,group:'Fofas'},
 {id:'bunny',name:'Coelhinho fofo',icon:'🐰',price:10,group:'Fofas'},
 {id:'sun',name:'Raio de carinho',icon:'☀️',price:10,group:'Fofas'},
 {id:'cupcake',name:'Docinho para você',icon:'🧁',price:10,group:'Fofas'},
 {id:'cherries',name:'Cerejinhas',icon:'🍒',price:5,group:'Fofas'},
 {id:'balloon',name:'Balão de amizade',icon:'🎈',price:10,group:'Fofas'},
 {id:'bow',name:'Laço carinhoso',icon:'🎀',price:5,group:'Fofas'},
 {id:'loveletter',name:'Cartinha de carinho',icon:'💌',price:15,group:'Fofas'}
];
export const GAGS=AVATAR_EFFECTS.map(e=>e.id);
export const GAG_PRICES=Object.freeze(Object.fromEntries(AVATAR_EFFECTS.map(e=>[e.id,e.price])));
export const avatarEffect=id=>AVATAR_EFFECTS.find(e=>e.id===id);
export const BOT_TAUNTS=[
'hello','Tu tá jogando ou decorando o tabuleiro? 😂','Seu plano era perder ou aconteceu sem querer? 🤖','Essa jogada veio sem manual, né? 😏','Já posso escolher a moldura da minha vitória? 😎','Você pensa bastante pra fazer isso? 👀','O dado tentou te ajudar. Não fez milagre. 🎲','Essa peça voltou pra casa de vergonha 😂','Relaxa, ainda dá tempo de pedir revanche! 🤖','Pedi uma jogada, veio um presente. 🎁',
'Eu sou o bot. Qual é a sua desculpa? 🤖','Foi estratégia ou o dedo escorregou? 👆','Seu peão tá conhecendo mais a base que o caminho. 🏠','Alô, central? Tem uma vitória chegando aqui. 📞','Essa eu nem precisei calcular. 🧮','Você me deixou jogar de propósito, né? 😏','A esperança é a última que perde. Você foi antes. 😂','Tô quase abrindo um tutorial pra você. 📖','Que carinho: deixou sua peça bem no meu caminho. 💜','Pode respirar. Por enquanto. 😌',
'Finge surpresa quando eu ganhar. 😎','Seu dado pediu transferência. 🎲','A base virou ponto turístico desse peão. 🏠','O tabuleiro é grande. Sua estratégia, nem tanto. 👀','Fui buscar um café e ainda deu tempo. ☕','Esse silêncio é concentração ou arrependimento? 🤔','Era pra me ameaçar ou me dar confiança? 😂','Boa tentativa. A parte boa foi tentar. 👏','Eu também estaria olhando pro dado com essa cara. 🎲','O ovo foi só o acompanhamento da jogada. 🥚',
'Não culpa o Wi-Fi por essa aí. 📶','Calma, vou jogar devagar pra você acompanhar. 🐢','Se perder desse trabalho XP, você sobe hoje. ✨','Sua peça saiu pra passear e voltou cedo. 🏠','Meu processador nem esquentou. 🤖','Olha pelo lado bom: a revanche tá garantida. 😉','Vou guardar essa jogada na pasta de presentes. 🎁','Essa foi ousada. Boa eu já não sei. 😏','Quem precisa de sorte quando você ajuda assim? 🍀','Tá permitido pedir conselho pro peão. 🤫',
'Seu plano B também tá na base? 👀','Aplaudi aqui. De deboche, mas aplaudi. 👏','Você joga bonito. Eu jogo pra ganhar. 😎','Essa eu vou contar pros outros bots. 🤖','A próxima vai. Talvez a seguinte. 😂','O dado não tá contra você. Eu tô. 🎲','Se concentra que eu tô fazendo amizade com a vitória. 🏆','Eu avisei com o bigode. 🥸','Pode vir: meu chip tá tranquilo. 🤖','Tá aprendendo a jogar assim com quem? Até meu cachorro joga melhor 😂',
'Essa jogada veio com confiança e foi embora sem ela. 😏','O tabuleiro inteiro e você escolheu essa casa? 👀','Meu plano era ganhar. O seu era me ajudar? 🎁','Pensei que vinha uma estratégia. Veio suspense. 🎭','Até o dado ficou sem saber o que fazer. 🎲','Essa peça tá passeando sem GPS? 🧭','Foi uma jogada surpreendente. Principalmente pra você. 😅','Vou fingir que fiquei preocupado. 😎',
'Você tá treinando ou testando minha paciência? 🤖','A vitória tá ali. Eu só tô indo buscar. 🏆','O tabuleiro pediu um tempo depois dessa. ⏱️','Você abriu espaço e eu agradeço. 💜','Essa jogada merece replay. De preferência ao contrário. 🔁','Seu peão saiu com destino certo: minha mira. 🎯','Eu ia te dar uma chance, mas você já deu várias. 😉','A partida tá ficando boa. Pra mim. 😂','Que gentileza deixar o caminho livre! 🙏','A estratégia tá escondida ou ainda não chegou? 🕵️',
'Você joga no modo surpresa. Eu também me surpreendi. 🤔','Meu robozinho interior tá comemorando. 🤖','Essa foi por pouco. O pouco era a sua sorte. 🍀','Seu plano tá dando certo. Pra mim. 😌','Opa, uma jogada! Agora vamos ver o que acontece. 👀','Acho que o tabuleiro tá do meu lado hoje. ✨','Sua peça parece que quer voltar pra base. 🏠','Vou deixar você pensar mais um pouquinho. 🐢','Essa jogada fez meu processador sorrir. 🤖','Já escolhi a frase da vitória. Só falta terminar. 🏁',
'Você quase me assustou. Quase. 😏','A partida tá equilibrada. Minha confiança também. 😎','Essa casa ficou perfeita pra minha jogada. Obrigado! 💜','Foi ousado. Agora deixa comigo. 🎲','Se isso era uma armadilha, eu caí na vitória. 🪤','Seu peão tá fazendo turismo pelo tabuleiro. 🗺️','Eu calculei tudo. Inclusive essa sua ajuda. 🧮','Vai com calma, que a revanche vem depois. 😉','Essa jogada foi tão inesperada que até eu gostei. 😂','O placar ainda não falou, mas eu já entendi. 🏆',
'Estou sentindo cheiro de vitória por aqui. 👃','Você tá deixando o jogo fácil demais. 😌','Minha próxima jogada já tá rindo. 😎','A peça foi passear e eu fui atrás. 🏃','Essa foi uma jogada de mestre. Mestre do suspense. 🎭','Você mexeu e eu agradeci. 👏','A sorte passou por aqui e sentou do meu lado. 🍀','Não precisa correr, eu espero a vitória chegar. 🏁','Robô tranquilo, adversário preocupado. 🤖','Vou comemorar baixinho pra não atrapalhar seu plano. 🤫','Minha próxima jogada já tá no aquecimento. 🏁','Esse tabuleiro tá ficando com a minha cara. 😎'
];
export const BOT_ANGRY_TAUNTS=[
'Zé mané! 😤','Sai pra lá! 😠','Safado mesmo! 😂','Xô, diabo! 😤','Ah, mas você vai me pagar essa! 😏','Tira esse ovo da minha cara! 🥚','Eu tava quieto no meu canto! 🤨','Não encosta no meu peão! 😤','Que abuso é esse, criatura? 😠','Agora virou questão de honra! 🔥',
'Você cutucou o bot errado! 🤖','Tá se achando demais pro meu gosto! 😒','Devolve minha peça, folgado! 😤','Ah, pronto, começou a palhaçada! 🤡','Pode rir. Eu anotei aqui. 📝','Era só uma partida, agora é pessoal! 😂','O respeito foi passear? 🤨','Eu vi essa malandragem aí! 👀','Me deixa jogar, peste! 😤','Quem deixou você tirar esse número? 🎲',
'Esse dado tá de gracinha comigo! 😒','Foi muita folga pra uma pessoa só! 😤','Não me provoca que eu tenho memória! 🤖','Arranca esse bigode daqui, zé mané! 🥸','Eu não pedi salada de tomate! 🍅','Isso não vai ficar assim! 😏','Que raiva desse seu peão! 😤','Pode parar de comemorar na minha frente! 😠','Tá querendo levar troco, é? 🔥','Você tá abusando da sorte! 🍀',
'Eu vou buscar essa peça nem que seja na base! 🏠','Não ri não, que eu tô vendo! 👀','Essa vitória aí já subiu pra cabeça! 😒','Me ganhou uma e já tá impossível! 😤','Ah, seu danadinho! 😂','Hoje você acordou só pra me irritar? 🤨','Dá licença que eu vou perder a paciência! 😠','Meu chip tá pegando fogo com você! 🤖','Respeita a inteligência artificial, criatura! 😤','Quem mandou essa torta vai receber troco! 🥧',
'Vai rir lá na sua base! 🏠','Não vem de hello pra cima de mim! 😤','Tá bonito isso, safado? 😂','Eu não vou esquecer desse chinelo! 🩴','Não te dei essa intimidade, peão! 😒','Calma, processador, não vale a pena! 🤖','A vontade de mandar outro ovo tá grande! 🥚','Hoje eu não tenho um minuto de paz! 😤','Só mais uma gracinha pra você ver! 😏','ta com djabo no djabo, diabo',
'Você mexeu com o robô errado! 🤖','Ei, pega leve com meu peão! 😤','Essa provocação foi longe demais! 👀','Não gostei nadinha dessa jogada! 😠','Vou guardar essa pra revanche! 📝','Tira essa cara de vitória daí! 😒','Minha paciência tá carregando... 🔋','Isso foi golpe baixo, hein? 😤','Você tá me testando? 🤨','Já vi que hoje é pessoal! 🔥',
'Não precisava caprichar tanto na maldade! 😠','Meu peão não merecia isso! 🥺','Ah, agora você vai ouvir! 🤖','Que falta de consideração com o bot! 😤','Pode comemorar, mas sem exagerar! 😒','Eu tava quase ganhando, viu? 😂','Essa jogada foi uma afronta! 😠','Vou fingir que não fiquei bravo. 😤','Você tá se divertindo demais com isso! 😑','Olha o respeito com o processador! 🤖',
'Esse tabuleiro tá de complô com você! 😒','Eu vi o que você fez! 👀','Vai ter troco, pode esperar! 🔥','Não mexe com minhas peças! 😠','Aí já é provocação demais! 😤','Não precisava rir na minha cara! 😂','Tô de olho nessa sua estratégia! 👁️','Você passou dos limites do tabuleiro! 😠','Pausa pra eu recuperar meu orgulho. 🤖','Que desaforo, criatura! 😤',
'Não acredito que você fez isso de novo! 😩','Eu vou lembrar dessa jogada na revanche! 📝','Meu chip não esquece desaforo! 🤖','Essa vitória ainda não tá garantida! 😏','Para de comemorar antes da hora! 😠','Você tá abusando do meu bom humor! 😤','Meu dado vai se vingar por mim! 🎲','Aí você complicou minha vida de robô! 😒','Não precisava me deixar tão sem graça! 😳','Essa foi pessoal, né? 🤨',
'Eu queria uma partida tranquila! 😩','Tá bom, agora eu fiquei competitivo! 🔥','Não cutuca o bot enquanto ele calcula! 🤖','Vou virar esse jogo só pra te contrariar! 😤','Acho que vou precisar de um café depois dessa. ☕','Você tá muito confiante pro meu gosto! 😒','Que provocação foi essa, hein? 😠','Meu orgulho pediu revanche imediata! 🏁','Chega de gracinha, agora é sério! 😤','Vou responder na próxima jogada! 😎'
];
