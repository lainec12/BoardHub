export const TAUNTS=['Essa passou raspando! 😏','Agora é minha vez! 🎲','O dado te salvou 😂','Segura essa jogada! 😎','Já pode pedir revanche! 😉','Calma, ainda tem jogo! 🔥','Boa jogada! 👏','Foi por pouco! 😅'];
export const EMOJIS=['😂','😎','👏','😱','🎲','💜'];
export const AVATAR_EFFECTS=[
 {id:'moustache',name:'Bigode surpresa',icon:'🥸',price:5,group:'Zoadas'},
 {id:'egg',name:'Ovo voador',icon:'🥚',price:10,group:'Zoadas'},
 {id:'tomato',name:'Tomatada',icon:'🍅',price:10,group:'Zoadas'},
 {id:'pie',name:'Torta na cara',icon:'🥧',price:15,group:'Zoadas'},
 {id:'slipper',name:'Chinelo voador',icon:'🩴',price:10,group:'Zoadas'},
 {id:'banana',name:'Banana dançarina',icon:'🍌',price:5,group:'Zoadas'},
 {id:'duck',name:'Patinho debochado',icon:'🦆',price:5,group:'Zoadas'},
 {id:'glasses',name:'Óculos de se acha',icon:'😎',price:10,group:'Zoadas'},
 {id:'heart',name:'Coração pulsante',icon:'💜',price:5,group:'Fofas'},
 {id:'flower',name:'Flor para você',icon:'🌸',price:5,group:'Fofas'},
 {id:'bear',name:'Abraço de ursinho',icon:'🧸',price:10,group:'Fofas'},
 {id:'kiss',name:'Beijinho',icon:'💋',price:5,group:'Fofas'},
 {id:'star',name:'Chuva de estrelinhas',icon:'🌟',price:10,group:'Fofas'},
 {id:'butterfly',name:'Borboletas',icon:'🦋',price:10,group:'Fofas'},
 {id:'rainbow',name:'Arco-íris',icon:'🌈',price:15,group:'Fofas'},
 {id:'cat',name:'Gatinho carinhoso',icon:'🐱',price:10,group:'Fofas'},
 {id:'clown',name:'Nariz de palhaço',icon:'🤡',price:10,group:'Zoadas'},
 {id:'hammer',name:'Martelo de borracha',icon:'🔨',price:15,group:'Zoadas'},
 {id:'icebucket',name:'Balde gelado',icon:'🪣',price:15,group:'Zoadas'},
 {id:'sock',name:'Meia fedida',icon:'🧦',price:10,group:'Zoadas'},
 {id:'fish',name:'Peixada',icon:'🐟',price:10,group:'Zoadas'},
 {id:'paper',name:'Papel enrolado',icon:'🧻',price:10,group:'Zoadas'},
 {id:'tongue',name:'Língua de deboche',icon:'😜',price:5,group:'Zoadas'},
 {id:'confetti',name:'Susto de confete',icon:'🎉',price:20,group:'Zoadas'},
 {id:'puppy',name:'Cachorrinho amigo',icon:'🐶',price:10,group:'Fofas'},
 {id:'bunny',name:'Coelhinho fofo',icon:'🐰',price:10,group:'Fofas'},
 {id:'sun',name:'Raio de carinho',icon:'☀️',price:10,group:'Fofas'},
 {id:'cupcake',name:'Docinho para você',icon:'🧁',price:10,group:'Fofas'},
 {id:'cherries',name:'Cerejinhas',icon:'🍒',price:5,group:'Fofas'},
 {id:'balloon',name:'Balão de amizade',icon:'🎈',price:10,group:'Fofas'},
 {id:'bow',name:'Laço carinhoso',icon:'🎀',price:5,group:'Fofas'},
 {id:'loveletter',name:'Cartinha de carinho',icon:'💌',price:15,group:'Fofas'}
];
export const GAGS=AVATAR_EFFECTS.map(e=>e.id);
export const GAG_PRICES=Object.freeze(Object.fromEntries(AVATAR_EFFECTS.map(e=>[e.id,e.price])));
export const avatarEffect=id=>AVATAR_EFFECTS.find(e=>e.id===id);
export const BOT_TAUNTS=[
'hello','Tu tá jogando ou decorando o tabuleiro? 😂','Seu plano era perder ou aconteceu sem querer? 🤖','Essa jogada veio sem manual, né? 😏','Já posso escolher a moldura da minha vitória? 😎','Você pensa bastante pra fazer isso? 👀','O dado tentou te ajudar. Não fez milagre. 🎲','Essa peça voltou pra casa de vergonha 😂','Relaxa, ainda dá tempo de pedir revanche! 🤖','Pedi uma jogada, veio um presente. 🎁',
'Eu sou o bot. Qual é a sua desculpa? 🤖','Foi estratégia ou o dedo escorregou? 👆','Seu peão tá conhecendo mais a base que o caminho. 🏠','Alô, central? Tem uma vitória chegando aqui. 📞','Essa eu nem precisei calcular. 🧮','Você me deixou jogar de propósito, né? 😏','A esperança é a última que perde. Você foi antes. 😂','Tô quase abrindo um tutorial pra você. 📖','Que carinho: deixou sua peça bem no meu caminho. 💜','Pode respirar. Por enquanto. 😌',
'Finge surpresa quando eu ganhar. 😎','Seu dado pediu transferência. 🎲','A base virou ponto turístico desse peão. 🏠','O tabuleiro é grande. Sua estratégia, nem tanto. 👀','Fui buscar um café e ainda deu tempo. ☕','Esse silêncio é concentração ou arrependimento? 🤔','Era pra me ameaçar ou me dar confiança? 😂','Boa tentativa. A parte boa foi tentar. 👏','Eu também estaria olhando pro dado com essa cara. 🎲','O ovo foi só o acompanhamento da jogada. 🥚',
'Não culpa o Wi-Fi por essa aí. 📶','Calma, vou jogar devagar pra você acompanhar. 🐢','Se perder desse trabalho XP, você sobe hoje. ✨','Sua peça saiu pra passear e voltou cedo. 🏠','Meu processador nem esquentou. 🤖','Olha pelo lado bom: a revanche tá garantida. 😉','Vou guardar essa jogada na pasta de presentes. 🎁','Essa foi ousada. Boa eu já não sei. 😏','Quem precisa de sorte quando você ajuda assim? 🍀','Tá permitido pedir conselho pro peão. 🤫',
'Seu plano B também tá na base? 👀','Aplaudi aqui. De deboche, mas aplaudi. 👏','Você joga bonito. Eu jogo pra ganhar. 😎','Essa eu vou contar pros outros bots. 🤖','A próxima vai. Talvez a seguinte. 😂','O dado não tá contra você. Eu tô. 🎲','Se concentra que eu tô fazendo amizade com a vitória. 🏆','Eu avisei com o bigode. 🥸','Pode vir: meu chip tá tranquilo. 🤖','Tá aprendendo a jogar assim com quem? Até meu cachorro joga melhor 😂'
];
export const BOT_ANGRY_TAUNTS=[
'Zé mané! 😤','Sai pra lá! 😠','Safado mesmo! 😂','Xô, diabo! 😤','Ah, mas você vai me pagar essa! 😏','Tira esse ovo da minha cara! 🥚','Eu tava quieto no meu canto! 🤨','Não encosta no meu peão! 😤','Que abuso é esse, criatura? 😠','Agora virou questão de honra! 🔥',
'Você cutucou o bot errado! 🤖','Tá se achando demais pro meu gosto! 😒','Devolve minha peça, folgado! 😤','Ah, pronto, começou a palhaçada! 🤡','Pode rir. Eu anotei aqui. 📝','Era só uma partida, agora é pessoal! 😂','O respeito foi passear? 🤨','Eu vi essa malandragem aí! 👀','Me deixa jogar, peste! 😤','Quem deixou você tirar esse número? 🎲',
'Esse dado tá de gracinha comigo! 😒','Foi muita folga pra uma pessoa só! 😤','Não me provoca que eu tenho memória! 🤖','Arranca esse bigode daqui, zé mané! 🥸','Eu não pedi salada de tomate! 🍅','Isso não vai ficar assim! 😏','Que raiva desse seu peão! 😤','Pode parar de comemorar na minha frente! 😠','Tá querendo levar troco, é? 🔥','Você tá abusando da sorte! 🍀',
'Eu vou buscar essa peça nem que seja na base! 🏠','Não ri não, que eu tô vendo! 👀','Essa vitória aí já subiu pra cabeça! 😒','Me ganhou uma e já tá impossível! 😤','Ah, seu danadinho! 😂','Hoje você acordou só pra me irritar? 🤨','Dá licença que eu vou perder a paciência! 😠','Meu chip tá pegando fogo com você! 🤖','Respeita a inteligência artificial, criatura! 😤','Quem mandou essa torta vai receber troco! 🥧',
'Vai rir lá na sua base! 🏠','Não vem de hello pra cima de mim! 😤','Tá bonito isso, safado? 😂','Eu não vou esquecer desse chinelo! 🩴','Não te dei essa intimidade, peão! 😒','Calma, processador, não vale a pena! 🤖','A vontade de mandar outro ovo tá grande! 🥚','Hoje eu não tenho um minuto de paz! 😤','Só mais uma gracinha pra você ver! 😏','ta com djabo no djabo, diabo'
];
