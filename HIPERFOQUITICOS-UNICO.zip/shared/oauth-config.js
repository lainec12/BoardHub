// ID público OAuth. Nunca inclua Client Secret aqui.
export const DEFAULT_GOOGLE_CLIENT_ID = '195848073550-63nq9gpp2p64p1fcaljdf20baalpfer7.apps.googleusercontent.com';
