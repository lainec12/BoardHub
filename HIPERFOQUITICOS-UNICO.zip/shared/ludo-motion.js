// Durations in milliseconds, shared by both boards and the turn timer.
const forwardStep=215,returnStep=110,landingPause=350;
export const landingTime=event=>(event.to-event.from)*forwardStep;
export function motionDuration(event){
  const advance=landingTime(event);
  if(!event.captured.length)return advance;
  return advance+landingPause+Math.max(...event.captured.map(piece=>(piece.from+1)*returnStep));
}
export function pawnStep(event,color,index,elapsed){
  if(event?.type!=='move'||!Number.isFinite(event.startedAt))return null;
  let from,to,delay=0,step=forwardStep;
  if((event.movingColor||event.color)===color && event.token===index){
    from=event.from;to=event.to;
  }else{
    const victim=event.captured.find(p=>p.color===color&&p.token===index);
    if(!victim)return null;
    from=victim.from;to=-1;step=returnStep;
    const impact=elapsed-landingTime(event);
    delay=landingTime(event)+landingPause;
    if(elapsed<delay){
      const fall=Math.max(0,impact)/landingPause;
      return {from,to:from,t:0,lift:0,tilt:Math.sin(fall*Math.PI)*1.5};
    }
  }
  const time=Math.max(0,elapsed-delay)/step;
  if(time>=Math.abs(to-from))return null;
  const direction=Math.sign(to-from),start=from+direction*Math.floor(time);
  const t=time%1;
  return {from:start,to:start+direction,t:t*t*(3-2*t),lift:Math.sin(Math.PI*t)*(direction>0?.22:.10)};
}

export function ludoCelebrationTiming({celebration,winner,finishedAt}){
  const landed=celebration ? celebration.startedAt+landingTime(celebration) : 0;
  const end=landed ? landed+(celebration.captured.length?780:1050) : 0;
  const motionEnd=celebration ? celebration.startedAt+motionDuration(celebration) : 0;
  const victory=winner && winner!=='draw' && finishedAt ? Math.max(finishedAt,end,motionEnd) : 0;
  return {landed,end,victory};
}
