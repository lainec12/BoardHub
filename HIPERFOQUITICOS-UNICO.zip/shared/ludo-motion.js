// Durations in milliseconds, shared by both boards and the turn timer.
const forwardStep=215,returnStep=110,landingPause=180;
export function motionDuration(event){
  const advance=(event.to-event.from)*forwardStep;
  if(!event.captured.length)return advance;
  return advance+landingPause+Math.max(...event.captured.map(piece=>(piece.from+1)*returnStep));
}
export function pawnStep(event,color,index,elapsed){
  if(event?.type!=='move'||!Number.isFinite(event.startedAt))return null;
  let from,to,delay=0,step=forwardStep;
  if((event.movingColor||event.color)===color && event.token===index){
    from=event.from;to=event.to;
  }else{
    const victim=event.captured.find(p=>p.color===color&&p.token===index);
    if(!victim)return null;
    from=victim.from;to=-1;step=returnStep;
    delay=(event.to-event.from)*forwardStep+landingPause;
  }
  const time=Math.max(0,elapsed-delay)/step;
  if(time>=Math.abs(to-from))return null;
  const direction=Math.sign(to-from),start=from+direction*Math.floor(time);
  const t=time%1;
  return {from:start,to:start+direction,t:t*t*(3-2*t),lift:Math.sin(Math.PI*t)*(direction>0?.22:.10)};
}
