# Contratos compartilhados

`game:state` é um objeto JSON serializável; a interface trata esse objeto como somente leitura.
Cada motor de jogo exporta createState, validateAction e applyAction. O motor puro não conhece sockets ou DOM.
A camada de salas identifica o jogador pelo socket autenticado com token, aplica permissões e só então chama o motor.
Os jogos declaram limites próprios: Velha = 2, Damas Brasileiras e Inglesas = 2, Ludo = 2 a 4.
O servidor deve enviar visões filtradas por jogador nos futuros jogos com segredos (UNO e Batalha Naval).
