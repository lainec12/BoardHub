export function xpForLevel(level){
 if(level<=1)return 0;
 const n=level-1;
 // Cumulative cost, with exactly 100 XP from level one to level two.
 return 100+Math.round(40*(n**2.5-1)+50*(n**1.5-1)+12.5*(Math.sqrt(n)-1));
}
export function levelFromXp(xp){
 let low=1,high=2;
 while(xpForLevel(high)<=xp)high*=2;
 while(high-low>1){const mid=Math.floor((low+high)/2);if(xpForLevel(mid)<=xp)low=mid;else high=mid;}
 return low;
}
export const rankFromXp=xp=>xp>=500000?'Mestre':xp>=200000?'Diamante':xp>=100000?'Ouro':xp>=50000?'Prata':'Bronze';
const special={'first-win':'Primeira vitória',unbeatable:'Imbatível','dice-master':'Mestre do Dado','tournament-champion':'Campeão do Torneio','ludo-master':'Matador de Ludo','chess-master':'Rei do Xadrez','checkers-master':'Mestre de Damas','domino-master':'Mestre do Dominó','uno-master':'Rei do UNO','naval-master':'Almirante','ttt-master':'Mestre da Velha'};
export function badgeName(id){
 if(Object.hasOwn(special,id))return special[id];
 const match=/^(level|veteran|legend):([1-9]\d*)$/.exec(id);
 return match?({level:'Nível',veteran:'Veterano',legend:'Lenda'})[match[1]]+' '+match[2]:null;
}
export function canEquipBadge(id,level,achievements){
 if(!badgeName(id))return false;
 if(Object.hasOwn(special,id))return achievements.includes(id);
 const [kind,n]=id.split(':'),value=Number(n);
 return value<=level&&value%({level:2,veteran:10,legend:50}[kind])===0;
}
export function dailyChallenge(day){
 const value=[...day].reduce((n,c)=>((n*31+c.charCodeAt(0))>>>0),0);
 return [{goal:2,metric:'games',label:'Jogue duas partidas'},{goal:1,metric:'wins',label:'Vença uma partida'},{goal:3,metric:'games',label:'Jogue três partidas'}][value%3];
}
