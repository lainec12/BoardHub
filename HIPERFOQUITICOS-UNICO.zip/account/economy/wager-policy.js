// Bots usam identificadores reservados criados pelo servidor, nunca contas fictícias no banco.
export function validateWager(stake,players){
 if(!Number.isSafeInteger(stake)||stake<1||stake>1000||players.length<2||players.length>4||new Set(players.map(p=>p.id)).size!==players.length)throw Error('Aposta inválida');
 const humans=players.filter(p=>!p.bot);
 if(!humans.length||players.some(p=>typeof p.id!=='string'||(p.bot?!p.id.startsWith('bot:'):p.id.startsWith('bot:'))))throw Error('Participantes inválidos');
 if(players.some(p=>p.bot)&&humans.length!==1)throw Error('Aposta com bots exige um único jogador humano');
 return {humans,pot:stake*players.length,hasBots:humans.length!==players.length};
}
export function settlementShares(wager,record){
 const humans=wager.participants.filter(p=>!p.bot);
 if(record.cancelled||record.draw)return humans.map(p=>({id:p.id,amount:wager.stake}));
 const winners=[...new Set(record.winners||[])];
 if(!winners.length||winners.some(id=>!wager.participants.some(p=>p.id===id)))throw Error('Vencedores inválidos');
 const base=Math.floor(wager.pot/winners.length),rest=wager.pot%winners.length;
 return winners.slice().sort().map((id,i)=>({id,amount:base+(i<rest?1:0)})).filter(p=>humans.some(h=>h.id===p.id));
}
