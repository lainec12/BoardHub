export const CURRENCY={name:'Foticas',icon:'🧠'};
export function payoutShares(pot,winners){if(!Number.isSafeInteger(pot)||pot<0||!winners.length)throw Error('Pote inválido');const ids=[...new Set(winners)].sort(),base=Math.floor(pot/ids.length),rest=pot%ids.length;return ids.map((id,i)=>({id,amount:base+(i<rest?1:0)}));}
export const levelFromXp=xp=>1+Math.floor(xp/100);
export function eloChange(rating,others,score){const expected=others.reduce((s,r)=>s+1/(1+10**((r-rating)/400)),0)/Math.max(1,others.length);return Math.round(24*(score-expected));}
