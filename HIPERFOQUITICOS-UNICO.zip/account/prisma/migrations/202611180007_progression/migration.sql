CREATE TABLE "user_badges" (
 "userId" TEXT NOT NULL REFERENCES "Usuarios"("id") ON DELETE CASCADE,
 "badgeId" TEXT NOT NULL,
 "slot" INTEGER NOT NULL CHECK ("slot" BETWEEN 1 AND 7),
 PRIMARY KEY ("userId","badgeId"),
 UNIQUE ("userId","slot")
);
CREATE TABLE "Rental" (
 "userId" TEXT NOT NULL REFERENCES "Usuarios"("id") ON DELETE CASCADE,
 "itemId" TEXT NOT NULL,
 "expiresAt" TIMESTAMP(3) NOT NULL,
 PRIMARY KEY ("userId","itemId")
);
