ALTER TABLE "Usuarios" ADD COLUMN "equippedTheme" TEXT NOT NULL DEFAULT 'theme-midnight';
