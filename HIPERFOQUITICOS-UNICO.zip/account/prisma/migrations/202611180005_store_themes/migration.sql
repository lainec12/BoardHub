ALTER TABLE "User" ADD COLUMN "equippedTheme" TEXT NOT NULL DEFAULT 'theme-midnight';
