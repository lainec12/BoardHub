-- CreateTable
CREATE TABLE "Usuarios" (
    "id" TEXT NOT NULL,
    "googleId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "picture" TEXT,
    "coins" INTEGER NOT NULL DEFAULT 100,
    "equippedDice" TEXT NOT NULL DEFAULT 'classic',
    "equippedAvatar" TEXT NOT NULL DEFAULT 'google',
    "equippedFrame" TEXT NOT NULL DEFAULT 'none',
    "streak" INTEGER NOT NULL DEFAULT 0,
    "bestStreak" INTEGER NOT NULL DEFAULT 0,
    "powersUsed" INTEGER NOT NULL DEFAULT 0,
    "lastRecoveryDay" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Usuarios_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InventarioDados" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "itemId" TEXT NOT NULL,
    "purchasedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "InventarioDados_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Conquistas" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "unlockedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Conquistas_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Game" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "board" JSONB NOT NULL,
    "difficulty" TEXT NOT NULL,
    "version" INTEGER NOT NULL DEFAULT 0,
    "finished" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Game_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HistoricoPartidas" (
    "id" TEXT NOT NULL,
    "gameId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "gameName" TEXT NOT NULL DEFAULT 'Jogo da Velha',
    "opponent" TEXT NOT NULL DEFAULT 'Bot',
    "result" TEXT NOT NULL,
    "coins" INTEGER NOT NULL,
    "difficulty" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "HistoricoPartidas_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Usuarios_googleId_key" ON "Usuarios"("googleId");

-- CreateIndex
CREATE UNIQUE INDEX "InventarioDados_userId_itemId_key" ON "InventarioDados"("userId", "itemId");

-- CreateIndex
CREATE UNIQUE INDEX "Conquistas_userId_key_key" ON "Conquistas"("userId", "key");

-- CreateIndex
CREATE UNIQUE INDEX "HistoricoPartidas_gameId_key" ON "HistoricoPartidas"("gameId");

-- AddForeignKey
ALTER TABLE "InventarioDados" ADD CONSTRAINT "InventarioDados_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Conquistas" ADD CONSTRAINT "Conquistas_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Game" ADD CONSTRAINT "Game_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HistoricoPartidas" ADD CONSTRAINT "HistoricoPartidas_gameId_fkey" FOREIGN KEY ("gameId") REFERENCES "Game"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HistoricoPartidas" ADD CONSTRAINT "HistoricoPartidas_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE;

