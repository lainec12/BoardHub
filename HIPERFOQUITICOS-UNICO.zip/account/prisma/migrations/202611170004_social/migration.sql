ALTER TABLE "Usuarios" ADD COLUMN "equippedBubble" TEXT NOT NULL DEFAULT 'classic-bubble';
CREATE TABLE "Friendship" ("id" TEXT NOT NULL,"pair" TEXT NOT NULL,"fromId" TEXT NOT NULL,"toId" TEXT NOT NULL,"status" TEXT NOT NULL DEFAULT 'pending',"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "Friendship_pkey" PRIMARY KEY ("id"),CONSTRAINT "Friendship_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE,CONSTRAINT "Friendship_toId_fkey" FOREIGN KEY ("toId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE);
CREATE UNIQUE INDEX "Friendship_pair_key" ON "Friendship"("pair");
CREATE INDEX "Friendship_toId_status_idx" ON "Friendship"("toId","status");
CREATE TABLE "RoomInvite" ("id" TEXT NOT NULL,"fromId" TEXT NOT NULL,"toId" TEXT NOT NULL,"code" TEXT NOT NULL,"gameId" TEXT NOT NULL,"expiresAt" TIMESTAMP(3) NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,CONSTRAINT "RoomInvite_pkey" PRIMARY KEY ("id"),CONSTRAINT "RoomInvite_fromId_fkey" FOREIGN KEY ("fromId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE,CONSTRAINT "RoomInvite_toId_fkey" FOREIGN KEY ("toId") REFERENCES "Usuarios"("id") ON DELETE CASCADE ON UPDATE CASCADE);
CREATE INDEX "RoomInvite_toId_expiresAt_idx" ON "RoomInvite"("toId","expiresAt");

