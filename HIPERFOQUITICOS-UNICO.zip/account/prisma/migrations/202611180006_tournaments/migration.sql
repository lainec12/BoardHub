CREATE TABLE "Tournament" ("id" TEXT PRIMARY KEY,"status" TEXT NOT NULL DEFAULT 'registering',"startsAt" TIMESTAMP(3) NOT NULL,"endsAt" TIMESTAMP(3) NOT NULL,"state" JSONB NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" TIMESTAMP(3) NOT NULL);
CREATE INDEX "Tournament_status_endsAt_idx" ON "Tournament"("status","endsAt");
CREATE TABLE "TournamentEntry" ("id" TEXT PRIMARY KEY,"tournamentId" TEXT NOT NULL REFERENCES "Tournament"("id"),"userId" TEXT NOT NULL REFERENCES "Usuarios"("id"),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE UNIQUE INDEX "TournamentEntry_tournamentId_userId_key" ON "TournamentEntry"("tournamentId","userId");
CREATE TABLE "TournamentMessage" ("id" TEXT PRIMARY KEY,"tournamentId" TEXT NOT NULL REFERENCES "Tournament"("id"),"userId" TEXT NOT NULL REFERENCES "Usuarios"("id"),"name" TEXT NOT NULL,"text" TEXT NOT NULL,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "TournamentMessage_tournamentId_createdAt_idx" ON "TournamentMessage"("tournamentId","createdAt");
CREATE TABLE "TournamentChampion" ("id" TEXT PRIMARY KEY,"tournamentId" TEXT NOT NULL UNIQUE REFERENCES "Tournament"("id"),"userId" TEXT NOT NULL REFERENCES "Usuarios"("id"),"name" TEXT NOT NULL,"avatar" TEXT NOT NULL,"picture" TEXT,"prize" INTEGER NOT NULL,"wonAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
