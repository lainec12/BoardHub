-- Rode após migrar/copiar o schema da aplicação. As contas Google são autorizadas pela API Node.
-- Este script não apaga dados e pode ser executado novamente.
DO $$
DECLARE name text;
BEGIN
  FOREACH name IN ARRAY ARRAY['Usuarios','InventarioDados','Conquistas','Friendship','DailyClaim','user_badges','Rental','Game','HistoricoPartidas','PowerUse','Rating','WalletEntry','WagerRoom','RoomInvite','Tournament','TournamentEntry','TournamentMessage','TournamentChampion','_prisma_migrations'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',name);
    EXECUTE format('REVOKE ALL ON TABLE public.%I FROM anon, authenticated',name);
  END LOOP;
END $$;
GRANT SELECT ON public."TournamentChampion" TO service_role;
