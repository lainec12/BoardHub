import {createClient} from '@supabase/supabase-js';
let client;
export function supabaseClient(env=process.env){
 if(!env.SUPABASE_URL&&!env.SUPABASE_SECRET_KEY)return null;
 if(!env.SUPABASE_URL||!env.SUPABASE_SECRET_KEY)throw Error('Configure SUPABASE_URL e SUPABASE_SECRET_KEY juntos.');
 client??=createClient(env.SUPABASE_URL,env.SUPABASE_SECRET_KEY,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
 return client;
}
