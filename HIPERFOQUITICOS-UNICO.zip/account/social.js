import {progression,equippedBadges,cosmeticsFor} from './progression.js';
export function mountSocial(app,{db,api,fail}){const presence=new Map();app.locals.friendPresence=presence;
const publicUser=u=>({id:u.id,name:u.nickname||u.name,picture:u.picture,avatar:u.equippedAvatar,online:!!app.locals.friendOnline?.(u.id)||Date.now()-(presence.get(u.id)||0)<45000});
const relation=(a,b)=>({OR:[{fromId:a,toId:b},{fromId:b,toId:a}]});
function touchPresence(userId) {
  presence.set(userId,Date.now());
  if(presence.size>10000) for(const [id,time] of presence) if(Date.now()-time>60000) presence.delete(id);
}
async function pendingInvites(userId) {
  const invites=await db.roomInvite.findMany({
    where:{toId:userId,expiresAt:{gt:new Date()}},include:{from:true},orderBy:{createdAt:'desc'},take:20
  });
  return invites.map(i=>({id:i.id,from:publicUser(i.from),code:i.code,gameId:i.gameId,expiresAt:i.expiresAt}));
}
app.get('/api/friends/invites',api(async(req,res)=>{
  touchPresence(req.userId);
  res.json({invites:await pendingInvites(req.userId)});
}));
app.get('/api/friends',api(async(req,res)=>{touchPresence(req.userId);const edges=await db.friendship.findMany({where:{OR:[{fromId:req.userId},{toId:req.userId}]},include:{from:true,to:true},take:300});const invites=await pendingInvites(req.userId);res.json({friends:edges.filter(e=>e.status==='accepted').map(e=>publicUser(e.fromId===req.userId?e.to:e.from)),requests:edges.filter(e=>e.status==='pending').map(e=>({id:e.id,incoming:e.toId===req.userId,user:publicUser(e.fromId===req.userId?e.to:e.from)})),invites});}));
app.get('/api/friends/:id/profile',api(async(req,res)=>{
 const id=req.params.id;
 if(!await db.friendship.findFirst({where:{...relation(req.userId,id),status:'accepted'}}))fail('Perfil disponível para amigos.',404);
 const user=await db.user.findUnique({where:{id},include:{achievements:true}});
 if(!user)fail('Perfil indisponível.',404);
 const [badges,{effective}]=await Promise.all([equippedBadges(db,id),cosmeticsFor(db,user)]);
 res.json({friend:{...publicUser({...user,...effective}),...progression(user),xp:user.xp,badges,achievements:user.achievements.map(a=>a.key)}});
}));
app.post('/api/friends/request',api(async(req,res)=>{const id=String(req.body.userId||'').trim();if(!id||id.length>100||id===req.userId)fail('Informe o ID de outra conta.');if(!await db.user.findUnique({where:{id}}))fail('Conta não encontrada.');if(await db.friendship.count({where:{OR:[{fromId:req.userId},{toId:req.userId}]}})>=200)fail('Limite de 200 amizades e pedidos.');await db.$transaction(async tx=>{const existing=await tx.friendship.findFirst({where:relation(req.userId,id)});if(existing){if(existing.toId===req.userId&&existing.status==='pending')await tx.friendship.update({where:{id:existing.id},data:{status:'accepted'}});return;}await tx.friendship.create({data:{fromId:req.userId,toId:id,pair:[req.userId,id].sort().join(':')}});});res.json({ok:true});}));
app.post('/api/friends/answer',api(async(req,res)=>{const edge=await db.friendship.findUnique({where:{id:String(req.body.id||'')}});if(!edge||edge.toId!==req.userId||edge.status!=='pending')fail('Pedido indisponível.');if(req.body.accept===true)await db.friendship.update({where:{id:edge.id},data:{status:'accepted'}});else await db.friendship.delete({where:{id:edge.id}});res.json({ok:true});}));
app.post('/api/friends/remove',api(async(req,res)=>{await db.friendship.deleteMany({where:relation(req.userId,String(req.body.userId||''))});await db.roomInvite.deleteMany({where:relation(req.userId,String(req.body.userId||''))});res.json({ok:true});}));
app.post('/api/friends/invite',api(async(req,res)=>{const target=String(req.body.userId||''),edge=await db.friendship.findFirst({where:{...relation(req.userId,target),status:'accepted'}});if(!edge)fail('O convite exige amizade aceita.');if(!app.locals.friendOnline?.(target)&&Date.now()-(presence.get(target)||0)>=45000)fail('Seu amigo está offline.');const room=app.locals.friendRoom?.(req.userId,String(req.body.code||''));if(!room)fail('Crie uma sala com vaga antes de convidar.');const old=await db.roomInvite.findFirst({where:{fromId:req.userId,toId:target,expiresAt:{gt:new Date()}}});if(old)fail('Aguarde o convite anterior expirar.');await db.roomInvite.deleteMany({where:{expiresAt:{lt:new Date()}}});await db.roomInvite.create({data:{fromId:req.userId,toId:target,code:room.code,gameId:room.gameId,expiresAt:new Date(Date.now()+120000)}});res.json({ok:true});}));
app.post('/api/friends/invite-answer',api(async(req,res)=>{const invite=await db.roomInvite.findUnique({where:{id:String(req.body.id||'')}});if(!invite||invite.toId!==req.userId||invite.expiresAt<new Date())fail('Convite expirado.');await db.roomInvite.delete({where:{id:invite.id}});res.json({invite:req.body.accept===true?{code:invite.code,gameId:invite.gameId}:null});}));
}
