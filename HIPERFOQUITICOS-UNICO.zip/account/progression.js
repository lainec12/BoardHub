import {randomInt} from 'node:crypto';
import {levelFromXp,rankFromXp,badgeName,canEquipBadge,dailyChallenge} from '../shared/progression.js';
import {availableNow,brazilDate} from '../shared/seasons.js';
import {CATALOG} from '../client3d/src/metagame/catalog.js';
export const equippedFields={dice:'equippedDice',avatar:'equippedAvatar',frame:'equippedFrame',bubble:'equippedBubble',theme:'equippedTheme'};
export const cosmeticDefaults={dice:'classic',avatar:'google',frame:'none',bubble:'classic-bubble',theme:'theme-midnight'};
export const badgeAchievements=Object.fromEntries([['ludo','ludo-master'],['chess','chess-master'],['checkers-brazilian','checkers-master'],['checkers-english','checkers-master'],['uno','uno-master'],['domino','domino-master'],['battleship','naval-master'],['tic-tac-toe','ttt-master']]);
export function dateKey(date=new Date()){
 const {year,month,day}=brazilDate(date);
 return [year,month,day].map(n=>String(n).padStart(2,'0')).join('-');
}
export async function dailyProgress(db,userId,date=new Date()){
 const day=dateKey(date),challenge=dailyChallenge(day);
 const where={userId,createdAt:{gte:new Date(day+'T03:00:00Z')},...(challenge.metric==='wins'?{result:'victory'}:{})};
 const [progress,claimed]=await Promise.all([db.matchHistory.count({where}),db.dailyClaim.findUnique({where:{userId_day_kind:{userId,day,kind:'legendary-daily'}}})]);
 return {...challenge,day,progress,claimed:!!claimed};
}
export async function cosmeticsFor(db,user){
 const [owned,rentals]=await Promise.all([
  db.inventory.findMany({where:{userId:user.id},select:{itemId:true}}),
  db.rental.findMany({where:{userId:user.id,expiresAt:{gt:new Date()}}})
 ]);
 const allowed=new Set([...owned,...rentals].map(i=>i.itemId));
 const effective=Object.fromEntries(Object.entries(equippedFields).map(([category,field])=>[field,allowed.has(user[field])||user[field]===cosmeticDefaults[category]?user[field]:cosmeticDefaults[category]]));
 return {effective,rentals};
}
export async function equippedBadges(db,userId){
 return (await db.userBadge.findMany({where:{userId},orderBy:{slot:'asc'}})).map(b=>({id:b.badgeId,slot:b.slot,name:badgeName(b.badgeId)}));
}
export function mountProgression(app,{db,api,fail,serial,profile,wallet}){
 app.post('/api/profile/badge',api(async(req,res)=>{
  const {slot,badgeId}=req.body;
  if(!Number.isInteger(slot)||slot<1||slot>7||badgeId!==null&&typeof badgeId!=='string')fail('Etiqueta ou posição inválida.');
  await serial(async tx=>{
   const user=await tx.user.findUnique({where:{id:req.userId},include:{achievements:true}});
   if(badgeId!==null&&!canEquipBadge(badgeId,levelFromXp(user.xp),user.achievements.map(a=>a.key)))fail('Etiqueta ainda não conquistada.');
   await tx.userBadge.deleteMany({where:{userId:user.id,OR:[{slot},...(badgeId?[{badgeId}]:[])]}});
   if(badgeId)await tx.userBadge.create({data:{userId:user.id,slot,badgeId}});
  });
  res.json({profile:await profile(req.userId)});
 }));
 app.post('/api/rewards/legendary',api(async(req,res)=>{
  const rewardItemId=await serial(async tx=>{
   const mission=await dailyProgress(tx,req.userId);
   if(mission.claimed||mission.progress<mission.goal)fail('Missão indisponível ou já concluída.');
   const [owned,active]=await Promise.all([tx.inventory.findMany({where:{userId:req.userId}}),tx.rental.findMany({where:{userId:req.userId,expiresAt:{gt:new Date()}}})]);
   const used=new Set([...owned,...active].map(i=>i.itemId));
   const candidates=CATALOG.filter(i=>i.rarity==='Lendário'&&i.price&&availableNow(i)&&!used.has(i.id));
   const item=candidates.length?candidates[randomInt(candidates.length)]:null;
   await tx.dailyClaim.create({data:{userId:req.userId,day:mission.day,kind:'legendary-daily'}});
   if(item){const expiresAt=new Date(Date.now()+48*3600000);await tx.rental.upsert({where:{userId_itemId:{userId:req.userId,itemId:item.id}},update:{expiresAt},create:{userId:req.userId,itemId:item.id,expiresAt}});}
   await wallet.grantXp(tx,req.userId,75);
   return item?.id??null;
  });
  res.json({rewardItemId,profile:await profile(req.userId)});
 }));
}
export const progression=u=>({level:levelFromXp(u.xp),rank:rankFromXp(u.xp)});
