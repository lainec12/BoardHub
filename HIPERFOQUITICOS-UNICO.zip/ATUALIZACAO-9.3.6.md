# Atualização 9.3.6

Nitidez do Ludo aprimorada sem alterar câmera, enquadramento ou layout de celular/computador. Suavização MSAA ativada; densidade acompanha a tela até 2× no automático e 2,5× em Alta nitidez. Modo leve não reduz mais a resolução abaixo de um pixel por pixel CSS. Peões e círculos de marcação ganharam contornos mais suaves; mantidos os lotes de instâncias, ausência de sombras pesadas e renderização sob demanda.
