# Atualização 9.3.5

- Celular: área do tabuleiro dimensionada pela proporção projetada, controles inferiores compactos e opções de áudio/aparência recolhidas.
- Respeito às áreas seguras do iPhone e espaço inferior para os controles do navegador.
- Balões de fala ancorados no avatar mas posicionados dentro da área visível; reposicionam com rolagem, rotação e mudança da altura disponível.
- Duração das frases continua em sete segundos. Não foram alteradas regras, preços ou dificuldade.
