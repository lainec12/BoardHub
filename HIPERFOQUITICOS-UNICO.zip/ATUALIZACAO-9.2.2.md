# Atualização 9.2.2

- Peões na mesma casa são distribuídos individualmente em pequenos grupos; nunca substituídos por contador.
- A distribuição considera todas as cores na mesma casa do caminho e também as peças na chegada.
- Cada peão segue selecionável individualmente e a lógica de movimento permanece no servidor.
- Marcas permanentes da base preservadas; acabamento da moldura em dourado suave e HUD com sombras discretas.
- Mantidos os ajustes anteriores de responsividade, áudio independente e desempenho.
