# 9.4.0 — Dominó, campeonatos e Loja Hiperfoquítica

- Dominó individual de 2 a 4 jogadores: 28 peças, sete por jogador, abertura pela maior dupla, compra sem encaixe e vitória pela menor soma quando fechado. Mãos privadas, bots e reconexão integrados.
- No Ludo, uma única opção legal de movimento é executada após o dado, sem ativar Auto-Jogar. Havendo opções, a escolha continua manual.
- Cliente reconecta e reassocia a sala/identidade automaticamente após perda de transporte; até 60 segundos de reserva de vaga no servidor. Reinício do servidor ainda encerra salas em memória.
- Eventos gratuitos entre humanos: corrida a três vitórias, placar do evento separado e revanches confirmadas pelos participantes. Campeão recebe cinco Foticas na conta, uma vez por evento/conta, com registro na carteira e fila persistente de tentativas.
- Eventos sem campeão são interrompidos se um participante sair definitivamente. Empates não dão ponto.
- Loja renomeada para Loja Hiperfoquítica. Mais 32 dados de bichinhos e 32 balões com mascotes, além dos itens antigos.
- 50 temas de interface, claros e escuros, com padrões vetoriais e opção de equipar. Tema padrão gratuito; compras e equipamento sincronizam em conta Google. Convidados guardam o inventário neste navegador.
- Migração aditiva: User.equippedTheme. Nenhuma remoção de dados.
- Mantidas as melhorias de nitidez, desempenho e enquadramento da 9.3.10.

Testes automatizados cobrem motores, privacidade, partidas de bots, reconexão por perda real de transporte, eventos, premiação idempotente, catálogo e renderização das sete mesas. Validação de Prisma sem credenciais de produção não equivale a teste ponta a ponta da carteira real.
