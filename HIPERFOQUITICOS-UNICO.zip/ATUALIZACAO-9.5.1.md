# Atualização 9.5.1

- Balões de fala agora apontam para a foto do personagem que está falando, em estilo de gibi.
- Todos os robôs têm falas próprias no início da partida, exibidas em sequência.
- Robôs também podem provocar ao receber emoji, após capturas, em jogadas especiais e no encerramento da partida.
- Jogadas comuns não geram falas automáticas.
