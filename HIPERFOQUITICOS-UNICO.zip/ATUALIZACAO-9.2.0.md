# Hiperfoquíticos 9.2.0

## Ludo
- Câmera ortográfica inclinada em relação à mesa, altura 15 e afastamento horizontal 9. A base de cada participante aparece embaixo à esquerda. Só a visão muda; coordenadas, sorteio e regras são comuns à sala.
- Quatro marcações permanentes em cada base, mesmo quando vazias.
- A primeira vez é sorteada no servidor. O anfitrião não pode expulsar jogadores nem reiniciar o Ludo em andamento para manipular o resultado.
- Duplas: sem captura do parceiro, vitória com oito peças e dado de apoio para quem terminou suas quatro peças.
- Na mesa: dois Escudos, dois Duplos, dois Escolher e quatro casas amarelas +1. O +1 amarelo concede nova rolagem, sem deslocamento extra. Não existe mais bônus azul na mesa nem na barra.
- Poderes começam zerados e só podem ser usados antes de rolar. Escolher prepara o próximo resultado; Duplo consome o item e rola automaticamente, exibindo o resultado normal do dado e dobrando a distância do movimento; Escudo exige selecionar o peão. O servidor valida uso e inventário.
- Animações de uso diferentes por poder, exibidas em todos os clientes após confirmação, respeitando movimento reduzido.
- 10 segundos para rolar e 10 segundos para escolher um movimento. Ao vencer o prazo, ação automática; botão permite desativar Auto-Jogar durante a partida. Animações e falta de movimentos têm seus próprios tempos.

## Mesas e comunicação
- Avatares em cantos relativos ao participante, nome, indicador de vez e mensagens em balão por cinco segundos. A lista lateral foi removida das mesas React.
- Editor de mensagens flutuante. Classes de balão preparadas para futuros cosméticos; não há compra de balões nesta versão.
- Trilhas curtas originais sintetizadas no navegador por jogo; efeitos de clique, dado, poder e captura. Botão de som com preferência local. Áudio inicia desligado e depende de interação do navegador para tocar.
- UNO e demais mesas usam o mesmo padrão de retratos nos cantos.

## Cacheta
- Nova sala jogável de dois a quatro participantes, amigos por código ou bots.
- Variante explícita: nove cartas, dois baralhos, sem coringa, Ás baixo, fechamento automático após descarte válido. Monte e cartas adversárias ficam ocultos; apenas contagens são compartilhadas.
- Truco foi retirado por solicitação da usuária.

## Publicação
Pacote único com fonte e compilação. Substitua HIPERFOQUITICOS-UNICO.zip no repositório e faça novo deploy no Render. Esta entrega não altera automaticamente o site publicado. Variáveis e credenciais de produção continuam nas configurações do serviço.
