# Atualização 9.1.2

- Enquadramento com espaço reservado aos avatares, nomes e placar.
- Peões remodelados com corpo curvo, base arredondada e acabamento brilhante.
- Quatro encaixes permanentes por base com silhueta visível após a saída.
- Seletor de 2 ou até 4 jogadores. Em dois: amigo contra amigo por código ou jogador contra exatamente um bot, em cantos opostos.
- Poderes na mesa: 2 Escolher, 2 Duplos, 2 Escudos, 2 Bônus e 4 casas +1; reposição após coleta.
- 30 verificações automatizadas passaram; compilação de produção concluída.

Substitua o ZIP no repositório e faça novo deploy no Render. Esta entrega não publica automaticamente.
