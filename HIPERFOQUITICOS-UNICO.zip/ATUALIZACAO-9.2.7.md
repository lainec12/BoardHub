# Atualização 9.2.7

Capturar peça adversária ou concluir a chegada de um peão ao triângulo (posição final 57) concede uma nova rolagem ao jogador da vez, incluindo o dado de apoio em duplas. Vale para humanos e bots, com ou sem poderes. Captura bloqueada por segurança, escudo ou parceria não concede bônus de captura. Se a jogada concluir a vitória, a partida termina normalmente. Múltiplos motivos na mesma jogada concedem uma nova rolagem, sem acumular uma fila de turnos.
