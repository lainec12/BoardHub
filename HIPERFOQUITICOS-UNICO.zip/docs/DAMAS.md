# Damas — Etapa 2

A sala é criada com `checkers-brazilian` ou `checkers-english`. A escolha fica fixa na sala: quem entra por código ou convite recebe a variante do anfitrião. Ambas são para dois jogadores.

## Referências e regras adotadas

- Brasileiras: [FMJD — regras de damas-64, especialmente seção 5](https://www.fmjd.org/downloads/64cb/Official_Rules_of_the_game_in_64_classic_draughts.pdf).
- Inglesas: [WCDF — Rules of Checkers](https://wcdf.net/rules/rules_of_checkers_english.pdf).

| Mecânica | Brasileira | Inglesa |
| --- | --- | --- |
| Tabuleiro e peças | 8×8, 12 por lado | 8×8, 12 por lado |
| Primeiro lado | Brancas, X | Vermelhas, X |
| Pedra sem captura | Uma diagonal para frente | Uma diagonal para frente |
| Captura da pedra | Frente e trás | Apenas frente |
| Movimento da dama | Diagonal longa | Uma casa diagonal |
| Captura obrigatória | Maior quantidade de peças | Qualquer sequência completa |
| Promoção em sequência | Só ao terminar na fileira final | Chegada à fileira final encerra a sequência |

Na brasileira, vítimas bloqueiam a diagonal até o término da sequência. O percurso pode revisitar casas vazias, sem capturar a mesma peça novamente. Damas e pedras têm igual peso na lei da maioria.

Empates brasileiros seguem o perfil FMJD 64 consultado: repetição tripla; 15 lances de cada lado exclusivamente com damas sem captura; limites de finais reduzidos (5 ou 15 lances por lado, conforme material e diagonal longa); estabilidade de material de 30/60 lances em finais de 4–5/6–7 peças, com damas em ambos os lados. A promoção/captura reinicia a estabilidade. Esses limites ficam explícitos no código; não se mistura o limite internacional de 25 lances com o perfil escolhido.

Na inglesa, repetição tripla e 40 lances de cada lado sem captura ou avanço de pedra causam empate. Ambos os modos também aceitam empate por acordo. Sem peças ou sem jogadas legais, o jogador perde.

## Adaptações para partidas casuais online

- Identidade X/O é interna; a interface mostra as cores de cada variante. O criador ocupa X e mantém esse lado nas revanches. Não há sorteio/alternância automática de cores.
- Não há relógio de torneio, regra física de peça tocada, árbitro ou tabelas de posições mortas. Jogadas ilegais são recusadas sem perda automática por infração repetida.
- A repetição é encerrada automaticamente na terceira ocorrência registrada, sem exigir uma reclamação ao árbitro. Os limites de lances contam duas meias-jogadas como um lance de cada lado.
- O acordo de empate pode ser proposto durante qualquer turno; a próxima jogada cancela a proposta pendente.
- O anfitrião mantém os controles casuais de expulsão e reinício. Esses resultados não servem como ranking competitivo verificado.

## Como jogar na interface

1. No lobby, selecione uma variante, informe seu nome e crie a sala.
2. Envie o convite ao amigo. O anfitrião inicia quando os dois estiverem conectados.
3. Clique em uma peça com borda pontilhada. Os destinos válidos ficam destacados.
4. Clique no destino. Em captura múltipla, clique em cada pouso até completar o caminho.
5. O último pouso envia a ação inteira. A seleção anterior é uma prévia local; o servidor confere tudo novamente.
6. **Desfazer seleção** limpa a prévia antes do envio. **Girar tabuleiro** muda apenas a orientação visual.
7. O chat também registra movimentos, capturas, promoções e resultados.

## Organização do código

- `server/src/games/checkers/index.js`: gerador de caminhos completos, lei da maioria, promoção, vitória e contadores de empate.
- `server/src/games/index.js`: registro de motores, nomes e limites por jogo.
- `client/public/checkers.js`: seleção por prefixo de caminho legal, destaques e orientação.
- `server/src/app.js`: autoriza o socket, valida a versão do lance e distribui o estado.

Ações de damas: `{type:'move', path:[origem,pouso,...], round, ply}`. Não se aceita tabuleiro, lista de capturas ou promoção enviados pelo cliente. `ply` impede reenvio de uma ação antiga dentro da mesma partida.

Eventos novos: `game:draw-offer {}` e `game:draw-answer {accept:boolean}`. `room:create` aceita `gameId`. A resposta `game:state` inclui `gameName`, `legalMoves` e `drawOffer`.

## Testes executados

`npm test`: 29 testes passaram nesta entrega, incluindo regressão do Jogo da Velha.

- Regras das duas variantes: posição inicial, turnos, versão, imutabilidade, sequência completa, captura obrigatória e promoção.
- Diferenças: captura para trás, maioria, dama longa/curta e passagem pela fileira de promoção.
- Limites: bloqueio, última peça, repetição tripla, contadores, finais reduzidos e campos adulterados.
- Oito partidas completas geradas verificam contagem de peças, alternância de turno e serialização.
- Clientes Socket.io reais validam escolha de variante, sequência rejeitada/aceita, vitória, placar, reinício e acordo de empate.
- Testes compartilhados preservam chat isolado, reconexão, abandono, rate limiting e SQLite.

## Conferência visual pendente

O navegador de verificação não conseguiu alcançar o servidor local (conexão recusada). Os testes HTTP e Socket.io executaram no ambiente local, mas não substituem uma auditoria visual ou de leitor de tela.

Verifique manualmente no seu navegador: seleção e captura múltipla, coroa, giro, Tab/Enter/setas, chat, saída/reconexão e tela pequena. Em telas menores que 352 px de área disponível, o tabuleiro tem rolagem horizontal para preservar casas de pelo menos 44×44 px. Isso evita reduzir demais a área de toque. Não foi certificada conformidade WCAG AA.
