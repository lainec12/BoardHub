# Etapa 4 — UNO

Selecione UNO ao criar a sala. De 2 a 4 amigos podem entrar por código ou link. O anfitrião inicia e reinicia. Chat, reconexão de 60 segundos e vitórias no SQLite usam a infraestrutura comum.

## Implementado

Baralho clássico de 108 cartas; sete por jogador; combinação por cor/símbolo; coringa com escolha de cor; +2; +4 com aceitar ou desafiar; inverter e pular, incluindo comportamento para dois participantes. Não há empilhamento. É possível comprar voluntariamente e jogar apenas a carta recém-comprada ou passar. O descarte é reciclado, preservando a carta da mesa.

Marque “Dizer UNO” antes de jogar a penúltima carta. Sem anúncio, o adversário pode denunciar antes da próxima ação de jogo; a penalidade é comprar duas. O jogador ainda pode dizer UNO pelo botão antes da denúncia. A primeira mão vazia vence, após resolver penalidades finais de compra. Cada partida vale uma vitória no placar; não há campanha por pontos até 500.

No +4, o servidor guarda se o autor tinha a cor vigente: desafio correto faz o infrator comprar quatro; desafio errado faz o desafiante comprar seis e perder a vez. Não se publica a mão do infrator: a verificação é automática. Coringa inicial usa vermelho como adaptação casual; +4 inicial volta ao monte. A partida pode começar com dois, três ou quatro jogadores.

Referência do baralho e das regras: https://service.mattel.com/instruction_sheets/B0001-Eng.pdf . A interface tem desenho próprio e não usa imagens oficiais.

## Privacidade e implementação

`server/src/games/uno/index.js` contém motor, embaralhamento com criptografia do Node, jogadas legais e visão pública por jogador. A distribuição de estado para UNO é individual por socket, incluindo somente a mão do destinatário, contagens dos adversários e carta da mesa. Monte, outras mãos e evidência privada do desafio nunca são enviados.

`client/public/uno.js` renderiza cartas e controles; `uno.css` mantém roxo/lilás na plataforma e as quatro cores nas cartas. Seleção de cor usa botões. Ações usam `round` e `revision` e são validadas pelo servidor.

## Rodar e testar

Node 24+: `npm ci`, `npm test`, `npm start`; abra http://localhost:3000. A hospedagem para amigos em redes diferentes está descrita no README. Não há URL pública criada nesta entrega.

53 testes automatizados passaram: os anteriores mais nove testes do UNO, incluindo isolamento de mãos em dois sockets reais. Conferência visual em navegador e auditoria formal WCAG permanecem pendentes. Verifique manualmente cartas no celular, foco de teclado, escolha de cor e reconexão antes de uso público.
