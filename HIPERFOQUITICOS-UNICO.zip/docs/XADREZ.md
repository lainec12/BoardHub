# Xadrez — Etapa 6

Dois jogadores: X joga de brancas e começa; O joga de pretas. Selecione uma peça e um destino destacado. Promoção oferece dama, torre, bispo ou cavalo. O botão girar altera apenas a orientação visual.

Servidor usa chess.js (dependência npm) para movimentos legais, xeque, mate, roque, en passant e promoção. O histórico de movimentos é reconstituído ao validar cada ação para preservar a repetição de posições. O cliente envia origem, destino, promoção, rodada e revisão; não decide resultado.

Empates automáticos por afogamento, material insuficiente reconhecido pelo motor, repetição tripla e 50 lances sem movimento de peão nem captura. Repetição e regra dos 50 lances são automatizadas nesta variante casual, sem pedido ao árbitro. Não há relógio nem arbitragem completa de torneio. Também valem acordo de empate e desistência.

Oito testes específicos cobrem movimentos ilegais, turno, versão, mate, roque e casas atacadas, en passant e expiração, quatro promoções, rei exposto, afogamento, material, repetição serializada, 50 lances e sincronização/revanche com dois sockets. A coleção tem 69 testes aprovados. Auditoria visual e WCAG ainda pendentes.

Referência técnica: https://github.com/jhlywa/chess.js
