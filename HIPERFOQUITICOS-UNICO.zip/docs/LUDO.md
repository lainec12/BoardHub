# Ludo — Etapa 3

Multiplayer para **2 a 4 jogadores**, nos modos Clássico e Power Mode. Sala, dado, inventários, capturas e turnos são autoritativos no servidor.

## Regras

- Quatro peças por cor; vermelho, verde, amarelo e azul.
- Um 6 libera peça e concede outra rolagem; três 6 seguidos encerram o turno.
- Circuito de 52 casas, seis casas finais e chegada exata na posição 57.
- Captura fora das casas seguras devolve a peça adversária à base.
- Vence quem leva quatro peças à chegada; o fim mostra ranking pelas peças concluídas.
- Teleporte não captura, não entra na chegada e só pousa em casa livre do circuito.

## Power Mode

O host escolhe inventário fixo (Double 2, Control 1, Shield 2, Bonus 2, Freeze 1, Teleport 1) ou aquisição nas quatro casas marcadas com raio, com limite de três poderes. Poderes ficam bloqueados nos dois primeiros turnos completos. Só um poder comum é permitido por turno; Bonus Roll é a exceção pós-movimento e não pode ser encadeado.

| Poder | Validação aplicada |
| --- | --- |
| Double Distance | Depois do dado; dobra 1–5 e rejeita 6 |
| Dice Control | Antes do dado; escolhe 1–5 |
| Protection Shield | Protege uma peça até o próximo turno do dono |
| Bonus Roll | Nova rolagem após mover, sem encadeamento |
| Freeze | Alvo perde o próximo turno; alvo já congelado é rejeitado |
| Teleport | Depois do dado; circuito livre, sem captura |

Ao ser capturado, o jogador perde um poder aleatório disponível. O cliente envia apenas intenção e revisão; toda aleatoriedade ocorre no servidor.

## Interface e acessibilidade

Tabuleiro SVG 15×15 responsivo, peças numeradas, rótulos de leitor de tela, ativação com Enter/Espaço, estrela nas casas seguras e raio nas casas de poder. O painel mostra dado, ações, inventário, peças na base/chegada e congelamento. O fim abre ranking com revanche para o anfitrião. Sons não foram incluídos, pois eram opcionais.

## Testes e decisões

Os testes cobrem 2–4 jogadores, recusa do quinto, dado no servidor, base, chegada exata, vitória, captura, escudo, três 6, todos os seis poderes, casas especiais, inventário, revisão adulterada, reconexão e revanche.

- Rolagens extras pertencem ao mesmo turno para o bloqueio inicial.
- Escudo expira no próximo turno do dono.
- Teleporte consome a jogada do dado e nunca captura.
- Não há bloqueio por duas peças na mesma casa; peças próprias podem compartilhar casas.
- Saída em partida de 3–4 participantes encerra como empate; com dois, o restante vence.
