# Etapa 5 — Batalha Naval

Dois jogadores, oceanos 10×10 e frota de cinco navios com comprimentos 5, 4, 3, 3 e 2. Navios retos, horizontais ou verticais, sem sobreposição e dentro dos limites. Navios podem se tocar nesta variante casual.

O anfitrião inicia a fase de posicionamento. Clique na origem de cada navio na ordem de tamanhos indicada; o botão de orientação alterna horizontal/vertical. Limpar permite refazer tudo antes de confirmar. O servidor aceita a frota inteira apenas após validação. Uma confirmação não pode ser alterada. Os tiros ficam bloqueados até os dois confirmarem.

X começa. Cada jogador dispara uma vez por turno, inclusive após acerto. Resultado: água, acerto ou afundado. Afundar todos os navios vence; não há empate automático. Reinício pelo anfitrião limpa as duas frotas. Desistência e reconexão seguem as regras comuns.

## Privacidade

O servidor mantém o estado integral e envia uma visão por socket: frota própria, tiros feitos e recebidos e prontidão dos dois jogadores. A frota inimiga nunca é transmitida. A lista de casas de um navio afundado só é revelada ao atirador após todos os acertos. Não há estado secreto embutido no HTML ou no cliente.

## Arquivos

- `server/src/games/battleship/index.js`: preparação, validação, tiros e visão privada.
- `client/public/battleship.js`: posicionamento e dois oceanos com botões rotulados.
- `client/public/battleship.css`: roxo/lilás e alvos de 44×44 px; no celular, oceanos têm rolagem horizontal.
- `test/battleship.test.js`: seis testes, incluindo clientes Socket.io reais e reconexão.

## Execução e validação

Node 24+: `npm ci`, `npm test`, `npm start`; abra http://localhost:3000 e escolha Batalha Naval. Acesso entre redes diferentes exige hospedar o servidor conforme o README. Não há URL pública nesta entrega.

Testes cobrem limites, sobreposição, continuidade, horizontal/vertical, preparo, turno, repetição, água/acerto/afundado, vitória, revisão, imutabilidade, privacidade pela rede e reconexão. Conferência visual e auditoria de acessibilidade permanecem pendentes.
