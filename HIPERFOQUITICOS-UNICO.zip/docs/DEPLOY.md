# GitHub e hospedagem

O repositório guarda o código. Para jogar em redes diferentes, execute o servidor Node em hospedagem com conexões persistentes. GitHub Pages sozinho não executa o servidor de salas.

## Render: cliente e servidor juntos (pacote pronto)

1. Crie Web Service e conecte somente o repositório BoardHub.
2. Runtime Node 24; build `npm ci`; start `npm start`; health check `/health`.
3. Use uma instância. Configure disco persistente e DB_PATH apontando para ele, por exemplo `/var/data/boardhub.sqlite`. Consulte disponibilidade e preço do plano antes de contratar.
4. Defina PUBLIC_URL como a URL HTTPS do serviço. Para login obrigatório, configure GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET e SESSION_SECRET aleatório de pelo menos 32 caracteres. Quando atrás de exatamente um proxy confiável, configure TRUST_PROXY=1.
5. No Google Cloud, cadastre o callback exato `https://SEU-DOMINIO/auth/google/callback`. Nunca adicione segredos ao GitHub ou ao cliente.
6. Abra a URL pública em dois dispositivos/redes diferentes e confira login, convite, chat e reconexão.

Sem credenciais Google, o código usa modo de desenvolvimento por apelido. Não considere o login Google ativado até configurar e testar as credenciais reais. SQLite preserva perfis, sessões e resultados; salas e partidas ativas estão em memória e não sobrevivem ao reinício do processo.

## Railway e domínio próprio

No Railway, conecte BoardHub, use Node 24 e `npm start`, configure volume para SQLite e as mesmas variáveis. O servidor lê PORT automaticamente. Para domínio próprio, siga os registros DNS fornecidos pela hospedagem, espere o certificado HTTPS e atualize PUBLIC_URL e o callback no Google. Nenhum domínio ou serviço pago foi contratado nesta entrega.

## Vercel/Netlify com backend separado

Este pacote serve front e backend juntos. Para separar, publique `client/public`, configure Socket.io para a URL do servidor, CLIENT_ORIGIN para a origem do cliente, rotas HTTP de autenticação e política de cookies entre as origens. Isso exige adaptação adicional; não basta subir apenas os arquivos HTML. Para o perfil Google funcionar com menos configurações, prefira o serviço único acima. Não há implantação separada Vercel + Render pré-configurada.

## Validação e próximos passos

Execute `npm ci` e `npm test` antes do deploy. A suíte atual tem 69 testes aprovados. A conferência visual em desktop/mobile e auditoria de acessibilidade ainda precisam ser realizadas. Ranking global, torneios, bots, replay, PostgreSQL e persistência de salas são evoluções futuras.
