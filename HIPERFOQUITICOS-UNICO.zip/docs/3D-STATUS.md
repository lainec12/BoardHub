# Estado do projeto unificado 7.1

React/R3F/Drei/Rapier para Ludo e Velha; os demais quatro jogos preservam cenas Three.js integradas às rotas React. Todos usam os motores autoritativos e a infraestrutura de salas. Ludo possui dado clicável, movimento automático, três estados de turno, avatares Html, coordenadas seguras compartilhadas e drops aleatórios repostos pelo servidor. Poderes não têm mais teto de inventário ou bloqueio inicial de turnos.

Economia Foticas, ELO por jogo, XP/baús, diário/missões e cosméticos possuem implementação PostgreSQL e migrações. Bots só no treino; potes só entre humanos autenticados. Interface, scripts e servidor estão no mesmo package.json e no mesmo ZIP.

Verificações: build e 94 testes de lógica/rede. SQL/Google reais e visual WebGL continuam sem validação de produção no ambiente disponível. Não se declara equivalência artística às imagens conceituais nem invencibilidade dos bots fora da Velha.
