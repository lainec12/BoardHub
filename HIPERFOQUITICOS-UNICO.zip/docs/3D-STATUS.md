# Migração visual 3D

Cenas WebGL com Three.js, módulos servidos pelo próprio servidor, sem CDN. Ludo: peões com seleção por raycasting e animação casa a casa, sem prévia do destino. Dado CSS com seis faces e rotação cosmética; resultado permanece validado no servidor. Velha: peças X/O volumétricas; Damas: discos e damas empilhadas; Xadrez: peças modeladas proceduralmente; UNO: mesa e cartas texturizadas, até 14 cartas por página 3D e mão inteira nos controles; Naval: dois oceanos e navios próprios, sem revelar a frota adversária.

Botão de controles acessíveis conserva as interações HTML. Sem WebGL, controles 2D continuam disponíveis. A arte é procedural e ainda não equivale às ilustrações de referência aprovadas.

Validação: sintaxe dos módulos e testes automatizados de regras/rede. QA visual pendente: navegador remoto não alcança localhost (ERR_CONNECTION_REFUSED). Não afirmar teste visual completo ou equivalência artística à referência.
