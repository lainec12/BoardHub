# Perfil único BoardHub com Google

Quando configurado, o login Google é obrigatório para criar ou entrar nas salas de qualquer jogo. Na primeira entrada, o ID Google e o nome são gravados no SQLite. O mesmo perfil vale para todo o lobby e todos os jogos; não há um login por jogo. O nome utilizado nas salas vem do banco, não de um ID enviado pelo cliente.

A sessão fica em cookie HttpOnly por até 30 dias e os dados da sessão ficam no SQLite. Limpar cookies, expiração, sair da conta ou mudar de dispositivo exige novo login; o perfil continua salvo. Não é possível prometer login permanente. Nenhum accessToken ou refreshToken é armazenado. O fluxo usa state contra falsificação de login e o logout exige token CSRF. Sessões encerradas são rejeitadas ao entrar ou agir nas salas.

## Ativar

1. Crie um cliente OAuth do tipo Aplicativo Web no Google Cloud e configure a tela de consentimento.
2. Cadastre a URI exata `http://localhost:3000/auth/google/callback` para testes. Na hospedagem, use `https://SEU-DOMINIO/auth/google/callback`.
3. Configure GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, SESSION_SECRET (aleatório, pelo menos 32 caracteres) e PUBLIC_URL no ambiente do servidor. Não coloque segredos no navegador, Git ou chat.
4. Em produção, PUBLIC_URL precisa ser HTTPS. Se houver exatamente um proxy confiável, configure TRUST_PROXY=1. Use disco persistente para DB_PATH e mantenha SESSION_SECRET entre reinícios.
5. Reinicie o servidor. O lobby exibirá “Entrar com Google”. O convite é retomado após o login.

Sem as credenciais, o pacote continua em modo de desenvolvimento por apelido e informa que o login não está configurado. O OAuth real não foi ativado nesta entrega: depende das suas credenciais e domínio. O fluxo de redirecionamento foi testado com valores fictícios, sem efetuar login Google.

Placar continua por sala/identidade de partida; ranking global de conta e histórico completo de jogos por perfil ainda não estão implementados. Salas ativas continuam em memória. As credenciais da sessão não substituem a persistência de salas após reinício.

Arquivos: server/src/auth.js, migração em db/index.js e client/public/auth.js. Dependências npm novas: passport, passport-google-oauth20 e express-session.
