# Atualização 9.2.3

Restaurado o contorno visível de cada casa do Ludo: linhas cinza-azul explícitas no plano superior, desenhadas em um único lote de instâncias. O caminho não depende mais de frestas minúsculas entre casas para mostrar as divisões. Interface alternativa também usa contorno de um pixel. Demais regras e ajustes preservados.
