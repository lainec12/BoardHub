import 'dotenv/config';import {spawnSync} from 'node:child_process';import {fileURLToPath} from 'node:url';
// Migrações aditivas e versionadas; nunca executa reset ou db push no banco da hospedagem.
if(process.env.DATABASE_URL){const cli=fileURLToPath(new URL('../node_modules/prisma/build/index.js',import.meta.url));const schema=fileURLToPath(new URL('../account/prisma/schema.prisma',import.meta.url));const result=spawnSync(process.execPath,[cli,'migrate','deploy','--schema',schema],{stdio:'inherit',env:process.env});if(result.status!==0)process.exit(result.status||1);}
await import('../server.js');
