import {writeFileSync} from 'node:fs';
const groups=[
 ['Terror',['Abóbora Sombria','Corvo da Névoa','Cripta Lunar','Gato Espectral','Fantasma da Meia-Noite','Morcego de Veludo','Lobisomem','Múmia','Caldeirão','Aranha de Cristal'],['🎃','🐦‍⬛','🌒','🐈‍⬛','👻','🦇','🐺','🧻','🧙','🕷️'],['#9333ea','#182235','#f97316'],'cracks'],
 ['Bichinhos',['Lontra Lunar','Panda de Algodão','Capivara Sonhadora','Pinguim Polar','Coelho de Cereja','Gato de Chantilly','Raposa de Mel','Porquinho de Nuvem','Amigo Axolote','Ouriço de Jardim'],['🦦','🐼','🐹','🐧','🐰','🐱','🦊','🐷','🫧','🦔'],['#f9a8d4','#7dd3fc','#c4b5fd'],'petals'],
 ['Neon',['Pulso Violeta','Circuito Menta','Laser Rosa','Raio Ciano','Cidade Elétrica','Pixel Dourado','Sinal Ultravioleta','Disco Retrô','Onda Digital','Núcleo Neon'],['⚡','🔌','💖','💎','🌃','👾','🟣','🪩','🌊','💡'],['#5b21b6','#155e75','#be185d'],'grid'],
 ['Espacial',['Lua de Cristal','Órbita de Saturno','Nebulosa Rosa','Chuva de Cometas','Estrela Binária','Robô de Marte','Viajante Lunar','Poeira Cósmica','Buraco Negro','Planeta Azul'],['🌙','🪐','🌌','☄️','🌟','🤖','🧑‍🚀','✨','🕳️','🌍'],['#312e81','#164e63','#86198f'],'stars'],
 ['Medieval',['Torre do Norte','Cavaleiro Rubi','Castelo de Jade','Dragão Real','Coroa Lunar','Escudo do Reino','Bardo Violeta','Grifo de Bronze','Chave Encantada','Bruxa da Floresta'],['🏰','⚔️','🏯','🐉','👑','🛡️','🎻','🦅','🗝️','🧙‍♀️'],['#78350f','#713f12','#581c87'],'royal'],
 ['Fantasia',['Jardim de Fadas','Nuvem Açucarada','Onda de Pérola','Borboleta Lilás','Unicórnio de Aurora','Cerejeira Encantada','Sereia Coral','Coração de Cristal','Sol de Lavanda','Arco-íris Mágico'],['🧚','☁️','🐚','🦋','🦄','🌸','🧜','💗','☀️','🌈'],['#a5b4fc','#fbcfe8','#67e8f9'],'pearl']
];
const sizes={dice:82,avatar:60,frame:20,bubble:38};
const prefixes={dice:'Dado',avatar:'',frame:'Moldura',bubble:'Balão'};
const items=Object.entries(sizes).flatMap(([category,size])=>Array.from({length:142-size},(_,i)=>{
 const fill=82-size,base=i<fill;
 const position=base?i:i-fill;
 const [collection,names,icons,colors,pattern]=groups[Math.floor(position/10)%groups.length];
 const variant=position%10,color=colors[variant%3],light=['Bichinhos','Fantasia'].includes(collection);
 return {id:`store-${category}-${i+1}`,category,name:[prefixes[category],names[variant],base?'· Coleção clássica':''].filter(Boolean).join(' '),collection,icon:icons[variant],price:category==='avatar'?50:category==='dice'?60:45,rarity:'Raro',color,pipColor:light?'#172554':'#fff',pattern,roughness:.32,metalness:.15};
}));
writeFileSync(new URL('../client3d/src/metagame/storeData.json',import.meta.url),JSON.stringify(items,null,2)+'\n');
