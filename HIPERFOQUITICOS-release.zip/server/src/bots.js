const starts={red:0,green:13,yellow:26,blue:39};
const safe=new Set([0,8,13,21,26,34,39,47]);
const cell=(color,v)=>v>=0&&v<52?(starts[color]+v)%52:null;
// Avalia apenas o tabuleiro público: não conhece nem altera o próximo dado.
function ludoChoice(s,mark,actions){
 const me=s.players.find(p=>p.color===mark),team=s.teams?.find(t=>t.includes(mark))||[mark];
 const enemies=s.players.filter(p=>!team.includes(p.color));
 const threat=v=>{const c=cell(mark,v);if(c===null||safe.has(c))return 0;return enemies.reduce((sum,p)=>sum+p.tokens.filter(t=>{const x=cell(p.color,t);return x!==null&&(c-x+52)%52>=1&&(c-x+52)%52<=6;}).length,0);};
 const moveScore=(token,to)=>{const from=me.tokens[token],c=cell(mark,to);let score=(to===57?250:to>=52?70:0)+(from===-1?35:to-from)+threat(from)*18-threat(to)*26;
 if(c!==null&&safe.has(c))score+=22;
 if(c!==null&&!safe.has(c))for(const p of enemies)p.tokens.forEach((v,i)=>{if(cell(p.color,v)===c&&p.shield?.token!==i)score+=85+v;});
 return score;};
 const normal=actions.filter(a=>a.type==='move');const best=Math.max(-100,...normal.map(a=>moveScore(a.token,a.to)));
 const scored=actions.map(a=>{let score=-200;
 if(a.type==='move')score=moveScore(a.token,a.to);
 if(a.type==='roll')score=0;if(a.type==='pass'||a.type==='end-turn')score=-5;
 if(a.power==='bonus')score=25;
 if(a.power==='control'){const candidates=me.tokens.map((v,i)=>({i,to:v===-1?(a.value===6?0:-1):v+a.value})).filter(x=>x.to>=0&&x.to<=57);score=Math.max(-100,...candidates.map(x=>moveScore(x.i,x.to)))-12;}
 if(a.power==='double'){const scores=me.tokens.map((v,i)=>({i,to:v===-1?(s.die*2===6?0:-1):v+s.die*2})).filter(x=>x.to>=0&&x.to<=57);const gain=Math.max(-100,...scores.map(x=>moveScore(x.i,x.to)));score=gain>best+15?gain+1:-100;}
 if(a.power==='shield'){score=threat(me.tokens[a.token])>0?best+5:-100;}
 return {a,score};});
 scored.sort((a,b)=>b.score-a.score);return scored[0].a;
}
// Bots usam apenas as ações legais. Naval e UNO consultam a visão pública.
export function chooseBotAction(engine,state,mark,rng){
 const view=engine.publicState?engine.publicState(state,mark):state;
 let actions=engine.legalActions?.(state,mark)|| (state.turn===mark?engine.legalMoves?.(state):[])||[];
 if(!actions.length&&state.board?.length===9&&state.turn===mark)actions=state.board.flatMap((v,cell)=>v?[]:[{type:'move',cell}]);
 if(!actions.length)return null;
 let a;
 if(state.variant==='ludo'){a=ludoChoice(state,mark,actions);
 }else if(actions[0].type==='place'){
  const used=new Set(),fleet=[];
  for(const length of [5,4,3,3,2]){let cells;do{const start=rng(100),step=rng(2)?10:1;cells=Array.from({length},(_,i)=>start+i*step);if(cells.some(c=>c>99||used.has(c))||(step===1&&Math.floor(cells[0]/10)!==Math.floor(cells.at(-1)/10)))cells=null;}while(!cells);cells.forEach(c=>used.add(c));fleet.push(cells);}a={type:'place',fleet};
 }else if(view.shots){const hits=view.shots.filter(s=>s.result==='hit').flatMap(s=>[s.cell-10,s.cell+10,...(s.cell%10?[s.cell-1]:[]),...(s.cell%10<9?[s.cell+1]:[])]);const targets=actions.filter(a=>hits.includes(a.cell));a=(targets.length?targets:actions)[rng((targets.length?targets:actions).length)];
 }else {const preferred=actions.filter(a=>!['draw','pass','challenge'].includes(a.type));const pool=preferred.length?preferred:actions;a=pool[rng(pool.length)];}
 return {type:'move',...a,uno:true,round:state.round,revision:state.revision,ply:state.ply};
}
