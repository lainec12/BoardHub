import {chooseBotAction} from './bots.js';
import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { randomBytes, randomInt } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db/index.js';
import { games } from './games/index.js';
import {configureAuth} from './auth.js';

export function createBoardHub({dbPath=process.env.DB_PATH || './data/boardhub.sqlite',graceMs=60000}={}) {
  const app=express(), http=createServer(app), rooms=new Map();
  const db=openDatabase(dbPath);
  const allowed=process.env.CLIENT_ORIGIN?.split(',').map(s=>s.trim());
  const io=new Server(http,{maxHttpBufferSize:8192,cors:allowed?{origin:allowed}:undefined,
    allowRequest:(req,callback)=>callback(null,!req.headers.origin || (allowed?allowed.includes(req.headers.origin):req.headers.origin===`https://${req.headers.host}` || req.headers.origin===`http://${req.headers.host}`))});
  app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' ws: wss:; base-uri 'none'; frame-ancestors 'none'");next();});
  app.get('/health',(_,res)=>res.json({ok:true}));
  configureAuth(app,io,db);
  // app.js está em server/src: dois níveis chegam à raiz do projeto.
  const assets=fileURLToPath(new URL('../../client/public/',import.meta.url));
  app.use(express.static(assets));
  app.get('/join/:code',(_,res)=>res.sendFile(assets+'index.html'));
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const code=()=>Array.from({length:6},()=>alphabet[randomInt(alphabet.length)]).join('');
  const clean=(v,max)=>{
    if(typeof v!=='string') throw Error('Texto inválido.');
    const s=v.replace(/[\u0000-\u001f\u007f<>]/g,'').trim();
    if(!s || s.length>max) throw Error(`Use de 1 a ${max} caracteres.`);return s;
  };
  function system(r,text) {r.chat.push({id:randomBytes(8).toString('hex'),name:'BoardHub',text,time:Date.now(),system:true});r.chat=r.chat.slice(-100);}
  function publish(r) {
    if(r.players.some(p=>p.bot) && r.status==='playing' && !r.botTimer && !r.game.winner && r.players.some(p=>!p.bot&&p.socket)){
      r.botTimer=setTimeout(()=>{
        r.botTimer=null;if(r.status!=='playing'||r.game.winner)return;
        const engine=games[r.gameId];
        for(const bot of r.players.filter(p=>p.bot)){
          const action=chooseBotAction(engine,r.game,bot.mark,n=>randomInt(n));
          if(!action)continue;
          try{r.game=engine.applyAction(r.game,bot.mark,action,n=>randomInt(n));
          if(r.game.winner)finish(r,r.game.winner,r.game.reason);publish(r);}catch(e){console.error('Bot action failed',r.gameId,e.message);}
          return;
        }
      },650);r.botTimer.unref?.();
    }
    const engine=games[r.gameId];
    if(engine.publicState){for(const p of r.players)if(p.socket)io.to(p.socket).emit('game:state',{solo:r.solo,code:r.code,gameId:r.gameId,gameName:engine.name,legalMoves:engine.legalActions(r.game,p.mark),host:r.host,status:r.status,drawOffer:null,game:engine.publicState(r.game,p.mark),chat:r.chat,scores:db.score(r.code),history:db.history(r.code),players:r.players.map(q=>({id:q.id,name:q.name,mark:q.mark,online:!!q.socket,deadline:q.deadline||null}))});return;}
    const actions=engine.legalActions?.(r.game,r.game.players?.[r.game.turnIndex]?.color) || engine.legalMoves?.(r.game) || [];
    io.to(r.code).emit('game:state',{solo:r.solo,code:r.code,gameId:r.gameId,gameName:engine.name,legalMoves:actions,drawOffer:r.drawOffer || null,host:r.host,status:r.status,
      game:r.game,chat:r.chat,scores:db.score(r.code),history:db.history(r.code),
      players:r.players.map(p=>({id:p.id,name:p.name,mark:p.mark,online:!!p.socket,deadline:p.deadline || null}))});
  }
  function finish(r,winner,reason) {
    if(r.status!=='playing') return;
    r.game={...r.game,winner,reason};db.finish(r.code,r.game,r.players);r.status='finished';r.drawOffer=null;
    system(r,winner==='draw'?'A partida empatou.':`${r.players.find(p=>p.mark===winner)?.name} venceu (${reason}).`);
  }
  function detach(r,p,reason) {
    clearTimeout(p.timer);
    if(r.status==='playing') {
      const remaining=r.players.filter(q=>q!==p);
      const winner=remaining.length===1?remaining[0].mark:'draw';
      finish(r,winner,reason);
    }
    r.players=r.players.filter(q=>q!==p);
    const old=io.sockets.sockets.get(p.socket);
    if(old) {old.leave(r.code);old.data.room=null;old.emit('room:removed',{reason});}
    if(r.host===p.id) r.host=r.players[0]?.id || null;
    system(r,`${p.name} saiu: ${reason}.`);
    r.touched=Date.now();publish(r);
  }
  io.on('connection',socket=>{
    let count=0, windowStart=Date.now(),lastChat=0;
    const current=()=>{
      const r=rooms.get(socket.data.room), p=r?.players.find(p=>p.socket===socket.id);
      if(!r || !p) throw Error('Entre em uma sala primeiro.');
      if(p.accountId&&db.getSession(socket.request.sessionID)?.passport?.user!==p.accountId)throw Error('Sessão encerrada. Entre novamente com Google.');
      r.touched=Date.now();return {r,p};
    };
    const hostOnly=(r,p)=>{if(r.host!==p.id) throw Error('Apenas o anfitrião pode fazer isso.');};
    const playersReady=r=>{const game=games[r.gameId];if(r.players.length<game.minPlayers || r.players.some(p=>!p.socket)) throw Error(`Aguarde pelo menos ${game.minPlayers} jogadores conectados.`);};
    // Teto de dez eventos/segundo por conexão (inclui chat e ações inválidas).
    const on=(event,fn)=>socket.on(event,(data,ack)=>{
      try {
        if(Date.now()-windowStart>=1000){count=0;windowStart=Date.now();}
        if(++count>10) throw Error('Limite de 10 ações por segundo.');
        if(!data || typeof data!=='object' || Array.isArray(data)) throw Error('Payload inválido.');
        const result=fn(data);if(typeof ack==='function') ack({ok:true,...result});
      } catch(e) {if(typeof ack==='function') ack({ok:false,error:e.message});}
    });
    function enter(data,create) {
      if(socket.data.room) throw Error('Saia da sala atual primeiro.');
      const googleEnabled=!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET);
      const accountId=googleEnabled?db.getSession(socket.request.sessionID)?.passport?.user:null;
      const account=googleEnabled&&accountId?db.getUser(accountId):null;
      if(googleEnabled&&!account)throw Error('Entre com Google para acessar os jogos.');
      const name=clean(account?account.name.slice(0,24):data.name,24);
      let r;
      if(create) {
        if(rooms.size>=1000) throw Error('Servidor cheio.');
        const gameId=data.gameId || 'tic-tac-toe';
        if(!Object.hasOwn(games,gameId))throw Error('Jogo inválido.');
        let id;do{id=code();}while(rooms.has(id) || db.roomExists(id));
        const options=gameId==='ludo'?{mode:data.mode,acquisition:data.acquisition}:{};
        r={solo:data.solo===true,code:id,gameId,options,players:[],host:null,game:games[gameId].createState(1,options),status:'waiting',chat:[],touched:Date.now()};rooms.set(id,r);
      } else {r=rooms.get(String(data.code).toUpperCase());if(!r) throw Error('Sala não encontrada ou expirada.');}
      let p=account?r.players.find(p=>p.accountId===account.id):(typeof data.token==='string'?r.players.find(p=>p.token===data.token):null);
      if(r.solo && !p && r.players.length)throw Error('Sala exclusiva contra o computador. Crie uma sala com amigos para convidar.');
      if(p?.socket) throw Error('Este jogador já está conectado.');
      const reconnect=!!p;
      if(!p) {
        if(r.players.length>=games[r.gameId].maxPlayers) throw Error('Sala cheia.');
        if(r.status==='playing') throw Error('A partida já começou.');
        const mark=games[r.gameId].playerMarks.find(value=>!r.players.some(p=>p.mark===value));
        p={id:randomBytes(12).toString('hex'),accountId:account?.id||null,name,mark,token:randomBytes(24).toString('hex')};
        db.register(r.code,p);r.players.push(p);if(!r.host) r.host=p.id;
      }
      clearTimeout(p.timer);p.deadline=null;p.socket=socket.id;
      socket.data.room=r.code;socket.join(r.code);r.touched=Date.now();
      system(r,`${p.name} ${reconnect?'voltou à':'entrou na'} sala.`);
      if(reconnect) io.to(r.code).emit('player:reconnect',{playerId:p.id});
      publish(r);return {code:r.code,token:p.token,playerId:p.id,mark:p.mark};
    }
    on('room:create',d=>enter(d,true));on('room:join',d=>enter(d,false));
    on('room:leave',()=>{const {r,p}=current();detach(r,p,'desistência');});
    on('room:kick',d=>{
      const {r,p}=current();hostOnly(r,p);
      const target=r.players.find(q=>q.id===d.playerId && q!==p);
      if(!target) throw Error('Jogador inválido.');detach(r,target,'expulsão pelo anfitrião');
    });
    on('room:fill-bots',()=>{
      const {r,p}=current();hostOnly(r,p);
      if(r.status!=='waiting')throw Error('Complete a sala antes de iniciar.');
      const profiles=[['Luna','🌙'],['Orion','🦊'],['Nina','🐼'],['Atlas','🦉']];
      for(const mark of games[r.gameId].playerMarks){if(r.players.some(q=>q.mark===mark))continue;
        const [name,avatar]=profiles[randomInt(profiles.length)];
        const bot={id:randomBytes(12).toString('hex'),name:avatar+' '+name+' · Bot '+(r.players.length+1),mark,bot:true,socket:'bot'};
        r.players.push(bot);db.register(r.code,bot);
      }
      publish(r);
    });
    on('room:start',d=>{
      const {r,p}=current();hostOnly(r,p);
      if(r.solo && r.players.length===1){for(const mark of games[r.gameId].playerMarks.slice(1)){
        const bot={id:randomBytes(12).toString('hex'),name:'Computador '+mark,mark,bot:true,socket:'bot'};r.players.push(bot);db.register(r.code,bot);
      }}
      playersReady(r);
      if(r.status!=='waiting') throw Error('Use reiniciar para uma nova partida.');
      if(r.gameId==='ludo' && [true,'together','versus'].includes(d.teams)){
        const humans=r.players.filter(p=>!p.bot),bots=r.players.filter(p=>p.bot);
        if(humans.length!==2||bots.length!==2)throw Error('Duplas exigem dois amigos e dois bots. Complete as vagas primeiro.');
        r.players=d.teams==='versus'?[humans[0],humans[1],bots[0],bots[1]]:[humans[0],bots[0],humans[1],bots[1]];
        r.players.forEach((player,index)=>{player.mark=games.ludo.playerMarks[index];});
        r.options.teams=[['red','yellow'],['green','blue']];r.game.teams=r.options.teams;
      }
      if(games[r.gameId].startGame)r.game=games[r.gameId].startGame(r.game,r.players.map(p=>p.mark));
      r.status='playing';system(r,games[r.gameId].name+': partida iniciada.');publish(r);
    });
    on('room:restart',()=>{
      const {r,p}=current();hostOnly(r,p);playersReady(r);
      // Reinício no meio da partida fica no histórico como partida anulada.
      if(r.status==='playing') system(r,'O anfitrião reiniciou a partida em andamento (sem pontuação).');
      r.game=games[r.gameId].createState(r.game.round+1,r.options);
      if(games[r.gameId].startGame)r.game=games[r.gameId].startGame(r.game,r.players.map(p=>p.mark));
      r.drawOffer=null;r.status='playing';system(r,'Nova partida iniciada.');publish(r);
    });
    on('game:action',action=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing') throw Error('A partida não está em andamento.');
      const next=games[r.gameId].applyAction(r.game,p.mark,action,n=>randomInt(n));
      r.drawOffer=null;
      // finish centraliza o registro único da vitória/empate no banco.
      r.game=next;
      if(next.lastMove){const m=next.lastMove;system(r,`${p.name} moveu ${m.path.map(i=>String.fromCharCode(97+i%8)+(8-Math.floor(i/8))).join(' → ')}${m.captures.length?' · capturas: '+m.captures.length:''}${m.promoted?' · virou dama':''}.`);}
      if(next.lastEvent&&r.gameId==='ludo')system(r,`${p.name}: ${JSON.stringify(next.lastEvent)}.`);
      if(next.winner) finish(r,next.winner,next.reason);
      publish(r);
    });
    on('game:draw-offer',()=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing')throw Error('Não há partida em andamento.');
      if(r.drawOffer)throw Error('Já existe uma proposta pendente.');
      r.drawOffer=p.id;system(r,`${p.name} propôs empate.`);publish(r);
    });
    on('game:draw-answer',d=>{
      const {r,p}=current();playersReady(r);
      if(r.status!=='playing' || !r.drawOffer || r.drawOffer===p.id || typeof d.accept!=='boolean')throw Error('Proposta inválida.');
      if(d.accept)finish(r,'draw','acordo entre jogadores');
      else system(r,`${p.name} recusou o empate.`);
      r.drawOffer=null;publish(r);
    });
    on('game:resign',()=>{
      const {r,p}=current();if(r.status!=='playing') throw Error('Não há partida em andamento.');
      const others=r.players.filter(q=>q!==p);finish(r,others.length===1?others[0].mark:'draw','desistência');publish(r);
    });
    on('chat:message',d=>{
      const {r,p}=current();const text=clean(d.text,400);
      if(Date.now()-lastChat<700) throw Error('Espere um instante entre mensagens.');lastChat=Date.now();
      r.chat.push({id:randomBytes(8).toString('hex'),name:p.name,text,time:Date.now(),mark:p.mark});r.chat=r.chat.slice(-100);publish(r);
    });
    socket.on('disconnect',()=>{
      const r=rooms.get(socket.data.room),p=r?.players.find(p=>p.socket===socket.id);if(!p)return;
      p.socket=null;p.deadline=Date.now()+graceMs;system(r,`${p.name} desconectou. A partida está pausada por até 60 segundos.`);
      io.to(r.code).emit('player:disconnect',{playerId:p.id,deadline:p.deadline});
      p.timer=setTimeout(()=>{if(!p.socket) detach(r,p,'tempo de reconexão esgotado');},graceMs);p.timer.unref();publish(r);
    });
  });
  const cleanup=setInterval(()=>{for(const [id,r] of rooms) if(!r.players.length && Date.now()-r.touched>1800000) rooms.delete(id);},60000);cleanup.unref();
  return {http,io,rooms,async close(){clearInterval(cleanup);for(const r of rooms.values()) for(const p of r.players) clearTimeout(p.timer);await new Promise(resolve=>io.close(resolve));db.close();}};
}
