// Bots usam apenas as ações legais. Naval e UNO consultam a visão pública.
export function chooseBotAction(engine,state,mark,rng){
 const view=engine.publicState?engine.publicState(state,mark):state;
 let actions=engine.legalActions?.(state,mark)|| (state.turn===mark?engine.legalMoves?.(state):[])||[];
 if(!actions.length&&state.board?.length===9&&state.turn===mark)actions=state.board.flatMap((v,cell)=>v?[]:[{type:'move',cell}]);
 if(!actions.length)return null;
 let a;
 if(actions[0].type==='place'){
  const used=new Set(),fleet=[];
  for(const length of [5,4,3,3,2]){let cells;do{const start=rng(100),step=rng(2)?10:1;cells=Array.from({length},(_,i)=>start+i*step);if(cells.some(c=>c>99||used.has(c))||(step===1&&Math.floor(cells[0]/10)!==Math.floor(cells.at(-1)/10)))cells=null;}while(!cells);cells.forEach(c=>used.add(c));fleet.push(cells);}a={type:'place',fleet};
 }else if(view.shots){const hits=view.shots.filter(s=>s.result==='hit').flatMap(s=>[s.cell-10,s.cell+10,...(s.cell%10?[s.cell-1]:[]),...(s.cell%10<9?[s.cell+1]:[])]);const targets=actions.filter(a=>hits.includes(a.cell));a=(targets.length?targets:actions)[rng((targets.length?targets:actions).length)];
 }else {const preferred=actions.filter(a=>!['draw','pass','challenge'].includes(a.type));const pool=preferred.length?preferred:actions;a=pool[rng(pool.length)];}
 return {type:'move',...a,uno:true,round:state.round,revision:state.revision,ply:state.ply};
}
