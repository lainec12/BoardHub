// Entrada de execução. O app também é exportável para testes sem abrir porta fixa.
import { createBoardHub } from './server/src/app.js';
const {http}=createBoardHub();
http.listen(process.env.PORT || 3000,'0.0.0.0',()=>console.log('BoardHub em http://localhost:'+(process.env.PORT || 3000)));
